from fastapi import FastAPI, Depends, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from fastapi.responses import JSONResponse
from jose import jwt
from pwdlib import PasswordHash
from pydantic import BaseModel
from datetime import datetime, timedelta, timezone
from typing import Optional
import sqlite3
import uvicorn
import logging
import csv
import io
import os
import time
import socketio
import pandas as pd
import json

from core.redis_client import redis_client as r
from anomaly.inference_pipeline import InferencePipeline
from security.security_pipeline import SecurityPipeline
from threat.inference_pipeline import predict as threat_predict 
from fastapi import UploadFile, File
from starlette.concurrency import run_in_threadpool

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.path.join(BASE_DIR, "users.db")

app = FastAPI()

# =========================================================
# Socket.io Setup
# =========================================================
sio = socketio.AsyncServer(
    async_mode='asgi',
    cors_allowed_origins='*',
    logger=True, 
    engineio_logger=True
)
app_sio = socketio.ASGIApp(sio)
combined_app = socketio.ASGIApp(
    socketio_server=sio, 
    other_asgi_app=app,
)

# =========================================================
# 2. CORS Middleware 
# =========================================================
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], 
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# =========================================================
# Logging (Professional)
# =========================================================
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler("aisentinel.log", mode="a", delay=False), 
        logging.StreamHandler() 
    ]
)
logger = logging.getLogger(__name__)

# =========================================================
# Helper Function to Save Logs in JSONL Format
# =========================================================
def save_log_to_jsonl(log_entry, result):
    try:
        file_path = os.path.join(BASE_DIR, "aisentinel_raw_data.jsonl")
        
        data_to_save = {
            "@timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "source_ip": log_entry.get("source_ip"),
            "request_url": log_entry.get("request_url"),
            "stages": result.get("stages", []),
            "sub_type": result.get("sub_type", "None"),
            "anomaly_score": result.get("anomaly_score", 0.0),
            "status": result.get("status")
        }
        
        with open(file_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(data_to_save) + "\n")

        import asyncio
        asyncio.run_coroutine_threadsafe(
            sio.emit('security_update_live', data_to_save), 
            loop=asyncio.get_event_loop()
        )
    except Exception as e:
        logger.error(f"Error saving JSONL log: {e}")

# =========================================================
# App Initialization
# =========================================================
anomaly_model = InferencePipeline()
# الـ Pipeline العام للـ Security تم ترقيته وتمرير الـ Model الجديد له
pipeline = SecurityPipeline(anomaly_model=anomaly_model, threat_model=threat_predict)
password_hasher = PasswordHash.recommended()

# =========================================================
# Middleware (WAF Layer)
# =========================================================
@app.middleware("http")
async def security_middleware(request: Request, call_next):
    client_ip = request.headers.get("x-forwarded-for", request.client.host)
    path = request.url.path
    
    if (path == "/predict" or 
        path.startswith("/socket.io") or 
        path == "/login" or 
        path.startswith("/api/")):  # يحمي مسار upload-logs و logs تماماً
        return await call_next(request)
    
    allowed_paths = ["/login", "/change-password", "/docs", "/openapi.json", "/socket.io"]
    is_static = any(path.endswith(ext) for ext in [".ico", ".png", ".jpg", ".css", ".js"])
    is_allowed = path in allowed_paths or path.startswith("/users")

    if is_allowed or is_static:
        return await call_next(request)
    
    # الفحص الصارم للـ Redis في البيئة الحقيقية
    if r and r.exists(f"block:{client_ip}"):
        return JSONResponse(status_code=403, content={"detail": "Blocked"})

    body_bytes = await request.body()
    body_str = body_bytes.decode('utf-8', errors='ignore') if body_bytes else ""

    if client_ip == "127.0.0.1":
        return await call_next(request) 

    async def receive():
        return {"type": "http.request", "body": body_bytes}
    request._receive = receive

    log_entry = {
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "source_ip": client_ip,
        "request": f"{request.method} {path} HTTP/1.1",
        "request_url": str(request.url),
        "query_parameters": str(request.query_params),
        "body": body_str,
        "headers": dict(request.headers),
        "http_method": request.method,
        "status_code": 200,
        "response_size": len(body_bytes),
        "referrer": request.headers.get("referer", "-"),
        "user_agent": request.headers.get("user-agent", "unknown")
    }

    logger.info(f"WAF Check | IP={client_ip} | PATH={path}")
    result = pipeline.run(log_entry)

    try:
        save_log_to_jsonl(log_entry, result)
    except:
        pass 

    if result["status"] == "blocked":
        if r:
            r.setex(f"block:{client_ip}", 600, json.dumps({
                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "reason": result['reason'],
                "severity": result["severity"],
                "type": result.get("sub_type")
            }))
            import asyncio
            asyncio.run_coroutine_threadsafe(
                sio.emit('ip_blocked_live', {"ip": client_ip, "reason": result['reason']}), 
                loop=asyncio.get_event_loop()
            )
        return JSONResponse(status_code=403, content={"detail": f"Security Alert: {result['reason']}"})

    return await call_next(request)

# ==================================================
# ده لتجربة داتا ال wireshark
# @app.middleware("http")
# async def security_middleware(request: Request, call_next):
#     client_ip = request.headers.get("x-forwarded-for", request.client.host)
#     path = request.url.path
    
#     # حماية خاصة: لو الريكوست رايح للاختبار، مرره فوراً للدالة بدون أي فحص في الـ Middleware
#     if path == "/predict" or path.startswith("/socket.io") or path == "/login":
#         return await call_next(request)
    
#     allowed_paths = ["/login", "/change-password", "/docs", "/openapi.json", "/socket.io"]
#     is_static = any(path.endswith(ext) for ext in [".ico", ".png", ".jpg", ".css", ".js"])
#     is_allowed = path in allowed_paths or path.startswith("/users")

#     if is_allowed or is_static:
#         return await call_next(request)
    
#     # الفحص الصارم للـ Redis في البيئة الحقيقية
#     if r and r.exists(f"block:{client_ip}"):
#         return JSONResponse(status_code=403, content={"detail": "Blocked"})

#     body_bytes = await request.body()
#     body_str = body_bytes.decode('utf-8', errors='ignore') if body_bytes else ""

#     if client_ip == "127.0.0.1":
#         return await call_next(request) 

#     async def receive():
#         return {"type": "http.request", "body": body_bytes}
#     request._receive = receive

#     log_entry = {
#         "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
#         "source_ip": client_ip,
#         "request": f"{request.method} {path} HTTP/1.1",
#         "request_url": str(request.url),
#         "query_parameters": str(request.query_params),
#         "body": body_str,
#         "headers": dict(request.headers),
#         "http_method": request.method,
#         "status_code": 200,
#         "response_size": len(body_bytes),
#         "referrer": request.headers.get("referer", "-"),
#         "user_agent": request.headers.get("user-agent", "unknown")
#     }

#     logger.info(f"WAF Check | IP={client_ip} | PATH={path}")
#     result = pipeline.run(log_entry)

#     try:
#         save_log_to_jsonl(log_entry, result)
#     except:
#         pass 

#     if result["status"] == "blocked":
#         if r:
#             r.setex(f"block:{client_ip}", 600, json.dumps({
#                 "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
#                 "reason": result['reason'],
#                 "severity": result["severity"],
#                 "type": result.get("sub_type")
#             }))
#             import asyncio
#             asyncio.run_coroutine_threadsafe(
#                 sio.emit('ip_blocked_live', {"ip": client_ip, "reason": result['reason']}), 
#                 loop=asyncio.get_event_loop()
#             )
#         return JSONResponse(status_code=403, content={"detail": f"Security Alert: {result['reason']}"})

#     return await call_next(request)


# ==================================================
#هنرجع نشغل ده
# @app.middleware("http")
# async def security_middleware(request: Request, call_next):
#     client_ip = request.headers.get("x-forwarded-for", request.client.host)
#     path = request.url.path
#     if path.startswith("/socket.io") or path == "/login":
#         return await call_next(request)
    
#     allowed_paths = ["/login", "/change-password", "/docs", "/openapi.json", "/socket.io"]
    
#     is_static = any(path.endswith(ext) for ext in [".ico", ".png", ".jpg", ".css", ".js"])
#     is_allowed = path in allowed_paths or path.startswith("/users")

#     if is_allowed or is_static:
#         return await call_next(request)
    
#     if r and r.exists(f"block:{client_ip}"):
#         return JSONResponse(status_code=403, content={"detail": "Blocked"})

#     body_bytes = await request.body()
#     body_str = body_bytes.decode('utf-8', errors='ignore') if body_bytes else ""

#     if client_ip == "127.0.0.1":
#         return await call_next(request) 

#     async def receive():
#         return {"type": "http.request", "body": body_bytes}

#     request._receive = receive

#     log_entry = {
#         "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
#         "source_ip": client_ip,
#         "request": f"{request.method} {path} HTTP/1.1",
#         "request_url": str(request.url),
#         "query_parameters": str(request.query_params),
#         "body": body_str,
#         "headers": dict(request.headers),
#         "http_method": request.method,
#         "status_code": 200,  # قيمة افتراضية للمعالجة الأولية قبل خروج الرد
#         "response_size": len(body_bytes),
#         "referrer": request.headers.get("referer", "-"),
#         "user_agent": request.headers.get("user-agent", "unknown")
#     }

#     logger.info(f"WAF Check | IP={client_ip} | PATH={path}")

#     result = pipeline.run(log_entry)

#     try:
#         save_log_to_jsonl(log_entry, result)
#     except:
#         pass 

#     if result["status"] == "blocked":
#         return JSONResponse(
#             status_code=403,
#             content={
#                 "detail": f"Security Alert: {result['reason']}",
#                 "severity": result["severity"],
#                 "type": result.get("sub_type")
#             }
#         )

#     return await call_next(request)

# =========================================================
# Secrets & Auth Setup
# =========================================================
SECRET_KEY = "AISENTINEL_SUPER_SECRET_KEY_2026"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="login")

class PasswordChangeRequest(BaseModel):
    new_password: str

class UserCreateRequest(BaseModel):
    username: str
    role: str

def init_db():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS users 
                      (username TEXT PRIMARY KEY, hashed_password TEXT, role TEXT, must_change_password INTEGER)''')
    temp_pass = password_hasher.hash("temp123")
    users = [('admin_boss', temp_pass, 'super_admin', 1)]
    for u in users:
        cursor.execute("INSERT OR IGNORE INTO users VALUES (?, ?, ?, ?)", u)
    conn.commit()
    conn.close()

init_db()

def create_access_token(data: dict):
    to_encode = data.copy()
    expire = datetime.now(timezone.utc) + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

# -----------------------------------------------------------------------
# Routes
# -----------------------------------------------------------------------
@app.post("/predict")
async def predict_endpoint(log: dict):
    try:
        target_ip = str(log.get("ip", log.get("source_ip", "192.168.1.50"))).strip()
        if not target_ip or target_ip == "unknown" or "EDT" in target_ip:
            target_ip = "192.168.1.50"
        
        log["source_ip"] = target_ip
        log["ip"] = target_ip

        if "request" not in log:
            raw_url = log.get("url") or log.get("request_url") or "/"
            log["request"] = f"{log.get('http_method', 'GET')} {raw_url} HTTP/1.1"
            log["request_url"] = raw_url

        log.setdefault("timestamp", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
        log.setdefault("status_code", 200)
        log.setdefault("response_size", 0)
        log.setdefault("user_agent", "Mozilla/5.0")
        log.setdefault("referrer", "-")

        result = pipeline.run(log)
        
        if not isinstance(result, dict):
            result = {"status": "normal", "reason": "Pipeline Fallback", "stages": ["Error"], "sub_type": "None", "anomaly_score": 0.0}

    except Exception as e:
        logger.error(f"Pipeline Error: {e}")
        result = {"status": "error", "stages": ["Failed"], "sub_type": "None", "anomaly_score": 0.0, "reason": str(e)}

    save_log_to_jsonl(log, result)

    if result.get("status") == "blocked":
        if r:
            r.setex(f"block:{target_ip}", 600, json.dumps({
                "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "reason": result.get("reason", "Security Alert"),
                "severity": result.get("severity", "High"),
                "type": result.get("sub_type", "None")
            }))
            
            import asyncio
            try:
                loop = asyncio.get_event_loop()
            except RuntimeError:
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                
            asyncio.run_coroutine_threadsafe(
                sio.emit('ip_blocked_live', {"ip": target_ip, "reason": result.get("reason")}), 
                loop=loop
            )

    log_file = os.path.join(BASE_DIR, "security_detections.csv")
    file_exists = os.path.isfile(log_file)
    try:
        with open(log_file, mode='a', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            if not file_exists:
                writer.writerow(['Timestamp', 'IP', 'Request', 'Stage', 'Threat_Type', 'Anomaly_Score', 'Final_Status'])
            
            raw_req_for_csv = log.get("request_url") or log.get("request") or "/"
            
            writer.writerow([
                time.strftime("%Y-%m-%d %H:%M:%S"),
                target_ip,
                raw_req_for_csv,
                " | ".join(result.get("stages", [])),
                result.get("sub_type"),
                result.get("anomaly_score", 0.0),
                result.get("status")
            ])
    except Exception as e:
        logger.error(f"[ERROR] Failed to write CSV: {e}")

    return result

#25/6/2025 6 PM
# Wireshark
# @app.post("/predict")
# async def predict_endpoint(log: dict):
#     try:
#         # 1️⃣ استخراج دقيق وعزل كامل للـ IP لمنع قراءة التوقيت كـ IP
#         target_ip = str(log.get("ip", "192.168.1.50")).strip()
#         if not target_ip or target_ip == "unknown" or "EDT" in target_ip:
#             target_ip = "192.168.1.50"

#         # توحيد المتغيرات داخل الـ log المتمرر للموديل
#         log["source_ip"] = target_ip
#         log["ip"] = target_ip
        
#         # 2️⃣ استخراج الـ URL والـ Request الأصلي لتغذية الـ Threat Model بشكل سليم
#         # جلب الـ URI النقي الجاي من الـ simulator
#         raw_url = log.get("url") or log.get("request_url") or "/"
        
#         # هندسة المفاتيح: نوحد الصيغة اللي مستنيها الـ Threat Model تفصيلياً
#         log["request"] = f"GET {raw_url} HTTP/1.1"
#         log["request_url"] = raw_url
#         log["url"] = raw_url

#         # التأمين الشامل للمفاتيح لضمان نجاح الـ Preprocessing في كل الموديلات
#         log.setdefault("timestamp", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
#         log.setdefault("status_code", 200)
#         log.setdefault("response_size", 0)
        
#         # تغذية الـ User Agent والـ Browser والـ Referrer كـ نصوص نقية منعاً للـ Unhashable Dict
#         log["user_agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
#         log["browser"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
#         log["headers"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64)" 
#         log["referrer"] = "unknown"
#         log["referer"] = "unknown"

#         # تشغيل الفحص على الموديلات والـ Pipeline المشترك
#         result = pipeline.run(log)
#     except Exception as e:
#         logger.error(f"Pipeline Error: {e}")
#         result = {"status": "error", "stages": ["Failed"], "sub_type": "None", "anomaly_score": 0.0, "reason": str(e)}

#     save_log_to_jsonl(log, result)

#     # الحظر النظيف في الـ Redis بناءً على الـ IP الحقيقي فقط
#     if result.get("status") == "blocked":
#         if r:
#             r.setex(f"block:{target_ip}", 600, json.dumps({
#                 "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
#                 "reason": result.get("reason", "Security Alert"),
#                 "severity": result.get("severity", "High"),
#                 "type": result.get("sub_type", "None")
#             }))
            
#             import asyncio
#             try:
#                 loop = asyncio.get_event_loop()
#             except RuntimeError:
#                 loop = asyncio.new_event_loop()
#                 asyncio.set_event_loop(loop)
                
#             asyncio.run_coroutine_threadsafe(
#                 sio.emit('ip_blocked_live', {"ip": target_ip, "reason": result.get("reason")}), 
#                 loop=loop
#             )

#     # كتابة الـ CSV التقييمي
#     log_file = os.path.join(BASE_DIR, "security_detections.csv")
#     file_exists = os.path.isfile(log_file)
#     try:
#         with open(log_file, mode='a', newline='', encoding='utf-8') as f:
#             writer = csv.writer(f)
#             if not file_exists:
#                 writer.writerow(['Timestamp', 'IP', 'Request', 'Stage', 'Threat_Type', 'Anomaly_Score', 'Final_Status'])
#             writer.writerow([
#                 time.strftime("%Y-%m-%d %H:%M:%S"),
#                 target_ip,
#                 log.get("request_url") or log.get("request") or "/",
#                 " | ".join(result.get("stages", [])),
#                 result.get("sub_type"),
#                 result.get("anomaly_score"),
#                 result.get("status")
#             ])
#     except Exception as e:
#         logger.error(f"[ERROR] Failed to write CSV: {e}")

#     return result


#  24/6/2025
# @app.post("/predict")
# async def predict_endpoint(log: dict):
#     try:
#         log.setdefault("timestamp", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
#         log.setdefault("source_ip", log.get("ip", "unknown"))
#         log.setdefault("request", f"{log.get('method', 'GET')} {log.get('url', '/')} HTTP/1.1")
#         log.setdefault("status_code", 200)
#         log.setdefault("response_size", 0)
#         log.setdefault("user_agent", "Mozilla/5.0")
#         log.setdefault("referrer", "-")

#         result = pipeline.run(log)
#     except Exception as e:
#         logger.error(f"Pipeline Error: {e}")
#         result = {"status": "error", "stages": ["Failed"], "sub_type": "None", "anomaly_score": 0.0, "reason": str(e)}

#     save_log_to_jsonl(log, result)

#     log_file = os.path.join(BASE_DIR, "security_detections.csv")
#     file_exists = os.path.isfile(log_file)

#     try:
#         with open(log_file, mode='a', newline='', encoding='utf-8') as f:
#             writer = csv.writer(f)
#             if not file_exists:
#                 writer.writerow(['Timestamp', 'IP', 'Request', 'Stage', 'Threat_Type', 'Anomaly_Score', 'Final_Status'])
            
#             writer.writerow([
#                 time.strftime("%Y-%m-%d %H:%M:%S"),
#                 log.get("source_ip") or "unknown",
#                 log.get("request_url") or log.get("request") or "/",
#                 " | ".join(result.get("stages", [])),
#                 result.get("sub_type"),
#                 result.get("anomaly_score"),
#                 result.get("status")
#             ])
#     except Exception as e:
#         logger.error(f"[ERROR] Failed to write CSV: {e}")

#     return result

@app.post("/login")
def login(form_data: OAuth2PasswordRequestForm = Depends()):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT hashed_password, role, must_change_password FROM users WHERE username = ?", (form_data.username,))
    user = cursor.fetchone()
    conn.close()

    if not user or not password_hasher.verify(form_data.password, user[0]):
        raise HTTPException(status_code=401, detail="Incorrect username or password")

    access_token = create_access_token(data={"sub": form_data.username, "role": user[1]})
    return {"access_token": access_token, "token_type": "bearer", "role": user[1], "username": form_data.username, "must_change_password": bool(user[2])}

@app.post("/users")
def create_user(request: UserCreateRequest, token: str = Depends(oauth2_scheme)):
    payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
    admin_role = payload.get("role")
    
    if admin_role != "super_admin":
        raise HTTPException(status_code=403, detail="Only Super Admins can create users")

    temp_password = password_hasher.hash("temp123") 
    
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("INSERT INTO users (username, hashed_password, role, must_change_password) VALUES (?, ?, ?, ?)", 
                       (request.username, temp_password, request.role, 1))
        conn.commit()
        conn.close()
        return {"status": "success", "message": f"User {request.username} created successfully"}
    except sqlite3.IntegrityError:
        raise HTTPException(status_code=400, detail="Username already exists")
    except Exception as e:
        logger.error(f"Error creating user: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error")

@app.get("/users")
def get_all_users(token: str = Depends(oauth2_scheme)):
    try:
        jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
    except:
        raise HTTPException(status_code=401, detail="Invalid token")

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT username, role, must_change_password FROM users")
    user_list = cursor.fetchall()
    conn.close()

    return [{"username": u[0], "role": u[1], "must_change": bool(u[2])} for u in user_list]

@app.delete("/users/{username}")
def delete_user(username: str, token: str = Depends(oauth2_scheme)):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        if payload.get("role") != "super_admin":
            raise HTTPException(status_code=403, detail="Forbidden: Admins only")

        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("DELETE FROM users WHERE username = ?", (username,))
        conn.commit()
        
        if cursor.rowcount == 0:
            conn.close()
            raise HTTPException(status_code=404, detail="User not found")
            
        conn.close()
        return {"status": "success", "message": f"User {username} deleted"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/change-password")
def change_password(request: PasswordChangeRequest, token: str = Depends(oauth2_scheme)):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username = payload.get("sub")
        
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        cursor.execute("SELECT hashed_password, username FROM users")
        all_users = cursor.fetchall()
        for hashed_pass, user_owner in all_users:
            if password_hasher.verify(request.new_password, hashed_pass):
                conn.close()
                raise HTTPException(
                    status_code=400, 
                    detail="Security Policy Violation: Please choose a different password."
                )
             
        new_hashed_password = password_hasher.hash(request.new_password)
        cursor.execute("UPDATE users SET hashed_password = ?, must_change_password = 0 WHERE username = ?", 
                       (new_hashed_password, username))
        conn.commit()
        conn.close()
        return {"status": "success", "message": "Password updated successfully"}
    except HTTPException as he:
        raise he
    except Exception as e:
        logger.error(f"DATABASE ERROR: {str(e)}")
        raise HTTPException(status_code=500, detail="Internal Server Error")

@app.get("/logs")
def get_logs(type: str = "all", limit: Optional[str] = "50", token: str = Depends(oauth2_scheme)):
    return {"status": "success", "data": "Logs will be here"}

@app.get("/test-waf")
async def test_waf():
    return {"status": "If you see this, the WAF failed to stop the attack."}

@app.get("/")
def home():
    return {"status": "normal request passed"}

@app.get("/history")
async def get_history(page: int = 1, size: int = 15, q: str = None, token: str = Depends(oauth2_scheme)):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        role = payload.get("role")
        
        if role not in ["super_admin", "analyst"]:
             raise HTTPException(status_code=403, detail="Access Denied")

        file_path = os.path.join(BASE_DIR, "aisentinel_raw_data.jsonl")
        all_logs = []
        
        if os.path.exists(file_path):
            with open(file_path, "r", encoding="utf-8") as f:
                for line in f:
                    if line.strip():
                        log_entry = json.loads(line)
                        
                        if q:
                            q_lower = q.lower().strip()
                            ip = str(log_entry.get("source_ip", "")).lower()
                            status = str(log_entry.get("status", "")).lower()
                            attack_type = str(log_entry.get("sub_type", "")).lower()
                            
                            if q_lower == "normal":
                                if status not in ["attack", "blocked", "fail"] and "attack" not in ip and "attack" not in attack_type:
                                    if not any(x in attack_type for x in ["sqli", "xss", "lfi", "rce", "injection"]):
                                        all_logs.append(log_entry)
                                    
                            elif q_lower == "attack":
                                if status in ["attack", "blocked", "fail"] or any(x in attack_type for x in ["sqli", "xss", "lfi", "rce", "injection"]):
                                    all_logs.append(log_entry)
                                    
                            else:
                                if q_lower in ip or q_lower in attack_type:
                                    all_logs.append(log_entry)
                        else:
                            all_logs.append(log_entry)
        
        all_logs.reverse()
        total_count = len(all_logs)
        total_pages = (total_count // size) + (1 if total_count % size > 0 else 0)
        
        start = (page - 1) * size
        end = start + size
        
        return {
            "logs": all_logs[start:end],
            "total_pages": total_pages
        }
    except Exception as e:
        print(f"DEBUG ERROR: {e}")
        return {"logs": [], "total_pages": 1}

@app.get("/api/logs")
async def get_logs_api(token: str = Depends(oauth2_scheme)):
    logs = []
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        file_path = os.path.join(BASE_DIR, "aisentinel_raw_data.jsonl")
        if not os.path.exists(file_path):
            return [] 
            
        with open(file_path, 'r', encoding='utf-8') as f:
            for line in f:
                if line.strip():
                    logs.append(json.loads(line))
        
        return logs
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/upload-logs")
async def upload_and_analyze_logs(file: UploadFile = File(...), token: str = Depends(oauth2_scheme)):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        contents = await file.read()
        text_data = contents.decode("utf-8", errors="ignore")
        
        def process_raw_csv_logs():
            analyzed_records = []
            threat_count = 0
            total_lines = 0
            csv_file = io.StringIO(text_data)
            
            try:
                reader = csv.DictReader(csv_file)
            except:
                reader = csv.reader(csv_file)
            
            for row in reader:
                total_lines += 1
                if isinstance(row, dict):
                    ip = row.get("source_ip") or row.get("ip") or "unknown"
                    request_content = row.get("request") or row.get("body") or str(list(row.values())[0])
                    status_c = int(row.get("status_code", 200))
                    size_r = int(row.get("response_size", 0))
                    ua = row.get("user_agent", "Mozilla/5.0")
                    ref = row.get("referrer", "-")
                    method = row.get("http_method") or row.get("method") or "GET"
                else:
                    ip = row[0] if len(row) > 0 else "unknown"
                    request_content = row[3] if len(row) > 3 else str(row)
                    status_c, size_r, ua, ref, method = 200, 0, "Mozilla/5.0", "-", "GET"

                request_clean = request_content.strip()

                log_payload = {
                    "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "source_ip": ip,
                    "request": request_clean,
                    "request_url": request_clean,
                    "query_parameters": request_clean.split("?")[1] if "?" in request_clean else "",
                    "body": "",
                    "http_method": method,
                    "status_code": status_c,
                    "response_size": size_r,
                    "user_agent": ua,
                    "referrer": ref
                }

                result = pipeline.run(log_payload)
                pipeline_status = result.get("status", "normal")
                pipeline_sub_type = result.get("sub_type", "None")
                pipeline_stages = result.get("stages", [])

                is_attack = pipeline_status in ["attack", "blocked", "fail"]
                sub_type = pipeline_sub_type if is_attack else "None"
                stage = " | ".join(pipeline_stages) if pipeline_stages else "WAF Filter"

                if is_attack:
                    threat_count += 1

                analyzed_records.append({
                    "ip": ip,
                    "request": request_clean,
                    "status": "attack" if is_attack else "normal",
                    "sub_type": sub_type if is_attack else "-",
                    "stage": stage
                })
            
            return {
                "status": "success",
                "summary": {
                    "total_lines": total_lines,
                    "threats_detected": threat_count
                },
                "results": analyzed_records
            }

        final_result = await run_in_threadpool(process_raw_csv_logs)
        return final_result

    except Exception as e:
        logger.error(f"Bulk Analysis Error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    uvicorn.run(combined_app, host="0.0.0.0", port=8000)


# from fastapi import FastAPI, Depends, HTTPException, Request
# from fastapi.middleware.cors import CORSMiddleware
# from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
# from fastapi.responses import JSONResponse
# from jose import jwt
# from pwdlib import PasswordHash
# from pydantic import BaseModel
# from datetime import datetime, timedelta
# from typing import Optional
# from datetime import timezone
# import sqlite3
# import uvicorn
# import logging
# import csv
# import io
# import os
# import time
# import socketio
# import pandas as pd
# import json

# from core.redis_client import redis_client as r
# from anomaly.inference_pipeline import InferencePipeline
# from security.security_pipeline import SecurityPipeline
# from threat.inference_pipeline_td import ThreatInferencePipeline
# from fastapi import UploadFile, File
# from starlette.concurrency import run_in_threadpool

# BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# DB_PATH = os.path.join(BASE_DIR, "users.db")

# app = FastAPI()

# # =========================================================
# # Socket.io Setup
# # =========================================================
# sio = socketio.AsyncServer(
#     async_mode='asgi',
#     cors_allowed_origins='*',
#     logger=True, 
#     engineio_logger=True
# )
# app_sio = socketio.ASGIApp(sio)
# combined_app = socketio.ASGIApp(
#     socketio_server=sio, 
#     other_asgi_app=app,
#      )

# # =========================================================
# # 2. CORS Middleware 
# # =========================================================
# app.add_middleware(
#     CORSMiddleware,
#     allow_origins=["*"], 
#     allow_credentials=True,
#     allow_methods=["*"],
#     allow_headers=["*"],
# )

# # =========================================================
# # Logging (Professional)
# # =========================================================
# logging.basicConfig(
#     level=logging.INFO,
#     format="%(asctime)s - %(levelname)s - %(message)s",
#     handlers=[
#         # delay=False تضمن الكتابة في الملف فوراً دون انتظار
#         logging.FileHandler("aisentinel.log", mode="a", delay=False), 
#         logging.StreamHandler() 
#     ]
# )
# logger = logging.getLogger(__name__)
# # =========================================================
# # Helper Function to Save Logs in JSONL Format
# # =========================================================
# def save_log_to_jsonl(log_entry, result):
#     try:
#         file_path = os.path.join(BASE_DIR, "aisentinel_raw_data.jsonl")
        
#         data_to_save = {
#             "@timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
#             "source_ip": log_entry.get("source_ip"),
#             "request_url": log_entry.get("request_url"),
#             "stages": result.get("stages", []),
#             "sub_type": result.get("sub_type", "None"),
#             "anomaly_score": result.get("anomaly_score", 0.0),
#             "status": result.get("status")
#         }
        
#         with open(file_path, "a", encoding="utf-8") as f:
#             f.write(json.dumps(data_to_save) + "\n")

#         import asyncio
#         asyncio.run_coroutine_threadsafe(
#             sio.emit('security_update_live', data_to_save), 
#             loop=asyncio.get_event_loop()
#         )
#     except Exception as e:
#         logger.error(f"Error saving JSONL log: {e}")
# # =========================================================
# # App Initialization
# # =========================================================
# anomaly_model = InferencePipeline()
# threat_model = ThreatInferencePipeline()
# pipeline = SecurityPipeline( anomaly_model=anomaly_model, threat_model=threat_model )
# password_hasher = PasswordHash.recommended()

# # =========================================================
# # Middleware (WAF Layer)
# # =========================================================
# @app.middleware("http")
# async def security_middleware(request: Request, call_next):
#     # --- IP extraction (proxy-safe) ---
#     client_ip = request.headers.get("x-forwarded-for", request.client.host)
#     path = request.url.path
#     if path.startswith("/socket.io") or path == "/login":
#         return await call_next(request)
    
#     allowed_paths = ["/login", "/change-password", "/docs", "/openapi.json", "/socket.io"]
    
#     is_static = any(path.endswith(ext) for ext in [".ico", ".png", ".jpg", ".css", ".js"])
#     is_allowed = path in allowed_paths or path.startswith("/users")

#     if is_allowed or is_static:
#         return await call_next(request)
    
#         # blocked IP
#     if r and r.exists(f"block:{client_ip}"):
#         return JSONResponse(status_code=403, content={"detail": "Blocked"})

#     body_bytes = await request.body()
#     body_str = body_bytes.decode('utf-8', errors='ignore') if body_bytes else ""

#     if client_ip == "127.0.0.1":
#         return await call_next(request) 

#     async def receive():
#         return {"type": "http.request", "body": body_bytes}

#     request._receive = receive

#     # --- Build log entry ---
#     log_entry = {
#         "source_ip": client_ip,
#         "request_url": str(request.url),
#         "query_params": str(request.query_params),
#         "body": body_str,
#         "headers": dict(request.headers),
#         "method": request.method
#     }

#     logger.info(f"WAF Check | IP={client_ip} | PATH={path}")

#     # --- Run pipeline ---
#     result = pipeline.run(log_entry)

#     # Storing logs in JSONL format for the history endpoint
#     try:
#         save_log_to_jsonl(log_entry, result)
#     except:
#         pass 

#     if result["status"] == "blocked":
#         return JSONResponse(
#             status_code=403,
#             content={
#                 "detail": f"Security Alert: {result['reason']}",
#                 "severity": result["severity"],
#                 "type": result.get("sub_type")
#             }
#         )

#     return await call_next(request)

# # =========================================================
# # Secrets & Auth Setup
# # =========================================================
# # SECRET_KEY = os.getenv("SECRET_KEY", "fallback_secret")

# SECRET_KEY = "AISENTINEL_SUPER_SECRET_KEY_2026"
# ALGORITHM = "HS256"

# ACCESS_TOKEN_EXPIRE_MINUTES = 60
# FILE_PATH = os.path.join(BASE_DIR, "aisentinel_raw_data.jsonl")
# oauth2_scheme = OAuth2PasswordBearer(tokenUrl="login")

# class PasswordChangeRequest(BaseModel):
#     new_password: str

# class UserCreateRequest(BaseModel):
#     username: str
#     role: str

# # --- Database Setup ---
# def init_db():
#     conn = sqlite3.connect(DB_PATH)
#     cursor = conn.cursor()
#     cursor.execute('''CREATE TABLE IF NOT EXISTS users 
#                       (username TEXT PRIMARY KEY, hashed_password TEXT, role TEXT, must_change_password INTEGER)''')
#     temp_pass = password_hasher.hash("temp123")
#     users = [('admin_boss', temp_pass, 'super_admin', 1)]
#     for u in users:
#         cursor.execute("INSERT OR IGNORE INTO users VALUES (?, ?, ?, ?)", u)
#     conn.commit()
#     conn.close()

# init_db()

# # --- Auth Functions ---
# def create_access_token(data: dict):
#     to_encode = data.copy()
#     # expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
#     expire = datetime.now(timezone.utc) + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
#     to_encode.update({"exp": expire})
#     return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

# # -----------------------------------------------------------------------
# # Routes
# # -----------------------------------------------------------------------
# @app.post("/predict")
# async def predict_endpoint(log: dict):
#     try:
#         result = pipeline.run(log)
#     except Exception as e:
#         logger.error(f"Pipeline Error: {e}")
#         result = {"status": "error", "stages": ["Failed"], "sub_type": "None", "anomaly_score": 0.0, "reason": str(e)}

#     save_log_to_jsonl(log, result)

#     log_file = os.path.join(BASE_DIR, "security_detections.csv")
#     file_exists = os.path.isfile(log_file)

#     try:
#         with open(log_file, mode='a', newline='', encoding='utf-8') as f:
#             writer = csv.writer(f)
#             if not file_exists:
#                 writer.writerow(['Timestamp', 'IP', 'Request', 'Stage', 'Threat_Type', 'Anomaly_Score', 'Final_Status'])
            
#             writer.writerow([
#                 time.strftime("%Y-%m-%d %H:%M:%S"),
#                 log.get("source_ip") or log.get("ip") or "unknown",
#                 log.get("request_url") or log.get("url") or "/",
#                 " | ".join(result.get("stages", [])),
#                 result.get("sub_type"),
#                 result.get("anomaly_score"),
#                 result.get("status")
#             ])
#     except Exception as e:
#         logger.error(f"[ERROR] Failed to write CSV: {e}")

#     return result

# @app.post("/login")
# def login(form_data: OAuth2PasswordRequestForm = Depends()):
#     conn = sqlite3.connect(DB_PATH)
#     cursor = conn.cursor()
#     cursor.execute("SELECT hashed_password, role, must_change_password FROM users WHERE username = ?", (form_data.username,))
#     user = cursor.fetchone()
#     conn.close()

#     if not user or not password_hasher.verify(form_data.password, user[0]):
#         raise HTTPException(status_code=401, detail="Incorrect username or password")

#     access_token = create_access_token(data={"sub": form_data.username, "role": user[1]})
#     return {"access_token": access_token, "token_type": "bearer", "role": user[1], "username": form_data.username, "must_change_password": bool(user[2])}


# @app.post("/users")
# def create_user(request: UserCreateRequest, token: str = Depends(oauth2_scheme)):
#     payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
#     admin_role = payload.get("role")
    
#     if admin_role != "super_admin":
#         raise HTTPException(status_code=403, detail="Only Super Admins can create users")

#     temp_password = password_hasher.hash("temp123") 
    
#     try:
#         conn = sqlite3.connect(DB_PATH)
#         cursor = conn.cursor()
#         cursor.execute("INSERT INTO users (username, hashed_password, role, must_change_password) VALUES (?, ?, ?, ?)", 
#                        (request.username, temp_password, request.role, 1))
#         conn.commit()
#         conn.close()
#         return {"status": "success", "message": f"User {request.username} created successfully"}
#     except sqlite3.IntegrityError:
#         raise HTTPException(status_code=400, detail="Username already exists")
#     except Exception as e:
#         logger.error(f"Error creating user: {e}")
#         raise HTTPException(status_code=500, detail="Internal Server Error")

# @app.get("/users")
# def get_all_users(token: str = Depends(oauth2_scheme)):
#     try:
#         jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
#     except:
#         raise HTTPException(status_code=401, detail="Invalid token")

#     conn = sqlite3.connect(DB_PATH)
#     cursor = conn.cursor()
#     cursor.execute("SELECT username, role, must_change_password FROM users")
#     user_list = cursor.fetchall()
#     conn.close()

#     return [{"username": u[0], "role": u[1], "must_change": bool(u[2])} for u in user_list]

# @app.delete("/users/{username}")
# def delete_user(username: str, token: str = Depends(oauth2_scheme)):
#     try:
#         payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
#         if payload.get("role") != "super_admin":
#             raise HTTPException(status_code=403, detail="Forbidden: Admins only")

#         conn = sqlite3.connect(DB_PATH)
#         cursor = conn.cursor()
        
#         cursor.execute("DELETE FROM users WHERE username = ?", (username,))
#         conn.commit()
        
#         if cursor.rowcount == 0:
#             conn.close()
#             raise HTTPException(status_code=404, detail="User not found")
            
#         conn.close()
#         return {"status": "success", "message": f"User {username} deleted"}
        
#     except Exception as e:
#         raise HTTPException(status_code=500, detail=str(e))
    

# @app.post("/change-password")
# def change_password(request: PasswordChangeRequest, token: str = Depends(oauth2_scheme)):
#     try:
#         payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
#         username = payload.get("sub")
        
#         conn = sqlite3.connect(DB_PATH)
#         cursor = conn.cursor()

#         cursor.execute("SELECT hashed_password, username FROM users")
#         all_users = cursor.fetchall()
#         for hashed_pass, user_owner in all_users:
#             if password_hasher.verify(request.new_password, hashed_pass):
#                 conn.close()
#                 raise HTTPException(
#                     status_code=400, 
#                     detail="Security Policy Violation: Please choose a different password."
#                 )
             
#         new_hashed_password = password_hasher.hash(request.new_password)
        
#         cursor.execute("UPDATE users SET hashed_password = ?, must_change_password = 0 WHERE username = ?", 
#                        (new_hashed_password, username))
#         conn.commit()
#         conn.close()
#         return {"status": "success", "message": "Password updated successfully"}
#     except HTTPException as he:
#         raise he
    
#     except Exception as e:
#         logger.error(f"DATABASE ERROR: {str(e)}")
#         raise HTTPException(status_code=500, detail="Internal Server Error")

    

# @app.get("/logs")
# def get_logs(type: str = "all", limit: Optional[str] = "50", token: str = Depends(oauth2_scheme)):
#     return {"status": "success", "data": "Logs will be here"}

# @app.get("/test-waf")
# async def test_waf():
#     return {"status": "If you see this, the WAF failed to stop the attack."}

# @app.get("/")
# def home():
#     return {"status": "normal request passed"}

# @app.get("/history")
# async def get_history(page: int = 1, size: int = 15, q: str = None, token: str = Depends(oauth2_scheme)):
#     try:
#         payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
#         role = payload.get("role")
        
#         if role not in ["super_admin", "analyst"]:
#              raise HTTPException(status_code=403, detail="Access Denied")

#         file_path = os.path.join(BASE_DIR, "aisentinel_raw_data.jsonl")
#         all_logs = []
        
#         if os.path.exists(file_path):
#             with open(file_path, "r", encoding="utf-8") as f:
#                 for line in f:
#                     if line.strip():
#                         log_entry = json.loads(line)
                        
#                         if q:
#                             q_lower = q.lower().strip()
#                             ip = str(log_entry.get("source_ip", "")).lower()
#                             status = str(log_entry.get("status", "")).lower()
#                             attack_type = str(log_entry.get("sub_type", "")).lower()
                            
#                             if q_lower == "normal":
#                                 if status not in ["attack", "blocked", "fail"] and "attack" not in ip and "attack" not in attack_type:
#                                     if not any(x in attack_type for x in ["sqli", "xss", "lfi", "rce", "injection"]):
#                                         all_logs.append(log_entry)
                                    
#                             elif q_lower == "attack":
#                                 if status in ["attack", "blocked", "fail"] or any(x in attack_type for x in ["sqli", "xss", "lfi", "rce", "injection"]):
#                                     all_logs.append(log_entry)
                                    
#                             else:
#                                 if q_lower in ip or q_lower in attack_type:
#                                     all_logs.append(log_entry)
#                         else:
#                             all_logs.append(log_entry)
        
#         all_logs.reverse()
#         total_count = len(all_logs)
#         total_pages = (total_count // size) + (1 if total_count % size > 0 else 0)
        
#         start = (page - 1) * size
#         end = start + size
        
#         return {
#             "logs": all_logs[start:end],
#             "total_pages": total_pages
#         }
#     except Exception as e:
#         print(f"DEBUG ERROR: {e}")
#         return {"logs": [], "total_pages": 1}

# @app.get("/api/logs")
# async def get_logs(token: str = Depends(oauth2_scheme)):
#     logs = []
#     try:
#         payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])

#         file_path = os.path.join(BASE_DIR, "aisentinel_raw_data.jsonl")
#         if not os.path.exists(file_path):
#             return [] 
            
#         with open(file_path, 'r', encoding='utf-8') as f:
#             for line in f:
#                 if line.strip():
#                     logs.append(json.loads(line))
        
#         return logs
#     except Exception as e:
#         raise HTTPException(status_code=500, detail=str(e))

# @app.post("/api/upload-logs")
# async def upload_and_analyze_logs(file: UploadFile = File(...), token: str = Depends(oauth2_scheme)):
#     try:
#         payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        
#         contents = await file.read()
#         text_data = contents.decode("utf-8", errors="ignore")
        
#         def process_raw_csv_logs():
#             analyzed_records = []
#             threat_count = 0
#             total_lines = 0
            
#             csv_file = io.StringIO(text_data)
            
#             try:
#                 reader = csv.DictReader(csv_file)
#             except:
#                 reader = csv.reader(csv_file)
            
#             for row in reader:
#                 total_lines += 1
                
#                 if isinstance(row, dict):
#                     ip = row.get("ip") or row.get("source_ip") or "unknown"
#                     request_content = row.get("request") or row.get("body") or str(list(row.values())[0])
#                 else:
#                     ip = row[0] if len(row) > 0 else "unknown"
#                     request_content = row[3] if len(row) > 3 else str(row)

#                 request_clean = request_content.strip()

#                 result = pipeline.run({"body": request_clean, "source_ip": ip, "request_url": request_clean})
                
#                 pipeline_status = result.get("status", "normal")
#                 pipeline_sub_type = result.get("sub_type", "None")
#                 pipeline_stages = result.get("stages", [])

#                 is_attack = pipeline_status in ["attack", "blocked", "fail"]
                
#                 sub_type = pipeline_sub_type if is_attack else "None"
#                 stage = " | ".join(pipeline_stages) if pipeline_stages else ("Threat Engine" if is_attack else "WAF Filter")

#                 if is_attack:
#                     threat_count += 1

#                 analyzed_records.append({
#                     "ip": ip,
#                     "request": request_clean,
#                     "status": "attack" if is_attack else "normal",
#                     "sub_type": sub_type if is_attack else "-",
#                     "stage": stage
#                 })
            
#             return {
#                 "status": "success",
#                 "summary": {
#                     "total_lines": total_lines,
#                     "threats_detected": threat_count
#                 },
#                 "results": analyzed_records
#             }

#         final_result = await run_in_threadpool(process_raw_csv_logs)
#         return final_result

#     except Exception as e:
#         logger.error(f"Bulk Analysis Error: {e}")
#         raise HTTPException(status_code=500, detail=str(e))
# if __name__ == "__main__":
#     uvicorn.run(combined_app, host="0.0.0.0", port=8000)


























# @app.post("/predict")
# async def predict_endpoint(log: dict):

#     normalized_log = {
#         "source_ip": log.get("ip") or log.get("source_ip") or "unknown",
#         "request_url": log.get("request") or log.get("request_url") or "/",
#         "headers": log.get("headers") if isinstance(log.get("headers"), dict) else {
#             "user-agent": log.get("browser", "unknown"),
#             "referer": log.get("referer", "Unknown")
#         },
#         "method": log.get("method", "POST")
#     }

#     # result = pipeline.run(normalized_log)

#     #*********************
#     # التعديل الوحيد: تأمين تشغيل الموديل
#     try:
#         result = pipeline.run(normalized_log)
#     except Exception as e:
#         logger.error(f"Pipeline Error: {e}")
#         # رد افتراضي في حالة فشل الـ Preprocessing عشان الكود اللي تحت مبيوظش
#         result = {"status": "error", "stages": ["Failed"], "sub_type": "None", "anomaly_score": 0.0}

#     print(f"DEBUG RESULT: {result}")
#     #**********************

#     # التخزين الموحد في JSONL
#     save_log_to_jsonl(normalized_log, result)
#     # =============================
#     # CSV Logging
#     # =============================
#     base_path = r"C:\AiSentinel"
#     log_file = os.path.join(base_path, "security_detections.csv")
#     file_exists = os.path.isfile(log_file)

#     try:
#         with open(log_file, mode='a', newline='', encoding='utf-8') as f:
#             writer = csv.writer(f)

#             if not file_exists:
#                 writer.writerow([
#                     'Timestamp',
#                     'IP',
#                     'Request',
#                     'Stage',
#                     'Threat_Type',
#                     'Anomaly_Score',
#                     'Final_Status'
#                 ])

#             writer.writerow([
#                 time.strftime("%Y-%m-%d %H:%M:%S"),
#                 normalized_log["source_ip"],
#                 normalized_log["request_url"],
#                 " | ".join(result.get("stages", [])),
#                 result.get("sub_type"),
#                 result.get("anomaly_score"),
#                 result.get("status")
#             ])
#             f.flush() # إجبار الويندوز على الكتابة حالاً
#     except Exception as e:
#         logger.error(f"[ERROR] Failed to write CSV: {e}")
#     # =============================
#     # Terminal Output
#     # =============================
#     stages_str = " -> ".join(result.get("stages", ["Start"]))
#     logger.info(
#         f"[DETECTION] IP: {normalized_log['source_ip']} | "
#         f"Path: {stages_str} | "
#         f"Verdict: {result.get('status').upper()} | "
#         f"Score: {result.get('anomaly_score', 0.0)}"
#     )

#     return result