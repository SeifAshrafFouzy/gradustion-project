import React from 'react';
import { ArrowLeft, UploadCloud, FileText, ShieldAlert, Loader2, Play } from 'lucide-react';

const LogAnalyzer = ({ onBack, file, setFile, loading, setLoading, analytics, setAnalytics }) => {

  const handleFileChange = (e) => {
    if (loading) return;
    const selectedFile = e.target.files[0];
    if (selectedFile) setFile(selectedFile);
  };

  const handleUpload = async () => {
    if (!file) return alert("Please select a file first!");
    setLoading(true);
    setAnalytics(null);

    const token = localStorage.getItem('token');
    const formData = new FormData();
    formData.append('file', file);

    try {
      const response = await fetch('http://localhost:8000/api/upload-logs', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` },
        body: formData
      });
      const result = await response.json();
      if (result.status === 'success') {
        setAnalytics(result);
      } else {
        alert("Analysis failed.");
      }
    } catch (error) {
      console.error(error);
      alert("Error contacting server.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen p-2 text-gray-900 dark:text-white transition-colors duration-300">
      <div className="max-w-7xl mx-auto pb-10">
        
        {/* --- Header --- */}
        <header className="mb-16">
          <div className="flex items-center gap-6 mb-4">
             <button 
               onClick={onBack} 
               className="p-3 bg-white dark:bg-[#0f172a] border border-gray-200 dark:border-white/5 hover:border-blue-500/50 rounded-2xl transition-all duration-300 text-blue-500 shadow-xl group"
             >
               <ArrowLeft size={24} className="group-hover:-translate-x-1 transition-transform text-blue-500" />
             </button>
             <div>
                <h1 className="text-4xl font-black uppercase tracking-tighter flex items-center gap-3">
                  <span className="bg-gradient-to-r from-blue-600 to-blue-400 bg-clip-text text-transparent">Logs</span> Analyzer
                </h1>
                <div className="h-1 w-20 bg-blue-600 mt-2 rounded-full shadow-[0_0_10px_#2563eb]"></div>
              </div>
            </div>
             {/* <div>
               <h1 className="text-4xl md:text-5xl font-black text-slate-900 dark:text-white uppercase tracking-tighter flex items-center gap-4">
                 <span className="bg-gradient-to-r from-blue-600 to-blue-400 bg-clip-text text-transparent">
                   Log
                 </span> 
                 Analyzer
               </h1>
               <div className="h-1 w-20 bg-blue-600 mt-2 rounded-full shadow-[0_0_10px_#2563eb]"></div>
             </div>
           </div> */}
         </header>
         {/* <header className="mb-16">
//           <div className="flex items-center gap-6 mb-4">
//             <button 
//               onClick={onBack} 
//               className="p-3 bg-white dark:bg-[#0f172a] border border-gray-200 dark:border-white/5 hover:border-blue-500/50 rounded-2xl transition-all duration-300 text-blue-500 shadow-xl group"
//             >
//               <ArrowLeft size={24} className="group-hover:-translate-x-1 transition-transform" />
//             </button>
//             <div>
//               <h1 className="text-4xl md:text-5xl font-black text-slate-900 dark:text-white uppercase tracking-tighter flex items-center gap-4">
//                 <span className="bg-gradient-to-r from-blue-500 to-purple-500 bg-clip-text text-transparent">
//                   Log
//                 </span> 
//                 Analyzer
//               </h1>
//               <div className="h-1 w-20 bg-gradient-to-r from-blue-500 to-purple-500 mt-2 rounded-full shadow-[0_0_10px_#2563eb]"></div>
//             </div>
//           </div>
//         </header> */}
        {/* --- Drag & Drop Zone --- */}
        <div className="bg-white dark:bg-[#0f172a] rounded-[2rem] border border-gray-200 dark:border-blue-900/20 p-8 shadow-2xl mb-8 transition-all">
          
          {loading ? (
            <div className="relative overflow-hidden bg-gradient-to-b from-blue-600/[0.03] to-transparent rounded-2xl p-12 flex flex-col items-center justify-center border border-blue-500/20 shadow-[0_0_50px_rgba(37,99,235,0.05)]">
              <div className="absolute -top-24 w-72 h-72 bg-blue-500/10 rounded-full blur-3xl animate-pulse"></div>
              <div className="relative flex items-center justify-center mb-6">
                <div className="absolute w-16 h-16 bg-blue-500/20 rounded-full animate-ping duration-1000"></div>
                <Loader2 size={56} className="text-blue-500 animate-spin relative z-10" />
              </div>
              <p className="text-base font-black text-blue-500 uppercase tracking-[0.25em] text-center">Background Inspection Active</p>
              <p className="text-xs text-slate-400 font-medium mt-2 text-center max-w-md leading-relaxed">
               AiSentinel is performing deep inspection on logs from <span className="text-blue-400 font-mono font-bold">"{file?.name}"</span> in real-time.
              </p>
            </div>
          ) : (
            <div className="border-2 border-dashed border-gray-300 dark:border-blue-500/20 rounded-2xl p-10 flex flex-col items-center justify-center relative group hover:border-blue-500/50 transition-colors">
              <input type="file" accept=".log,.csv" onChange={handleFileChange} className="absolute inset-0 opacity-0 cursor-pointer" />
              <UploadCloud size={48} className="text-blue-500 mb-4 group-hover:scale-110 transition-transform" />
              <p className="text-sm font-bold mb-1">Drag & Drop your server log or CSV file here</p>
              <p className="text-xs text-gray-400">Supports .log, .csv files only</p>
              {file && (
                <div className="mt-6 flex items-center gap-2 bg-blue-500/10 border border-blue-500/20 px-4 py-2 rounded-xl">
                  <FileText size={18} className="text-blue-400" />
                  <span className="text-xs font-mono font-bold text-blue-400">{file.name} ({(file.size/1024).toFixed(1)} KB)</span>
                </div>
              )}
            </div>
          )}

          {file && !analytics && (
            <button 
              onClick={handleUpload} 
              disabled={loading} 
              className="w-full mt-6 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-800 text-white py-4 rounded-xl font-bold transition-all shadow-lg shadow-blue-500/20 flex items-center justify-center gap-2 active:scale-[0.99]"
            >
              {loading ? (
                <> <Loader2 className="animate-spin" size={20} /> Inspecting Lines... </>
              ) : (
                <> <Play size={16} className="fill-current" /> Start Security Analysis </>
              )}
            </button>
          )}
        </div>

        {/* --- Dashboard Results Block --- */}
        {analytics && (
          <div className="animate-in fade-in zoom-in duration-300">
            {/* Smart Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              <div className="bg-white dark:bg-[#0f172a] border border-gray-200 dark:border-blue-900/20 rounded-2xl p-6 flex items-center gap-5 shadow-xl">
                <div className="p-4 bg-blue-500/10 rounded-xl text-blue-500"><FileText size={24} /></div>
                <div>
                  <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Total Lines Inspected</p>
                  <p className="text-3xl font-black">{analytics.summary.total_lines}</p>
                </div>
              </div>
              <div className="bg-white dark:bg-[#0f172a] border border-gray-200 dark:border-blue-900/20 rounded-2xl p-6 flex items-center gap-5 shadow-xl">
                <div className="p-4 bg-red-500/10 rounded-xl text-red-500 shadow-[0_0_15px_rgba(239,68,68,0.1)]"><ShieldAlert size={24} /></div>
                <div>
                  <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Threats Blocked</p>
                  <p className="text-3xl font-black text-red-500 drop-shadow-[0_0_10px_rgba(239,68,68,0.3)]">{analytics.summary.threats_detected}</p>
                </div>
              </div>
            </div>

             {/* Advanced Analysis Table */}
            <div className="bg-white dark:bg-[#0f172a] rounded-[2rem] border border-gray-200 dark:border-blue-900/20 overflow-hidden shadow-2xl w-full">
              <div className="p-6 border-b border-gray-100 dark:border-white/5 bg-gray-50/50 dark:bg-[#060a14]/30 flex justify-between items-center">
                <h3 className="font-black text-xs uppercase tracking-widest text-gray-400">Deep Inspection Matrix</h3>
                <button onClick={() => { setFile(null); setAnalytics(null); }} className="text-[10px] bg-blue-500/10 hover:bg-blue-500/20 text-blue-400 px-4 py-2 rounded-xl font-bold uppercase tracking-widest transition-colors border border-blue-500/10">
                  Clear & Analyze New File
                </button>
              </div>
              
              <div className="max-h-[55vh] overflow-y-auto w-full pr-1
                [&::-webkit-scrollbar]:w-1.5 
                [&::-webkit-scrollbar-track]:bg-transparent 
                [&::-webkit-scrollbar-thumb]:bg-gray-300 dark:[&::-webkit-scrollbar-thumb]:bg-blue-900/40 
                [&::-webkit-scrollbar-thumb]:rounded-full 
                hover:[&::-webkit-scrollbar-thumb]:bg-blue-500 transition-colors">
                
                <table className="w-full table-fixed text-left border-collapse">
                  <thead className="bg-gray-50 dark:bg-[#060a14]/80 text-gray-400 text-[10px] uppercase font-black tracking-[0.15em] border-b border-gray-100 dark:border-white/5 sticky top-0 z-10 backdrop-blur-md">
                    <tr>
                      <th className="w-[15%] px-6 py-4">IP Address</th>
                      <th className="w-[40%] px-6 py-4">Payload Content</th>
                      {/* 🚨 الترتيب الجديد المطور للأعمدة حسب رغبتك 🚨 */}
                      <th className="w-[12%] px-6 py-4 text-center">Status</th>
                      <th className="w-[18%] px-6 py-4">Attack Type</th>
                      <th className="w-[15%] px-6 py-4">Pipeline Stage</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100 dark:divide-white/5 font-mono text-[11px]">
                    {analytics.results.map((log, i) => {
                      const isAttack = log.status === 'attack';
                      return (
                        <tr key={i} className="hover:bg-blue-500/[0.02] transition duration-150">
                          <td className="px-6 py-4 font-bold font-sans tracking-tight text-slate-800 dark:text-slate-200 truncate">{log.ip}</td>
                          <td className="px-6 py-4 text-gray-400 truncate font-mono select-all" title={log.request}>{log.request}</td>
                          
                          {/* 1. الـ Status أولاً */}
                          <td className="px-6 py-4 text-center font-sans">
                            <span className={`px-2.5 py-1 rounded-md text-[9px] font-black tracking-wider border block w-full text-center ${
                              isAttack ? 'bg-red-500/10 text-red-500 border-red-500/20 shadow-[0_0_10px_rgba(239,68,68,0.05)]' : 'bg-green-500/10 text-green-500 border-green-500/20'
                            }`}>
                              {isAttack ? 'ATTACK' : 'NORMAL'}
                            </span>
                          </td>

                          {/* 2. الـ Attack Type */}
                          <td className="px-6 py-4">
                            <span className={isAttack ? 'text-red-400 font-extrabold tracking-wide uppercase text-[10px]' : 'text-slate-600 dark:text-slate-600 font-sans'}>
                              {log.sub_type}
                            </span>
                          </td>

                          {/* 3. الـ Pipeline Stage */}
                          <td className="px-6 py-4 text-slate-400 text-[11px] font-sans truncate" title={log.stage}>{log.stage}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default LogAnalyzer;
// *****************************
// import React from 'react';
// import { ArrowLeft, UploadCloud, FileText, ShieldAlert, Loader2, Play } from 'lucide-react';

// const LogAnalyzer = ({ onBack, file, setFile, loading, setLoading, analytics, setAnalytics }) => {

//   const handleFileChange = (e) => {
//     if (loading) return; 
//     const selectedFile = e.target.files[0];
//     if (selectedFile) setFile(selectedFile);
//   };

//   const handleUpload = async () => {
//     if (!file) return alert("Please select a file first!");
//     setLoading(true);
//     setAnalytics(null);

//     const token = localStorage.getItem('token');
//     const formData = new FormData();
//     formData.append('file', file);

//     try {
//       const response = await fetch('http://localhost:8000/api/upload-logs', {
//         method: 'POST',
//         headers: { 'Authorization': `Bearer ${token}` },
//         body: formData
//       });
//       const result = await response.json();
//       if (result.status === 'success') {
//         setAnalytics(result);
//       } else {
//         alert("Analysis failed.");
//       }
//     } catch (error) {
//       console.error(error);
//       alert("Error contacting server.");
//     } finally {
//       setLoading(false);
//     }
//   };

//   return (
//     <div className="min-h-screen p-2 text-gray-900 dark:text-white transition-colors duration-300">
//       <div className="max-w-6xl mx-auto pb-10">
        
//         {/* --- Header --- */}
//         <header className="mb-16">
//           <div className="flex items-center gap-6 mb-4">
//             <button 
//               onClick={onBack} 
//               className="p-3 bg-white dark:bg-[#0f172a] border border-gray-200 dark:border-white/5 hover:border-blue-500/50 rounded-2xl transition-all duration-300 text-blue-500 shadow-xl group"
//             >
//               <ArrowLeft size={24} className="group-hover:-translate-x-1 transition-transform text-blue-500" />
//             </button>
//             <div>
//               <h1 className="text-4xl md:text-5xl font-black text-slate-900 dark:text-white uppercase tracking-tighter flex items-center gap-4">
//                 <span className="bg-gradient-to-r from-blue-600 to-blue-400 bg-clip-text text-transparent">
//                   Log
//                 </span> 
//                 Analyzer
//               </h1>
//               <div className="h-1 w-20 bg-blue-600 mt-2 rounded-full shadow-[0_0_10px_#2563eb]"></div>
//             </div>
//           </div>
//         </header>
//         {/* <header className="mb-16">
//           <div className="flex items-center gap-6 mb-4">
//             <button 
//               onClick={onBack} 
//               className="p-3 bg-white dark:bg-[#0f172a] border border-gray-200 dark:border-white/5 hover:border-blue-500/50 rounded-2xl transition-all duration-300 text-blue-500 shadow-xl group"
//             >
//               <ArrowLeft size={24} className="group-hover:-translate-x-1 transition-transform" />
//             </button>
//             <div>
//               <h1 className="text-4xl md:text-5xl font-black text-slate-900 dark:text-white uppercase tracking-tighter flex items-center gap-4">
//                 <span className="bg-gradient-to-r from-blue-500 to-purple-500 bg-clip-text text-transparent">
//                   Log
//                 </span> 
//                 Analyzer
//               </h1>
//               <div className="h-1 w-20 bg-gradient-to-r from-blue-500 to-purple-500 mt-2 rounded-full shadow-[0_0_10px_#2563eb]"></div>
//             </div>
//           </div>
//         </header> */}

//         {/* --- Drag & Drop Zone --- */}
//         <div className="bg-white dark:bg-[#0f172a] rounded-[2rem] border border-gray-200 dark:border-blue-900/20 p-8 shadow-2xl mb-8 transition-all">
          
//           {loading ? (
//             <div className="border-2 border-dashed border-blue-500/30 bg-blue-500/5 rounded-2xl p-10 flex flex-col items-center justify-center animate-pulse">
//               <Loader2 size={48} className="text-blue-500 animate-spin mb-4" />
//               <p className="text-sm font-black text-blue-500 uppercase tracking-widest">Background Inspection Active</p>
//               <p className="text-xs text-gray-400 mt-1">AiSentinel is deep-scanning "{file?.name}" in a background thread...</p>
//             </div>
//           ) : (
//             <div className="border-2 border-dashed border-gray-300 dark:border-blue-500/20 rounded-2xl p-10 flex flex-col items-center justify-center relative group hover:border-blue-500/50 transition-colors">
//               <input type="file" accept=".log,.csv" onChange={handleFileChange} className="absolute inset-0 opacity-0 cursor-pointer" />
//               <UploadCloud size={48} className="text-blue-500 mb-4 group-hover:scale-110 transition-transform" />
//               <p className="text-sm font-bold mb-1">Drag & Drop your server log or CSV file here</p>
//               <p className="text-xs text-gray-400">Supports .log, .csv files only</p>
//               {file && (
//                 <div className="mt-6 flex items-center gap-2 bg-blue-500/10 border border-blue-500/20 px-4 py-2 rounded-xl">
//                   <FileText size={18} className="text-blue-400" />
//                   <span className="text-xs font-mono font-bold text-blue-400">{file.name} ({(file.size/1024).toFixed(1)} KB)</span>
//                 </div>
//               )}
//             </div>
//           )}

//           {file && !analytics && (
//             <button 
//               onClick={handleUpload} 
//               disabled={loading} 
//               className="w-full mt-6 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-800 text-white py-4 rounded-xl font-bold transition-all shadow-lg shadow-blue-500/20 flex items-center justify-center gap-2 active:scale-[0.99]"
//             >
//               {loading ? (
//                 <> <Loader2 className="animate-spin" size={20} /> Inspecting Lines... </>
//               ) : (
//                 <> <Play size={16} className="fill-current" /> Start Security Analysis </>
//               )}
//             </button>
//           )}
//         </div>

//         {/* --- Dashboard Results Block --- */}
//         {analytics && (
//           <div className="animate-in fade-in zoom-in duration-300">
//             {/* 📈 Smart Cards */}
//             <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
//               <div className="bg-white dark:bg-[#0f172a] border border-gray-200 dark:border-blue-900/20 rounded-2xl p-6 flex items-center gap-5 shadow-xl">
//                 <div className="p-4 bg-blue-500/10 rounded-xl text-blue-500"><FileText size={24} /></div>
//                 <div>
//                   <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Total Lines Inspected</p>
//                   <p className="text-3xl font-black">{analytics.summary.total_lines}</p>
//                 </div>
//               </div>
//               <div className="bg-white dark:bg-[#0f172a] border border-gray-200 dark:border-blue-900/20 rounded-2xl p-6 flex items-center gap-5 shadow-xl">
//                 <div className="p-4 bg-red-500/10 rounded-xl text-red-500 shadow-[0_0_15px_rgba(239,68,68,0.1)]"><ShieldAlert size={24} /></div>
//                 <div>
//                   <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Threats Blocked</p>
//                   <p className="text-3xl font-black text-red-500 drop-shadow-[0_0_10px_rgba(239,68,68,0.3)]">{analytics.summary.threats_detected}</p>
//                 </div>
//               </div>
//             </div>

//             {/* 📋 Advanced Analysis Table */}
//             <div className="bg-white dark:bg-[#0f172a] rounded-[2rem] border border-gray-200 dark:border-blue-900/20 overflow-hidden shadow-2xl">
//               <div className="p-6 border-b border-gray-100 dark:border-white/5 bg-gray-50/50 dark:bg-[#060a14]/30 flex justify-between items-center">
//                 <h3 className="font-black text-xs uppercase tracking-widest text-gray-400">Deep Inspection Matrix</h3>
//                 <button onClick={() => { setFile(null); setAnalytics(null); }} className="text-[10px] bg-blue-500/10 hover:bg-blue-500/20 text-blue-400 px-3 py-1.5 rounded-xl font-bold uppercase tracking-widest transition-colors">
//                   Clear & Analyze New File
//                 </button>
//               </div>
//               <div className="overflow-x-auto max-h-[50vh] custom-scrollbar">
//                 <table className="w-full text-left">
//                   <thead className="bg-gray-50 dark:bg-[#060a14]/50 text-gray-400 text-[10px] uppercase font-black tracking-[0.2em] border-b border-gray-100 dark:border-white/5 sticky top-0 z-10">
//                     <tr>
//                       <th className="px-7 py-4">IP Address</th>
//                       <th className="px-7 py-4">Payload/Payload Target</th>
//                       <th className="px-7 py-4">Attack Type</th>
//                       <th className="px-7 py-4">Pipeline Stage</th>
//                       <th className="px-7 py-4 text-center">Status</th>
//                     </tr>
//                   </thead>
//                   <tbody className="divide-y divide-gray-100 dark:divide-white/5 font-mono text-xs">
//                     {analytics.results.map((log, i) => {
//                       const isAttack = log.status === 'attack';
//                       return (
//                         <tr key={i} className="hover:bg-blue-500/[0.02] transition duration-150">
//                           <td className="px-7 py-4 font-bold font-sans">{log.ip}</td>
//                           <td className="px-7 py-4 max-w-xs truncate text-gray-400" title={log.request}>{log.request}</td>
//                           <td className="px-7 py-4"><span className={isAttack ? 'text-red-400 font-bold' : 'text-gray-500'}>{log.sub_type}</span></td>
//                           <td className="px-7 py-4 text-gray-400 text-[11px]">{log.stage}</td>
//                           <td className="px-7 py-4 text-center">
//                             <span className={`px-3 py-1 rounded-lg text-[9px] font-black tracking-widest border ${
//                               isAttack ? 'bg-red-500/10 text-red-500 border-red-500/20' : 'bg-green-500/10 text-green-500 border-green-500/20'
//                             }`}>
//                               {isAttack ? 'ATTACK' : 'NORMAL'}
//                             </span>
//                           </td>
//                         </tr>
//                       );
//                     })}
//                   </tbody>
//                 </table>
//               </div>
//             </div>
//           </div>
//         )}
//       </div>
//     </div>
//   );
// };

// export default LogAnalyzer;


// ***************************************
// import React, { useState } from 'react';
// import { ArrowLeft, UploadCloud, FileText, ShieldAlert, Loader2, RefreshCw, Play } from 'lucide-react';

// const LogAnalyzer = ({ onBack }) => {
//   const [file, setFile] = useState(null);
//   const [loading, setLoading] = useState(false);
//   const [analytics, setAnalytics] = useState(null);

//   const handleFileChange = (e) => {
//     const selectedFile = e.target.files[0];
//     if (selectedFile) setFile(selectedFile);
//   };

//   const handleUpload = async () => {
//     if (!file) return alert("Please select a file first!");
//     setLoading(true);
//     setAnalytics(null);

//     const token = localStorage.getItem('token');
//     const formData = new FormData();
//     formData.append('file', file);

//     try {
//       const response = await fetch('http://localhost:8000/api/upload-logs', {
//         method: 'POST',
//         headers: { 'Authorization': `Bearer ${token}` },
//         body: formData
//       });
//       const result = await response.json();
//       if (result.status === 'success') {
//         setAnalytics(result);
//       } else {
//         alert("Analysis failed.");
//       }
//     } catch (error) {
//       console.error(error);
//       alert("Error contacting server.");
//     } finally {
//       setLoading(false);
//     }
//   };

//   return (
//     <div className="min-h-screen p-2 text-gray-900 dark:text-white transition-colors duration-300">
//       <div className="max-w-6xl mx-auto pb-10">
//         {/* --- Header --- */}
//         <header className="mb-16">
//           <div className="flex items-center gap-6 mb-4">
//             <button 
//               onClick={onBack} 
//               className="p-3 bg-white dark:bg-[#0f172a] border border-gray-200 dark:border-white/5 hover:border-blue-500/50 rounded-2xl transition-all duration-300 text-blue-500 shadow-xl group"
//             >
//               <ArrowLeft size={24} className="group-hover:-translate-x-1 transition-transform" />
//             </button>
//             <div>
//               <h1 className="text-4xl md:text-5xl font-black text-slate-900 dark:text-white uppercase tracking-tighter flex items-center gap-4">
//                 <span className="bg-gradient-to-r from-blue-500 to-purple-500 bg-clip-text text-transparent">
//                   Log
//                 </span> 
//                 Analyzer
//               </h1>
//               <div className="h-1 w-20 bg-gradient-to-r from-blue-500 to-purple-500 mt-2 rounded-full shadow-[0_0_10px_#2563eb]"></div>
//             </div>
//           </div>
//         </header>

//         {/* --- Drag & Drop Zone --- */}
//         <div className="bg-white dark:bg-[#0f172a] rounded-[2rem] border border-gray-200 dark:border-blue-900/20 p-8 shadow-2xl mb-8 transition-all">
//           <div className="border-2 border-dashed border-gray-300 dark:border-blue-500/20 rounded-2xl p-10 flex flex-col items-center justify-center relative group hover:border-blue-500/50 transition-colors">
//             <input type="file" accept=".log,.csv" onChange={handleFileChange} className="absolute inset-0 opacity-0 cursor-pointer" />
//             <UploadCloud size={48} className="text-blue-500 mb-4 group-hover:scale-110 transition-transform" />
//             <p className="text-sm font-bold mb-1">Drag & Drop your server log or CSV file here</p>
//             <p className="text-xs text-gray-400">Supports .log, .csv files only</p>
//             {file && (
//               <div className="mt-6 flex items-center gap-2 bg-blue-500/10 border border-blue-500/20 px-4 py-2 rounded-xl">
//                 <FileText size={18} className="text-blue-400" />
//                 <span className="text-xs font-mono font-bold text-blue-400">{file.name} ({(file.size/1024).toFixed(1)} KB)</span>
//               </div>
//             )}
//           </div>
//           {file && (
//             <button onClick={handleUpload} disabled={loading} className="w-full mt-6 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-800 text-white py-4 rounded-xl font-bold transition-all shadow-lg shadow-blue-500/20 flex items-center justify-center gap-2">
//               {loading ? (
//                 <> <Loader2 className="animate-spin" size={20} /> AiSentinel is Inspecting Lines... </>
//               ) : (
//                 <> 
//                   <Play size={16} className="fill-current" /> Start Security Analysis </>
//               )}
//             </button>
//           )}
//         </div>

//         {/* --- Dashboard Results Block --- */}
//         {analytics && (
//           <div className="animate-in fade-in zoom-in duration-300">
//             {/* 📈 Smart Cards */}
//             <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
//               <div className="bg-white dark:bg-[#0f172a] border border-gray-200 dark:border-blue-900/20 rounded-2xl p-6 flex items-center gap-5 shadow-xl">
//                 <div className="p-4 bg-blue-500/10 rounded-xl text-blue-500"><FileText size={24} /></div>
//                 <div>
//                   <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Total Lines Inspected</p>
//                   <p className="text-3xl font-black">{analytics.summary.total_lines}</p>
//                 </div>
//               </div>
//               <div className="bg-white dark:bg-[#0f172a] border border-gray-200 dark:border-blue-900/20 rounded-2xl p-6 flex items-center gap-5 shadow-xl">
//                 <div className="p-4 bg-red-500/10 rounded-xl text-red-500 shadow-[0_0_15px_rgba(239,68,68,0.1)]"><ShieldAlert size={24} /></div>
//                 <div>
//                   <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Threats Blocked</p>
//                   <p className="text-3xl font-black text-red-500 drop-shadow-[0_0_10px_rgba(239,68,68,0.3)]">{analytics.summary.threats_detected}</p>
//                 </div>
//               </div>
//             </div>

//             {/* 📋 Advanced Analysis Table */}
//             <div className="bg-white dark:bg-[#0f172a] rounded-[2rem] border border-gray-200 dark:border-blue-900/20 overflow-hidden shadow-2xl">
//               <div className="p-6 border-b border-gray-100 dark:border-white/5 bg-gray-50/50 dark:bg-[#060a14]/30">
//                 <h3 className="font-black text-xs uppercase tracking-widest text-gray-400">Deep Inspection Matrix</h3>
//               </div>
//               <div className="overflow-x-auto max-h-[50vh] custom-scrollbar">
//                 <table className="w-full text-left">
//                   <thead className="bg-gray-50 dark:bg-[#060a14]/50 text-gray-400 text-[10px] uppercase font-black tracking-[0.2em] border-b border-gray-100 dark:border-white/5 sticky top-0 z-10">
//                     <tr>
//                       <th className="px-7 py-4">IP Address</th>
//                       <th className="px-7 py-4">Payload/Payload Target</th>
//                       <th className="px-7 py-4">Attack Type</th>
//                       <th className="px-7 py-4">Pipeline Stage</th>
//                       <th className="px-7 py-4 text-center">Status</th>
//                     </tr>
//                   </thead>
//                   <tbody className="divide-y divide-gray-100 dark:divide-white/5 font-mono text-xs">
//                     {analytics.results.map((log, i) => {
//                       const isAttack = log.status === 'attack';
//                       return (
//                         <tr key={i} className="hover:bg-blue-500/[0.02] transition duration-150">
//                           <td className="px-7 py-4 font-bold font-sans">{log.ip}</td>
//                           <td className="px-7 py-4 max-w-xs truncate text-gray-400" title={log.request}>{log.request}</td>
//                           <td className="px-7 py-4"><span className={isAttack ? 'text-red-400 font-bold' : 'text-gray-500'}>{log.sub_type}</span></td>
//                           <td className="px-7 py-4 text-gray-400 text-[11px]">{log.stage}</td>
//                           <td className="px-7 py-4 text-center">
//                             <span className={`px-3 py-1 rounded-lg text-[9px] font-black tracking-widest border ${
//                               isAttack ? 'bg-red-500/10 text-red-500 border-red-500/20' : 'bg-green-500/10 text-green-500 border-green-500/20'
//                             }`}>
//                               {isAttack ? 'ATTACK' : 'NORMAL'}
//                             </span>
//                           </td>
//                         </tr>
//                       );
//                     })}
//                   </tbody>
//                 </table>
//               </div>
//             </div>
//           </div>
//         )}
//       </div>
//     </div>
//   );
// };

// export default LogAnalyzer;