import React, { useState } from 'react';
import { ArrowLeft, Calendar, ChevronLeft, ChevronRight } from 'lucide-react';

const StaticEnginePage = ({ onBack, allLogs = [] }) => {
  const currentYear = "2026";
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [currentPage, setCurrentPage] = useState(1);
  const logsPerPage = 50;

  const staticAttacks = allLogs.filter(log => {
    const isAttack = log.status !== 'normal' && log.status !== 'success';
    const stages = String(JSON.stringify(log.stages || log.stage || "")).toLowerCase();
    const isStatic = stages.includes('static');
    
    // فلترة التاريخ YYYY-MM-DD
    const logTimestamp = log["@timestamp"] || log.time || "";
    const logDate = logTimestamp.includes(" ") ? logTimestamp.split(" ")[0] : (logTimestamp.includes("T") ? logTimestamp.split("T")[0] : logTimestamp);
    const matchesDate = logDate.trim() === selectedDate.trim();

    return isAttack && isStatic && matchesDate;
  });

  const totalPages = Math.ceil(staticAttacks.length / logsPerPage) || 1;
  const indexOfLastLog = currentPage * logsPerPage;
  const indexOfFirstLog = indexOfLastLog - logsPerPage;
  const currentLogs = staticAttacks.slice(indexOfFirstLog, indexOfLastLog);

  return (
    <div className="min-h-screen p-2 text-white font-sans animate-fadeIn">
      <div className="max-w-7xl mx-auto pb-10">
        
        {/* --- 1. Top Integrated Header  --- */}
        <header className="mb-8 flex flex-col md:flex-row justify-between items-start md:items-center gap-6 pb-6 border-b border-white/5">
          <div className="flex items-center gap-6 min-w-0">
            <button 
              onClick={onBack} 
              className="p-3 bg-[#0f172a] border border-white/5 hover:border-blue-500/50 rounded-2xl transition-all duration-300 text-blue-400 shadow-xl group flex-shrink-0"
            >
              <ArrowLeft size={24} className="group-hover:-translate-x-1 transition-transform" />
            </button>
            <div>
              <h1 className="text-3xl md:text-4xl lg:text-5xl font-black uppercase tracking-tighter whitespace-nowrap">
                <span className="bg-gradient-to-r from-blue-600 to-blue-400 bg-clip-text text-transparent">
                  Static Rules
                </span> Engine
              </h1>
              <div className="h-1 w-20 bg-blue-600 mt-2 rounded-full shadow-[0_0_10px_#2563eb]"></div>
            </div>
          </div>

          {/* Time Window */}
          <div className="flex flex-col items-start md:items-end gap-2 flex-shrink-0 translate-y-[2px]">
            <label className="text-xs font-black text-white uppercase tracking-widest">
              Time Window
            </label>
            
            <div className="relative flex items-center bg-blue-900/30 border border-blue-500/50 rounded-xl px-4 py-2.5 transition-all duration-300 cursor-pointer hover:bg-blue-900/50">
              <Calendar size={14} className="text-blue-400 mr-2.5" />
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => { setSelectedDate(e.target.value); setCurrentPage(1); }}
                className="bg-transparent text-xs font-black font-mono outline-none cursor-pointer text-white w-36"
              />
            </div>
            {/* <div className="relative flex items-center bg-[#060a14] border border-white/10 rounded-xl px-4 py-2.5 group hover:border-blue-500/50 transition-colors cursor-pointer">
              <Calendar size={14} className="text-blue-500 mr-2.5" />
              <input 
                type="date" 
                min={`${currentYear}-01-01`}
                max={`${currentYear}-12-31`}
                value={selectedDate}
                onChange={(e) => {
                  setSelectedDate(e.target.value);
                  setCurrentPage(1);
                }}
                className="bg-transparent text-xs font-black font-mono outline-none cursor-pointer text-slate-200 w-36 focus:text-white"
              />
            </div> */}
          </div>
        </header>

        {/* --- 2. Static Events Registry Table --- */}
        <div className="bg-[#0f172a] rounded-[2rem] border border-white/5 overflow-hidden shadow-2xl w-full">
          <div className="p-6 border-b border-white/5 bg-[#060a14]/30 flex justify-between items-center">
            <h3 className="font-black text-xs uppercase tracking-widest text-slate-400 text-white">
              Signature-Based Block Registry
            </h3>
            <span className="text-[10px] bg-blue-500/10 text-blue-400 px-3 py-1 rounded-lg border border-blue-500/10 font-bold font-mono">
              MATCHED VIOLATIONS: {staticAttacks.length}
            </span>
          </div>

          <div className="max-h-[72vh] overflow-y-auto w-full pr-1
            [&::-webkit-scrollbar]:w-2 
            [&::-webkit-scrollbar-track]:bg-transparent 
            [&::-webkit-scrollbar-thumb]:bg-blue-900/40 
            [&::-webkit-scrollbar-thumb]:rounded-full 
            hover:[&::-webkit-scrollbar-thumb]:bg-blue-500 transition-colors">
            
            <table className="w-full table-fixed text-left border-collapse">
              <thead className="bg-[#060a14]/80 text-slate-400 text-[10px] uppercase font-black tracking-[0.15em] border-b border-white/5 sticky top-0 z-10 backdrop-blur-md">
                <tr>
                  <th className="w-[12%] px-6 py-4">Timestamp</th>
                  <th className="w-[15%] px-6 py-4">Source IP</th>
                  <th className="w-[18%] px-6 py-4">Triggered Rule</th>
                  <th className="w-[35%] px-6 py-4">Matched Payload</th>
                  <th className="w-[10%] px-6 py-4 text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 font-mono text-[11px]">
                {currentLogs.map((log, i) => {
                  const isBlocked = log.status === 'blocked';
                  const payloadContent = log.request_url || log.request || log.payload || "N/A";
                  // const payloadContent = log.request_url || log.payload || log.message || "-";
                  return (
                    <tr key={i} className="hover:bg-blue-500/[0.02] transition">
                      <td className="px-6 py-4 text-slate-500 font-sans">{log["@timestamp"] || log.time}</td>
                      <td className="px-6 py-4 font-bold text-slate-300">{log.source_ip || log.ip}</td>
                      
                      <td className="px-6 py-4 text-blue-400 font-bold tracking-tight">
                        {log.sub_type && log.sub_type !== "None" ? log.sub_type : "STATIC_SIGNATURE_VIOLATION"}
                      </td>
                      
                      <td className="px-6 py-4 text-slate-400 truncate" title={payloadContent}>
                        {payloadContent}
                      </td>
                      
                      <td className="px-6 py-4 text-center font-sans">
                        <span className={`px-2.5 py-1 rounded-md text-[9px] font-black tracking-wider border block w-full text-center ${
                          isBlocked 
                            ? 'bg-red-500/10 text-red-500 border-red-500/20 shadow-[0_0_10px_rgba(239,68,68,0.05)]' 
                            : 'bg-blue-500/10 text-blue-500 border-blue-500/20'
                        }`}>
                          {isBlocked ? 'BLOCK' : 'ALERT'}
                        </span>
                      </td>
                    </tr>
                  );
                })}

                {staticAttacks.length === 0 && (
                  <tr>
                    <td colSpan="5" className="py-14 text-center text-slate-600 font-bold tracking-widest uppercase italic text-xs">
                      No signature violations triggered in this time window.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          <div className="p-4 bg-[#060a14]/50 border-t border-white/5 flex justify-center items-center w-full">
            <div className="flex items-center gap-2 max-w-md justify-center overflow-x-auto px-2 py-1">
              <button
                onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                disabled={currentPage === 1}
                className="p-2 bg-[#0f172a] border border-white/5 rounded-xl text-slate-400 hover:text-white disabled:opacity-40 disabled:hover:text-slate-400 transition flex-shrink-0"
              >
                <ChevronLeft size={16} />
              </button>

              {Array.from({ length: totalPages }, (_, index) => {
                const pageNum = index + 1;
                if (totalPages > 6 && Math.abs(currentPage - pageNum) > 2 && pageNum !== 1 && pageNum !== totalPages) return null;
                return (
                  <button
                    key={pageNum}
                    onClick={() => setCurrentPage(pageNum)}
                    className={`w-8 h-8 rounded-xl text-xs font-bold font-mono transition-all flex-shrink-0 ${
                      currentPage === pageNum 
                        ? 'bg-blue-600 text-white shadow-md shadow-blue-500/20 border border-blue-500/30' 
                        : 'bg-[#0f172a] border border-white/5 text-slate-400 hover:text-white'
                    }`}
                  >
                    {pageNum}
                  </button>
                );
              })}

              <button
                onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                disabled={currentPage === totalPages}
                className="p-2 bg-[#0f172a] border border-white/5 rounded-xl text-slate-400 hover:text-white disabled:opacity-40 disabled:hover:text-slate-400 transition flex-shrink-0"
              >
                <ChevronRight size={16} />
              </button>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};

export default StaticEnginePage;


// import React, { useState } from 'react';
// import { ArrowLeft, Calendar, ChevronLeft, ChevronRight } from 'lucide-react';

// const StaticEnginePage = ({ onBack, allLogs = [] }) => {
//   const currentYear = "2026";
//   const [selectedDate, setSelectedDate] = useState(`${currentYear}-06-21`);
//   const [currentPage, setCurrentPage] = useState(1);
//   const logsPerPage = 50;
//   const staticAttacks = allLogs.filter(log => {
//     const isAttack = log.status !== 'normal';
//     const isStatic = log.stage && log.stage.toLowerCase().includes('static');
//     return isAttack && isStatic;
//   });

//   const totalPages = Math.ceil(staticAttacks.length / logsPerPage) || 1;
//   const indexOfLastLog = currentPage * logsPerPage;
//   const indexOfFirstLog = indexOfLastLog - logsPerPage;
//   const currentLogs = staticAttacks.slice(indexOfFirstLog, indexOfLastLog);

//   return (
//     <div className="min-h-screen p-2 text-white font-sans animate-fadeIn">
//       <div className="max-w-7xl mx-auto pb-10">
        
//         {/* --- 1. Top Integrated Header  --- */}
//         <header className="mb-8 flex flex-col md:flex-row justify-between items-start md:items-center gap-6 pb-6 border-b border-white/5">
//           <div className="flex items-center gap-6 min-w-0">
//             <button 
//               onClick={onBack} 
//               className="p-3 bg-[#0f172a] border border-white/5 hover:border-blue-500/50 rounded-2xl transition-all duration-300 text-blue-400 shadow-xl group flex-shrink-0"
//             >
//               <ArrowLeft size={24} className="group-hover:-translate-x-1 transition-transform" />
//             </button>
//             <div>
//               <h1 className="text-3xl md:text-4xl lg:text-5xl font-black uppercase tracking-tighter whitespace-nowrap">
//                 <span className="bg-gradient-to-r from-blue-600 to-blue-400 bg-clip-text text-transparent">
//                   Static Rules
//                 </span> Engine
//               </h1>
//               <div className="h-1 w-20 bg-blue-600 mt-2 rounded-full shadow-[0_0_10px_#2563eb]"></div>
//             </div>
//           </div>

//           {/* Time Window */}
//           <div className="flex flex-col items-start md:items-end gap-2 flex-shrink-0 translate-y-[2px]">
//             <label className="text-xs font-black text-white uppercase tracking-widest">
//               Time Window
//             </label>
            
//             <div className="relative flex items-center bg-[#060a14] border border-white/10 rounded-xl px-4 py-2.5 group hover:border-blue-500/50 transition-colors cursor-pointer">
//               <Calendar size={14} className="text-blue-500 mr-2.5" />
//               <input 
//                 type="date" 
//                 min={`${currentYear}-01-01`}
//                 max={`${currentYear}-12-31`}
//                 value={selectedDate}
//                 onChange={(e) => setSelectedDate(e.target.value)}
//                 className="bg-transparent text-xs font-black font-mono outline-none cursor-pointer text-slate-200 w-36 focus:text-white"
//               />
//             </div>
//           </div>
//         </header>

//         {/* --- 2. Static Events Registry Table --- */}
//         <div className="bg-[#0f172a] rounded-[2rem] border border-white/5 overflow-hidden shadow-2xl w-full">
//           <div className="p-6 border-b border-white/5 bg-[#060a14]/30 flex justify-between items-center">
//             <h3 className="font-black text-xs uppercase tracking-widest text-slate-400 text-white">
//               Signature-Based Block Registry
//             </h3>
//             <span className="text-[10px] bg-blue-500/10 text-blue-400 px-3 py-1 rounded-lg border border-blue-500/10 font-bold font-mono">
//               MATCHED VIOLATIONS: {staticAttacks.length}
//             </span>
//           </div>

//           <div className="max-h-[60vh] overflow-y-auto w-full pr-1
//             [&::-webkit-scrollbar]:w-1.5 
//             [&::-webkit-scrollbar-track]:bg-transparent 
//             [&::-webkit-scrollbar-thumb]:bg-blue-900/40 
//             [&::-webkit-scrollbar-thumb]:rounded-full 
//             hover:[&::-webkit-scrollbar-thumb]:bg-blue-500 transition-colors">
            
//             <table className="w-full table-fixed text-left border-collapse">
//               <thead className="bg-[#060a14]/80 text-slate-400 text-[10px] uppercase font-black tracking-[0.15em] border-b border-white/5 sticky top-0 z-10 backdrop-blur-md">
//                 <tr>
//                   <th className="w-[12%] px-6 py-4">Timestamp</th>
//                   <th className="w-[15%] px-6 py-4">Source IP</th>
//                   <th className="w-[18%] px-6 py-4">Triggered Rule</th>
//                   <th className="w-[35%] px-6 py-4">Matched Payload</th>
//                   <th className="w-[10%] px-6 py-4 text-center">Action</th>
//                 </tr>
//               </thead>
//               <tbody className="divide-y divide-white/5 font-mono text-[11px]">
//                 {currentLogs.map((log, i) => {
//                   const isBlocked = log.status === 'blocked';
//                   return (
//                     <tr key={i} className="hover:bg-blue-500/[0.02] transition">
//                       <td className="px-6 py-4 text-slate-500 font-sans">{log["@timestamp"] || log.time}</td>
//                       <td className="px-6 py-4 font-bold text-slate-300">{log.source_ip || log.ip}</td>
                      
//                       {/* Triggered Rule */}
//                       <td className="px-6 py-4 text-blue-400 font-bold tracking-tight">
//                         {log.sub_type || "RULE_VIOLATION"}
//                       </td>
                      
//                       {/* Matched Payload */}
//                       <td className="px-6 py-4 text-slate-400 truncate" title={log.request}>
//                         {log.request}
//                       </td>
                      
//                       {/* Action */}
//                       <td className="px-6 py-4 text-center font-sans">
//                         <span className={`px-2.5 py-1 rounded-md text-[9px] font-black tracking-wider border block w-full text-center ${
//                           isBlocked 
//                             ? 'bg-red-500/10 text-red-500 border-red-500/20 shadow-[0_0_10px_rgba(239,68,68,0.05)]' 
//                             : 'bg-blue-500/10 text-blue-500 border-blue-500/20'
//                         }`}>
//                           {isBlocked ? 'DROP / BLOCK' : 'ALERT'}
//                         </span>
//                       </td>
//                     </tr>
//                   );
//                 })}

//                 {staticAttacks.length === 0 && (
//                   <tr>
//                     <td colSpan="5" className="py-14 text-center text-slate-600 font-bold tracking-widest uppercase italic text-xs">
//                       No signature violations triggered in this time window.
//                     </td>
//                   </tr>
//                 )}
//               </tbody>
//             </table>
//           </div>

//           {/*  3. Pages Controller Panel */}
//           <div className="p-4 bg-[#060a14]/50 border-t border-white/5 flex justify-center items-center">
//             <div className="flex items-center gap-2">
//               <button
//                 onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
//                 disabled={currentPage === 1}
//                 className="p-2 bg-[#0f172a] border border-white/5 rounded-xl text-slate-400 hover:text-white disabled:opacity-40 disabled:hover:text-slate-400 transition"
//               >
//                 <ChevronLeft size={16} />
//               </button>

//               {Array.from({ length: totalPages }, (_, index) => (
//                 <button
//                   key={index + 1}
//                   onClick={() => setCurrentPage(index + 1)}
//                   className={`w-8 h-8 rounded-xl text-xs font-bold font-mono transition-all ${
//                     currentPage === index + 1 
//                       ? 'bg-blue-600 text-white shadow-md shadow-blue-500/20 border border-blue-500/30' 
//                       : 'bg-[#0f172a] border border-white/5 text-slate-400 hover:text-white'
//                   }`}
//                 >
//                   {index + 1}
//                 </button>
//               ))}

//               <button
//                 onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
//                 disabled={currentPage === totalPages}
//                 className="p-2 bg-[#0f172a] border border-white/5 rounded-xl text-slate-400 hover:text-white disabled:opacity-40 disabled:hover:text-slate-400 transition"
//               >
//                 <ChevronRight size={16} />
//               </button>
//             </div>
//           </div>

//         </div>

//       </div>
//     </div>
//   );
// };

// export default StaticEnginePage;