// تظبيط ال Log Intelligence
import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, ChevronsLeft, Search, ArrowLeft, X, Shield, RefreshCw, Download, Calendar } from 'lucide-react';

const LogsHistory = ({ onBack }) => {
  const currentYear = "2026";
  const [allLogs, setAllLogs] = useState([]); 
  const [currentPage, setCurrentPage] = useState(1);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedLog, setSelectedLog] = useState(null);
  const [selectedDate, setSelectedDate] = useState("");
  const logsPerPage = 15;

  const fetchHistory = async () => {
    const token = localStorage.getItem('token');
    const url = `http://localhost:8000/api/logs`;
    
    try {
      const response = await fetch(url, { headers: { 'Authorization': `Bearer ${token}` } });
      const result = await response.json();
      
      if (result && Array.isArray(result)) {
        setAllLogs(result.reverse());
      } else {
        setAllLogs([]);
      }
    } catch (error) { 
      console.error("Error fetching history:", error); 
      setAllLogs([]);
    }
  };

  useEffect(() => { 
    fetchHistory(); 
  }, []);

  const handleRefresh = () => {
    setSearchTerm('');
    setCurrentPage(1);
    setSelectedDate(""); 
    fetchHistory();
  };

  const filteredLogs = allLogs.filter(log => {
    const logTimestamp = log["@timestamp"] || log.Timestamp || log.timestamp || "";
    let logDate = logTimestamp.includes(" ") ? logTimestamp.split(" ")[0] : (logTimestamp.includes("T") ? logTimestamp.split("T")[0] : logTimestamp);
    const matchesDate = selectedDate ? logDate.trim() === selectedDate.trim() : true;

    const query = searchTerm.toLowerCase().trim();
    if (!query) return matchesDate;

    const ip = String(log.source_ip || log.ip || "").toLowerCase();
    const status = String(log.status || "").toLowerCase();
    const attackType = String(log.sub_type || "").toLowerCase();
    const stagesStr = String(JSON.stringify(log.stages || log.stage || "")).toLowerCase();
    
    const isLogAttack = status === 'attack' || status === 'blocked' || status === 'fail' || (attackType !== 'none' && attackType !== '');

    let matchesSearch = false;
    
    if (query === "normal") {
      matchesSearch = !isLogAttack;
    } else if (query === "attack") {
      matchesSearch = isLogAttack;
    } else if (query === "static") {
      matchesSearch = isLogAttack && stagesStr.includes("static");
    } else if (query === "threat") {
      matchesSearch = isLogAttack && stagesStr.includes("threat");
    } else if (query === "anomaly") {
      matchesSearch = isLogAttack && stagesStr.includes("anomaly");
    } else {
      matchesSearch = ip.includes(query) || attackType.includes(query) || status.includes(query);
    }

    return matchesDate && matchesSearch;
  });

  const totalPages = Math.ceil(filteredLogs.length / logsPerPage) || 1;
  const indexOfLastLog = currentPage * logsPerPage;
  const indexOfFirstLog = indexOfLastLog - logsPerPage;
  const currentLogs = filteredLogs.slice(indexOfFirstLog, indexOfLastLog);

  const handleExportCSV = async () => {
    if (allLogs.length === 0) {
        return alert("No logs found in backend archive to export!");
    }
    try {
      const logsToExport = allLogs.filter(log => {
        if (!selectedDate) return true;
        const logTimestamp = log["@timestamp"] || log.Timestamp || log.timestamp || "";
        let logDate = logTimestamp.includes(" ") ? logTimestamp.split(" ")[0] : (logTimestamp.includes("T") ? logTimestamp.split("T")[0] : logTimestamp);
        return logDate.trim() === selectedDate.trim();
      });

      if (logsToExport.length === 0) {
        return alert("No logs found for the selected date to export!");
      }

      const headers = Object.keys(logsToExport[0]).join(",");
      const rows = logsToExport.map(log => 
        Object.values(log).map(val => {
          const cleanVal = String(val).replace(/"/g, '""').replace(/\n/g, ' ');
          return `"${cleanVal}"`;
        }).join(",")
      );
      
      const csvContent = "data:text/csv;charset=utf-8,\uFEFF" + [headers, ...rows].join("\n");
      const encodedUri = encodeURI(csvContent);
      
      const link = document.createElement("a");
      link.setAttribute("href", encodedUri);
      
      const filenameSuffix = selectedDate ? selectedDate : "Full_System_Report";
      link.setAttribute("download", `AiSentinel_Report_${filenameSuffix}.csv`);
      
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (error) {
      console.error("Export failed:", error);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-[#060a14] text-gray-900 dark:text-white p-8 relative transition-colors duration-300">
      <div className="max-w-6xl mx-auto pb-10">

        {/* --- Header --- */}
        <header className="mb-12">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
            <div className="flex items-center gap-6">
              <button onClick={onBack} className="p-3 bg-white dark:bg-[#0f172a] border border-gray-200 dark:border-white/5 hover:border-blue-500/50 rounded-2xl transition-all shadow-xl group">
                <ArrowLeft size={24} className="group-hover:-translate-x-1 transition-transform text-blue-500" />
              </button>
              <div>
                <h1 className="text-4xl font-black uppercase tracking-tighter flex items-center gap-3">
                  <span className="bg-gradient-to-r from-blue-600 to-blue-400 bg-clip-text text-transparent">Logs</span> Archive
                </h1>
                <div className="h-1 w-20 bg-blue-600 mt-2 rounded-full shadow-[0_0_10px_#2563eb]"></div>
              </div>
            </div>
            
            <div className="flex items-center gap-4 w-full md:w-auto">
              <div className="relative flex items-center bg-white dark:bg-[#060a14] border border-gray-200 dark:border-white/10 rounded-xl px-4 py-2.5 group hover:border-blue-500/50 transition-colors shadow-md">
                <Calendar size={14} className="text-blue-500 mr-2.5" />
                <input
                  type="date"
                  value={selectedDate}
                  onChange={(e) => {
                    setSelectedDate(e.target.value);
                    setCurrentPage(1); 
                  }}
                  className="bg-transparent text-xs font-black font-mono outline-none cursor-pointer text-gray-700 dark:text-slate-200 w-36 focus:text-blue-500"
                />
                {selectedDate && (
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedDate("");
                      setCurrentPage(1);
                    }} 
                    className="ml-2 text-gray-400 hover:text-red-500 transition-colors"
                  >
                    <X size={14} />
                  </button>
                )}
              </div>

              <button
                onClick={handleExportCSV}
                className="flex-1 md:flex-none flex items-center justify-center gap-2 bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-400 text-white px-6 py-3 rounded-xl font-bold transition-all shadow-lg shadow-blue-500/20 active:scale-95"
              >
                <Download size={18} /> Export CSV
              </button>
            </div>
          </div>
        </header>

        {/* --- Search Input --- */}
        <div className="relative flex gap-3 w-full mb-8">
          <div className="relative flex-grow group">
            <Search className="absolute left-4 top-3.5 text-gray-400 group-focus-within:text-blue-500 transition-colors" size={20} />
            <input
              type="text"
              value={searchTerm}
              placeholder="Search by IP, status, Attack_Type, or engine (static, threat, anomaly)..."
              className="w-full bg-white dark:bg-[#0f172a] border border-gray-200 dark:border-blue-900/20 rounded-2xl py-3.5 pl-12 pr-12 focus:border-blue-500 outline-none transition-all shadow-lg"
              onChange={(e) => {
                setSearchTerm(e.target.value);
                setCurrentPage(1);
              }}
            />
            {searchTerm && (
              <button onClick={() => { setSearchTerm(''); setCurrentPage(1); }} className="absolute right-4 top-3.5 text-gray-400 hover:text-red-500 transition-colors">
                <X size={20} />
              </button>
            )}
          </div>
          <button onClick={handleRefresh} title="Reset & Refresh" className="p-3 bg-white dark:bg-[#0f172a] border border-gray-200 dark:border-blue-900/20 rounded-2xl text-white hover:bg-blue-500/10 transition-all shadow-lg group">
            <RefreshCw size={24} className="group-active:rotate-180 transition-transform duration-500 text-gray-400 dark:text-white" />
          </button>
        </div>

        {/* --- Table --- */}
        <div className="bg-white dark:bg-[#0f172a] rounded-[2rem] border border-gray-200 dark:border-blue-900/20 overflow-hidden shadow-2xl">
          <table className="w-full text-left">
            <thead className="bg-gray-50 dark:bg-[#060a14]/50 text-gray-400 text-[10px] uppercase font-black tracking-[0.2em] border-b border-gray-100 dark:border-white/5">
              <tr>
                <th className="px-7 py-5">IP Address</th>
                <th className="px-7 py-5">Timestamp</th>
                <th className="px-7 py-5 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 dark:divide-white/5">
              {currentLogs.map((log, i) => {
                const ipValue = log.source_ip || log.ip || log.IP || "N/A";
                const timestampValue = log["@timestamp"] || log.Timestamp || log.timestamp || "-";
                const isAttack = log.status === 'attack' || log.status === 'blocked' || log.status === 'fail';
                return (
                  <tr key={i} onClick={() => setSelectedLog(log)} className="hover:bg-blue-500/[0.03] cursor-pointer transition duration-150 group">
                    <td className="px-6 py-5 font-bold group-hover:text-blue-500 transition-colors text-gray-800 dark:text-slate-200">{ipValue}</td>
                    <td className="px-6 py-5 text-sm font-mono text-gray-400">{timestampValue}</td>
                    <td className="px-6 py-5 text-center">
                      <span className={`px-4 py-1.5 rounded-lg text-[10px] font-black tracking-widest border ${
                        isAttack ? 'bg-red-500/10 text-red-500 border-red-500/20' : 'bg-green-500/10 text-green-500 border-green-500/20'
                      }`}>
                        {isAttack ? 'ATTACK' : 'NORMAL'}
                      </span>
                    </td>
                  </tr>
                );
              })}
              {filteredLogs.length === 0 && (
                <tr>
                  <td colSpan="3" className="py-14 text-center text-gray-400 font-bold tracking-widest uppercase italic text-xs">
                    No matching logs captured in this archive window.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* --- Pagination --- */}
        <div className="flex justify-center items-center gap-4 mt-12">
          <button
            onClick={() => setCurrentPage(1)}
            disabled={currentPage === 1}
            title="First Page"
            className="p-3 bg-white dark:bg-[#0f172a] border border-gray-200 dark:border-blue-900/20 rounded-xl text-blue-500 disabled:opacity-20 shadow-lg active:scale-95 transition-transform"
          >
            <ChevronsLeft size={20} />
          </button>

          <button
            disabled={currentPage === 1}
            onClick={() => setCurrentPage(p => Math.max(p - 1, 1))}
            title="Previous Page"
            className="p-3 bg-white dark:bg-[#0f172a] border border-gray-200 dark:border-blue-900/20 rounded-xl disabled:opacity-20 text-blue-500 shadow-lg active:scale-95 transition-transform"
          >
            <ChevronLeft size={24} />
          </button>

          <span className="text-xs font-black bg-white dark:bg-[#0f172a] px-8 py-3 rounded-full border border-gray-200 dark:border-blue-900/20 tracking-[0.2em] shadow-lg">
            PAGE {filteredLogs.length > 0 ? currentPage : 0} OF {totalPages}
          </span>

          <button
            disabled={currentPage >= totalPages}
            onClick={() => setCurrentPage(p => Math.min(p + 1, totalPages))}
            title="Next Page"
            className="p-3 bg-white dark:bg-[#0f172a] border border-gray-200 dark:border-blue-900/20 rounded-xl disabled:opacity-20 text-blue-500 shadow-lg active:scale-95 transition-transform"
          >
            <ChevronRight size={24} />
          </button>

          <button
            onClick={() => setCurrentPage(totalPages)}
            disabled={currentPage >= totalPages}
            title="Last Page"
            className="p-3 bg-white dark:bg-[#0f172a] border border-gray-200 dark:border-blue-900/20 rounded-xl text-blue-500 disabled:opacity-20 shadow-lg active:scale-95 transition-transform flex items-center justify-center rotate-180"
          >
            <ChevronsLeft size={20} />
          </button>
        </div>
      </div>

      {/* --- Log Intelligence Modal --- */}
      {selectedLog && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md flex items-center justify-center z-[1000] p-4" onClick={() => setSelectedLog(null)}>
          <div className="bg-[#0b1120] border border-slate-800/60 w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden" onClick={e => e.stopPropagation()}>
            
            <div className="p-6 border-b border-slate-900/50 flex justify-between items-center bg-[#070b14] text-white">
              <h2 className="text-sm font-black uppercase tracking-widest text-slate-100">Log Intelligence</h2>
              <button onClick={() => setSelectedLog(null)} className="text-slate-400 hover:text-red-500 transition-colors"><X size={20} /></button>
            </div>
            
            <div className="p-8 max-h-[75vh] overflow-y-auto custom-scrollbar space-y-6 text-slate-300 font-mono text-xs">
              
              <div>
                <label className="text-[10px] font-black uppercase tracking-widest text-blue-400 block mb-1.5">@timestamp</label>
                <p className="text-slate-200 text-sm">{selectedLog["@timestamp"] || selectedLog.Timestamp || selectedLog.timestamp || "-"}</p>
              </div>

              <div>
                <label className="text-[10px] font-black uppercase tracking-widest text-blue-400 block mb-1.5">source_ip</label>
                <p className="text-slate-200 text-sm font-bold tracking-tight">{selectedLog.source_ip || selectedLog.ip || "0.0.0.0"}</p>
              </div>

              <div>
                <label className="text-[10px] font-black uppercase tracking-widest text-blue-400 block mb-1.5">request_url</label>
                <p className="text-slate-200 text-sm break-all">{selectedLog.request_url || selectedLog.request || "/"}</p>
              </div>

              <div>
                <label className="text-[10px] font-black uppercase tracking-widest text-blue-400 block mb-1.5">Detection Stage</label>
                <p className="font-bold text-slate-100 text-sm uppercase tracking-wide">
                  {(() => {
                    const stagesStr = String(JSON.stringify(selectedLog.stages || selectedLog.stage || "")).toUpperCase();
                    if (stagesStr.includes("STATIC:HIGH") || stagesStr.includes("STATIC:CRITICAL")) return "Static Rules Engine Violation";
                    if (stagesStr.includes("THREAT:ATTACK")) return "Supervised ML Threat Engine Catch";
                    if (stagesStr.includes("ANOMALY:ATTACK")) return "Behavioral Anomaly Engine Catch";
                    return selectedLog.status !== 'normal' && selectedLog.status !== 'success' ? "DETECTION GATEWAY CONTAINMENT" : "AiSentinel COMPLIANT TRAFFIC";
                  })()}
                </p>
              </div>

              <div>
                <label className="text-[10px] font-black uppercase tracking-widest text-blue-400 block mb-1.5">Attack Type</label>
                <p className="font-extrabold text-slate-100 text-sm uppercase">
                  {selectedLog.sub_type && selectedLog.sub_type !== "None" ? selectedLog.sub_type : (selectedLog.status !== 'normal' && selectedLog.status !== 'success' ? "SUSPICIOUS_EXPLOIT" : "-")}
                </p>
              </div>

              {/* --- Pipeline Inspection Metrics --- */}
              <div className="border-t border-b border-slate-900/60 py-6 my-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-blue-400 block mb-4">
                  Pipeline Inspection Metrics
                </label>
                <div className="grid grid-cols-3 gap-3">
                  
                  {/* 1. static engine */}
                  <div className="bg-[#070b14] border border-slate-800/40 p-4 rounded-xl flex flex-col justify-center items-center shadow-inner">
                    <span className="text-slate-500 text-[9px] font-black uppercase tracking-wider mb-2">1. static engine</span>
                    <span className={(() => {
                      const stagesStr = String(JSON.stringify(selectedLog.stages || "")).toUpperCase();
                      if (stagesStr.includes("STATIC:HIGH") || stagesStr.includes("STATIC:CRITICAL")) return "text-red-500 font-black"; 
                      if (stagesStr.includes("STATIC:LOW") || stagesStr.includes("STATIC:MEDIUM")) return "text-yellow-400 font-bold";     
                      return "text-emerald-400 font-bold";
                    })()}>
                      {(() => {
                        const stagesStr = String(JSON.stringify(selectedLog.stages || "")).toUpperCase();
                        if (stagesStr.includes("STATIC:HIGH") || stagesStr.includes("STATIC:CRITICAL")) return "CRITICAL MATCH";
                        if (stagesStr.includes("STATIC:LOW") || stagesStr.includes("STATIC:MEDIUM")) return "LOW SUSPECT";
                        return "CLEAN";
                      })()}
                    </span> 
                  </div>

                  {/* 2. threat model */}
                  <div className="bg-[#070b14] border border-slate-800/40 p-4 rounded-xl flex flex-col justify-center items-center shadow-inner">
                    <span className="text-slate-500 text-[9px] font-black uppercase tracking-wider mb-2">2. threat model</span>
                    <span className={(() => {
                      const stagesStr = String(JSON.stringify(selectedLog.stages || "")).toUpperCase();
                      if (stagesStr.includes("THREAT:BYPASS")) return "text-slate-600 font-bold opacity-60";
                      if (stagesStr.includes("THREAT:ATTACK")) return "text-red-500 font-black"; 
                      return "text-emerald-400 font-bold";
                    })()}>
                      {(() => {
                        const stagesStr = String(JSON.stringify(selectedLog.stages || "")).toUpperCase();
                        if (stagesStr.includes("THREAT:BYPASS")) return "BYPASSED (EARLY BLOCK)";
                        if (stagesStr.includes("THREAT:ATTACK")) return "ATTACK CAUGHT";
                        return "PASSED SAFE";
                      })()}
                    </span> 
                  </div>

                  {/* 3. anomaly model */}
                  <div className="bg-[#070b14] border border-slate-800/40 p-4 rounded-xl flex flex-col justify-center items-center shadow-inner">
                    <span className="text-slate-500 text-[9px] font-black uppercase tracking-wider mb-2">3. anomaly model</span>
                    <span className={(() => {
                      const stagesStr = String(JSON.stringify(selectedLog.stages || "")).toUpperCase();
                      if (stagesStr.includes("ANOMALY:BYPASS")) return "text-slate-600 font-bold opacity-60";
                      if (stagesStr.includes("ANOMALY:ATTACK")) return "text-purple-400 font-black";
                      return "text-emerald-400 font-bold";
                    })()}>
                      {(() => {
                        const stagesStr = String(JSON.stringify(selectedLog.stages || "")).toUpperCase();
                        if (stagesStr.includes("ANOMALY:BYPASS")) return "BYPASSED (EARLY BLOCK)";
                        if (stagesStr.includes("ANOMALY:ATTACK")) return "ANOMALY CAUGHT";
                        return "CLEAN BASELINE";
                      })()}
                    </span> 
                  </div>

                </div>
              </div>

              <div>
                <label className="text-[10px] font-black uppercase tracking-widest text-blue-400 block mb-2">status</label>
                <p className="text-slate-200 text-sm tracking-wide lowercase">{selectedLog.status || "normal"}</p>
              </div>

            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default LogsHistory;



// النسخة الأصلية
// import React, { useState, useEffect } from 'react';
// import { ChevronLeft, ChevronRight, ChevronsLeft, Search, ArrowLeft, X, Shield, RefreshCw, Download, Calendar } from 'lucide-react';

// const LogsHistory = ({ onBack }) => {
//   const currentYear = "2026";
//   const [allLogs, setAllLogs] = useState([]); 
//   const [currentPage, setCurrentPage] = useState(1);
//   const [searchTerm, setSearchTerm] = useState('');
//   const [selectedLog, setSelectedLog] = useState(null);
//   const [selectedDate, setSelectedDate] = useState("");
//   const logsPerPage = 15;

//   const fetchHistory = async () => {
//     const token = localStorage.getItem('token');
//     const url = `http://localhost:8000/api/logs`;
    
//     try {
//       const response = await fetch(url, { headers: { 'Authorization': `Bearer ${token}` } });
//       const result = await response.json();
      
//       if (result && Array.isArray(result)) {
//         setAllLogs(result.reverse());
//       } else {
//         setAllLogs([]);
//       }
//     } catch (error) { 
//       console.error("Error fetching history:", error); 
//       setAllLogs([]);
//     }
//   };

//   useEffect(() => { 
//     fetchHistory(); 
//   }, []);

//   const handleRefresh = () => {
//     setSearchTerm('');
//     setCurrentPage(1);
//     setSelectedDate(""); 
//     fetchHistory();
//   };

//   const filteredLogs = allLogs.filter(log => {
//     const logTimestamp = log["@timestamp"] || log.Timestamp || log.timestamp || "";
//     let logDate = logTimestamp.includes(" ") ? logTimestamp.split(" ")[0] : (logTimestamp.includes("T") ? logTimestamp.split("T")[0] : logTimestamp);
//     const matchesDate = selectedDate ? logDate.trim() === selectedDate.trim() : true;

//     const query = searchTerm.toLowerCase().trim();
//     if (!query) return matchesDate;

//     const ip = String(log.source_ip || log.ip || "").toLowerCase();
//     const status = String(log.status || "").toLowerCase();
//     const attackType = String(log.sub_type || "").toLowerCase();
//     const stagesStr = String(JSON.stringify(log.stages || log.stage || "")).toLowerCase();
    
//     const isLogAttack = status === 'attack' || status === 'blocked' || status === 'fail' || (attackType !== 'none' && attackType !== '');

//     let matchesSearch = false;
    
//     if (query === "normal") {
//       matchesSearch = !isLogAttack;
//     } else if (query === "attack") {
//       matchesSearch = isLogAttack;
//     } else if (query === "static") {
//       matchesSearch = isLogAttack && stagesStr.includes("static");
//     } else if (query === "threat") {
//       matchesSearch = isLogAttack && stagesStr.includes("threat");
//     } else if (query === "anomaly") {
//       matchesSearch = isLogAttack && stagesStr.includes("anomaly");
//     } else {
//       matchesSearch = ip.includes(query) || attackType.includes(query) || status.includes(query);
//     }

//     return matchesDate && matchesSearch;
//   });

//   const totalPages = Math.ceil(filteredLogs.length / logsPerPage) || 1;
//   const indexOfLastLog = currentPage * logsPerPage;
//   const indexOfFirstLog = indexOfLastLog - logsPerPage;
//   const currentLogs = filteredLogs.slice(indexOfFirstLog, indexOfLastLog);

//   const handleExportCSV = async () => {
//     if (allLogs.length === 0) {
//         return alert("No logs found in backend archive to export!");
//     }
//     try {
//       const logsToExport = allLogs.filter(log => {
//         if (!selectedDate) return true;
//         const logTimestamp = log["@timestamp"] || log.Timestamp || log.timestamp || "";
//         let logDate = logTimestamp.includes(" ") ? logTimestamp.split(" ")[0] : (logTimestamp.includes("T") ? logTimestamp.split("T")[0] : logTimestamp);
//         return logDate.trim() === selectedDate.trim();
//       });

//       if (logsToExport.length === 0) {
//         return alert("No logs found for the selected date to export!");
//       }

//       const headers = Object.keys(logsToExport[0]).join(",");
//       const rows = logsToExport.map(log => 
//         Object.values(log).map(val => {
//           const cleanVal = String(val).replace(/"/g, '""').replace(/\n/g, ' ');
//           return `"${cleanVal}"`;
//         }).join(",")
//       );
      
//       const csvContent = "data:text/csv;charset=utf-8,\uFEFF" + [headers, ...rows].join("\n");
//       const encodedUri = encodeURI(csvContent);
      
//       const link = document.createElement("a");
//       link.setAttribute("href", encodedUri);
      
//       const filenameSuffix = selectedDate ? selectedDate : "Full_System_Report";
//       link.setAttribute("download", `AiSentinel_Report_${filenameSuffix}.csv`);
      
//       document.body.appendChild(link);
//       link.click();
//       document.body.removeChild(link);
//     } catch (error) {
//       console.error("Export failed:", error);
//     }
//   };

//   return (
//     <div className="min-h-screen bg-gray-50 dark:bg-[#060a14] text-gray-900 dark:text-white p-8 relative transition-colors duration-300">
//       <div className="max-w-6xl mx-auto pb-10">

//         {/* --- Header --- */}
//         <header className="mb-12">
//           <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
//             <div className="flex items-center gap-6">
//               <button onClick={onBack} className="p-3 bg-white dark:bg-[#0f172a] border border-gray-200 dark:border-white/5 hover:border-blue-500/50 rounded-2xl transition-all shadow-xl group">
//                 <ArrowLeft size={24} className="group-hover:-translate-x-1 transition-transform text-blue-500" />
//               </button>
//               <div>
//                 <h1 className="text-4xl font-black uppercase tracking-tighter flex items-center gap-3">
//                   <span className="bg-gradient-to-r from-blue-600 to-blue-400 bg-clip-text text-transparent">Logs</span> Archive
//                 </h1>
//                 <div className="h-1 w-20 bg-blue-600 mt-2 rounded-full shadow-[0_0_10px_#2563eb]"></div>
//               </div>
//             </div>
            
//             <div className="flex items-center gap-4 w-full md:w-auto">
//               <div className="relative flex items-center bg-white dark:bg-[#060a14] border border-gray-200 dark:border-white/10 rounded-xl px-4 py-2.5 group hover:border-blue-500/50 transition-colors shadow-md">
//                 <Calendar size={14} className="text-blue-500 mr-2.5" />
//                 <input
//                   type="date"
//                   value={selectedDate}
//                   onChange={(e) => {
//                     setSelectedDate(e.target.value);
//                     setCurrentPage(1); 
//                   }}
//                   className="bg-transparent text-xs font-black font-mono outline-none cursor-pointer text-gray-700 dark:text-slate-200 w-36 focus:text-blue-500"
//                 />
//                 {selectedDate && (
//                   <button 
//                     onClick={(e) => {
//                       e.stopPropagation();
//                       setSelectedDate("");
//                       setCurrentPage(1);
//                     }} 
//                     className="ml-2 text-gray-400 hover:text-red-500 transition-colors"
//                   >
//                     <X size={14} />
//                   </button>
//                 )}
//               </div>

//               <button
//                 onClick={handleExportCSV}
//                 className="flex-1 md:flex-none flex items-center justify-center gap-2 bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-400 text-white px-6 py-3 rounded-xl font-bold transition-all shadow-lg shadow-blue-500/20 active:scale-95"
//               >
//                 <Download size={18} /> Export CSV
//               </button>
//             </div>
//           </div>
//         </header>

//         {/* --- Search Input --- */}
//         <div className="relative flex gap-3 w-full mb-8">
//           <div className="relative flex-grow group">
//             <Search className="absolute left-4 top-3.5 text-gray-400 group-focus-within:text-blue-500 transition-colors" size={20} />
//             <input
//               type="text"
//               value={searchTerm}
//               placeholder="Search by IP, status, Attack_Type, or engine (static, threat, anomaly)..."
//               className="w-full bg-white dark:bg-[#0f172a] border border-gray-200 dark:border-blue-900/20 rounded-2xl py-3.5 pl-12 pr-12 focus:border-blue-500 outline-none transition-all shadow-lg"
//               onChange={(e) => {
//                 setSearchTerm(e.target.value);
//                 setCurrentPage(1);
//               }}
//             />
//             {searchTerm && (
//               <button onClick={() => { setSearchTerm(''); setCurrentPage(1); }} className="absolute right-4 top-3.5 text-gray-400 hover:text-red-500 transition-colors">
//                 <X size={20} />
//               </button>
//             )}
//           </div>
//           <button onClick={handleRefresh} title="Reset & Refresh" className="p-3 bg-white dark:bg-[#0f172a] border border-gray-200 dark:border-blue-900/20 rounded-2xl text-white hover:bg-blue-500/10 transition-all shadow-lg group">
//             <RefreshCw size={24} className="group-active:rotate-180 transition-transform duration-500 text-gray-400 dark:text-white" />
//           </button>
//         </div>

//         {/* --- Table --- */}
//         <div className="bg-white dark:bg-[#0f172a] rounded-[2rem] border border-gray-200 dark:border-blue-900/20 overflow-hidden shadow-2xl">
//           <table className="w-full text-left">
//             <thead className="bg-gray-50 dark:bg-[#060a14]/50 text-gray-400 text-[10px] uppercase font-black tracking-[0.2em] border-b border-gray-100 dark:border-white/5">
//               <tr>
//                 <th className="px-7 py-5">IP Address</th>
//                 <th className="px-7 py-5">Timestamp</th>
//                 <th className="px-7 py-5 text-center">Status</th>
//               </tr>
//             </thead>
//             <tbody className="divide-y divide-gray-100 dark:divide-white/5">
//               {currentLogs.map((log, i) => {
//                 const ipValue = log.source_ip || log.ip || log.IP || "N/A";
//                 const timestampValue = log["@timestamp"] || log.Timestamp || log.timestamp || "-";
//                 const isAttack = log.status === 'attack' || log.status === 'blocked' || log.status === 'fail';
//                 return (
//                   <tr key={i} onClick={() => setSelectedLog(log)} className="hover:bg-blue-500/[0.03] cursor-pointer transition duration-150 group">
//                     <td className="px-6 py-5 font-bold group-hover:text-blue-500 transition-colors text-gray-800 dark:text-slate-200">{ipValue}</td>
//                     <td className="px-6 py-5 text-sm font-mono text-gray-400">{timestampValue}</td>
//                     <td className="px-6 py-5 text-center">
//                       <span className={`px-4 py-1.5 rounded-lg text-[10px] font-black tracking-widest border ${
//                         isAttack ? 'bg-red-500/10 text-red-500 border-red-500/20' : 'bg-green-500/10 text-green-500 border-green-500/20'
//                       }`}>
//                         {isAttack ? 'ATTACK' : 'NORMAL'}
//                       </span>
//                     </td>
//                   </tr>
//                 );
//               })}
//               {filteredLogs.length === 0 && (
//                 <tr>
//                   <td colSpan="3" className="py-14 text-center text-gray-400 font-bold tracking-widest uppercase italic text-xs">
//                     No matching logs captured in this archive window.
//                   </td>
//                 </tr>
//               )}
//             </tbody>
//           </table>
//         </div>

//         {/* --- Pagination --- */}
//         <div className="flex justify-center items-center gap-4 mt-12">
//           <button
//             onClick={() => setCurrentPage(1)}
//             disabled={currentPage === 1}
//             title="First Page"
//             className="p-3 bg-white dark:bg-[#0f172a] border border-gray-200 dark:border-blue-900/20 rounded-xl text-blue-500 disabled:opacity-20 shadow-lg active:scale-95 transition-transform"
//           >
//             <ChevronsLeft size={20} />
//           </button>

//           <button
//             disabled={currentPage === 1}
//             onClick={() => setCurrentPage(p => Math.max(p - 1, 1))}
//             title="Previous Page"
//             className="p-3 bg-white dark:bg-[#0f172a] border border-gray-200 dark:border-blue-900/20 rounded-xl disabled:opacity-20 text-blue-500 shadow-lg active:scale-95 transition-transform"
//           >
//             <ChevronLeft size={24} />
//           </button>

//           <span className="text-xs font-black bg-white dark:bg-[#0f172a] px-8 py-3 rounded-full border border-gray-200 dark:border-blue-900/20 tracking-[0.2em] shadow-lg">
//             PAGE {filteredLogs.length > 0 ? currentPage : 0} OF {totalPages}
//           </span>

//           <button
//             disabled={currentPage >= totalPages}
//             onClick={() => setCurrentPage(p => Math.min(p + 1, totalPages))}
//             title="Next Page"
//             className="p-3 bg-white dark:bg-[#0f172a] border border-gray-200 dark:border-blue-900/20 rounded-xl disabled:opacity-20 text-blue-500 shadow-lg active:scale-95 transition-transform"
//           >
//             <ChevronRight size={24} />
//           </button>

//           <button
//             onClick={() => setCurrentPage(totalPages)}
//             disabled={currentPage >= totalPages}
//             title="Last Page"
//             className="p-3 bg-white dark:bg-[#0f172a] border border-gray-200 dark:border-blue-900/20 rounded-xl text-blue-500 disabled:opacity-20 shadow-lg active:scale-95 transition-transform flex items-center justify-center rotate-180"
//           >
//             <ChevronsLeft size={20} />
//           </button>
//         </div>
//       </div>

//       {/* --- Log Intelligence Modal --- */}
//       {selectedLog && (
//         <div className="fixed inset-0 bg-black/80 backdrop-blur-md flex items-center justify-center z-[1000] p-4" onClick={() => setSelectedLog(null)}>
//           <div className="bg-[#0b1120] border border-slate-800/60 w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden" onClick={e => e.stopPropagation()}>
            
//             <div className="p-6 border-b border-slate-900/50 flex justify-between items-center bg-[#070b14] text-white">
//               <h2 className="text-sm font-black uppercase tracking-widest text-slate-100">Log Intelligence</h2>
//               <button onClick={() => setSelectedLog(null)} className="text-slate-400 hover:text-red-500 transition-colors"><X size={20} /></button>
//             </div>
            
//             <div className="p-8 max-h-[75vh] overflow-y-auto custom-scrollbar space-y-6 text-slate-300 font-mono text-xs">
              
//               <div>
//                 <label className="text-[10px] font-black uppercase tracking-widest text-blue-400 block mb-1.5">@timestamp</label>
//                 <p className="text-slate-200 text-sm">{selectedLog["@timestamp"] || selectedLog.Timestamp || selectedLog.timestamp || "-"}</p>
//               </div>

//               <div>
//                 <label className="text-[10px] font-black uppercase tracking-widest text-blue-400 block mb-1.5">source_ip</label>
//                 <p className="text-slate-200 text-sm font-bold tracking-tight">{selectedLog.source_ip || selectedLog.ip || "0.0.0.0"}</p>
//               </div>

//               <div>
//                 <label className="text-[10px] font-black uppercase tracking-widest text-blue-400 block mb-1.5">request_url</label>
//                 <p className="text-slate-200 text-sm break-all">{selectedLog.request_url || selectedLog.request || "/"}</p>
//               </div>

//               <div>
//                 <label className="text-[10px] font-black uppercase tracking-widest text-blue-400 block mb-1.5">Detection Stage</label>
//                 <p className="font-bold text-slate-100 text-sm uppercase tracking-wide">
//                   {(() => {
//                     const stagesStr = String(JSON.stringify(selectedLog.stages || selectedLog.stage || "")).toLowerCase();
//                     if (stagesStr.includes("static_suspect")) return "static engine (high line suspect)";
//                     if (stagesStr.includes("static_mild")) return "static engine (low line suspect)";
//                     if (stagesStr.includes("threat_layer_catch")) return "threat model detection";
//                     if (stagesStr.includes("anomaly_layer_catch")) return "anomaly model detection";
//                     if (stagesStr.includes("ai_override")) return "ai override compliance validation";
//                     return selectedLog.status !== 'normal' && selectedLog.status !== 'success' ? "DETECTION GATEWAY" : "AiSentinel COMPLIANT";
//                   })()}
//                 </p>
//               </div>

//               <div>
//                 <label className="text-[10px] font-black uppercase tracking-widest text-blue-400 block mb-1.5">Attack Type</label>
//                 <p className="font-extrabold text-slate-100 text-sm uppercase">
//                   {selectedLog.sub_type && selectedLog.sub_type !== "None" ? selectedLog.sub_type : (selectedLog.status !== 'normal' && selectedLog.status !== 'success' ? "SUSPICIOUS_EXPLOIT" : "-")}
//                 </p>
//               </div>

//               {/* --- Pipeline Inspection Metrics --- */}
//               <div className="border-t border-b border-slate-900/60 py-6 my-2">
//                 <label className="text-[10px] font-black uppercase tracking-widest text-blue-400 block mb-4">
//                   Pipeline Inspection Metrics
//                 </label>
//                 <div className="grid grid-cols-3 gap-3">
                  
//                   {/* 1. static engine */}
//                   <div className="bg-[#070b14] border border-slate-800/40 p-4 rounded-xl flex flex-col justify-center items-center shadow-inner">
//                     <span className="text-slate-500 text-[9px] font-black uppercase tracking-wider mb-2">1. static engine</span>
//                     <span className={(() => {
//                       const stagesStr = String(JSON.stringify(selectedLog.stages || "")).toLowerCase();
//                       if (stagesStr.includes("static_suspect")) return "text-yellow-400 font-black"; 
//                       if (stagesStr.includes("static_mild")) return "text-emerald-400 font-bold";     
//                       return "text-emerald-400 font-bold";
//                     })()}>
//                       {(() => {
//                         const stagesStr = String(JSON.stringify(selectedLog.stages || "")).toLowerCase();
//                         if (stagesStr.includes("static_suspect")) return "CRITICAL";
//                         if (stagesStr.includes("static_mild")) return "LOW RISK";
//                         return "CLEAN";
//                       })()}
//                     </span>
//                   </div>

//                   {/* 2. threat model */}
//                   <div className="bg-[#070b14] border border-slate-800/40 p-4 rounded-xl flex flex-col justify-center items-center shadow-inner">
//                     <span className="text-slate-500 text-[9px] font-black uppercase tracking-wider mb-2">2. threat model</span>
//                     <span className={(() => {
//                       const stagesStr = String(JSON.stringify(selectedLog.stages || "")).toLowerCase();
//                       if (stagesStr.includes("threat_layer_catch")) return "text-yellow-400 font-black"; 
//                       if (stagesStr.includes("static_suspect") && !stagesStr.includes("ai_confirmed")) return "text-emerald-400 font-bold"; 
//                       return "text-slate-600 font-bold";
//                     })()}>
//                       {(() => {
//                         const stagesStr = String(JSON.stringify(selectedLog.stages || "")).toLowerCase();
//                         if (stagesStr.includes("threat_layer_catch")) return "DETECTED";
//                         if (stagesStr.includes("static_suspect")) {
//                           return stagesStr.includes("ai_confirmed") ? "VOTED ATTACK" : "BYPASSED (OVERRIDE)";
//                         }
//                         return "PASSED";
//                       })()}
//                     </span>
//                   </div>

//                   {/* 3. anomaly model */}
//                   <div className="bg-[#070b14] border border-slate-800/40 p-4 rounded-xl flex flex-col justify-center items-center shadow-inner">
//                     <span className="text-slate-500 text-[9px] font-black uppercase tracking-wider mb-2">3. anomaly model</span>
//                     <span className={(() => {
//                       const stagesStr = String(JSON.stringify(selectedLog.stages || "")).toLowerCase();
//                       if (stagesStr.includes("anomaly_layer_catch")) return "text-yellow-400 font-black";
//                       if (stagesStr.includes("threat_layer_catch")) return "text-emerald-400 font-bold";  
//                       if (stagesStr.includes("static_suspect")) {
//                         return stagesStr.includes("ai_confirmed") ? "text-yellow-400 font-black" : "text-emerald-400 font-bold";
//                       }
//                       return "text-emerald-400 font-bold";
//                     })()}>
//                       {(() => {
//                         const stagesStr = String(JSON.stringify(selectedLog.stages || "")).toLowerCase();
//                         if (stagesStr.includes("anomaly_layer_catch")) return "ANOMALY DETECTED";
//                         if (stagesStr.includes("threat_layer_catch")) return "NOT NEEDED";
//                         if (stagesStr.includes("static_suspect")) {
//                           return stagesStr.includes("ai_confirmed") ? "VOTED ATTACK" : "BYPASSED (OVERRIDE)";
//                         }
//                         return "CLEAN BASELINE";
//                       })()}
//                     </span>
//                   </div>

//                 </div>
//               </div>

//               <div>
//                 <label className="text-[10px] font-black uppercase tracking-widest text-blue-400 block mb-2">status</label>
//                 <p className="text-slate-200 text-sm tracking-wide lowercase">{selectedLog.status || "normal"}</p>
//               </div>

//             </div>
//           </div>
//         </div>
//       )}
//     </div>
//   );
// };

// export default LogsHistory;











// import React, { useState, useEffect } from 'react';
// import { ChevronLeft, ChevronRight, ChevronsLeft, Search, ArrowLeft, X, Shield, RefreshCw, Download, Calendar } from 'lucide-react';

// const LogsHistory = ({ onBack }) => {
//   const currentYear = "2026";
//   const [allLogs, setAllLogs] = useState([]); 
//   const [currentPage, setCurrentPage] = useState(1);
//   const [searchTerm, setSearchTerm] = useState('');
//   const [selectedLog, setSelectedLog] = useState(null);
//   const [selectedDate, setSelectedDate] = useState("");
//   const logsPerPage = 15;

//   const fetchHistory = async () => {
//     const token = localStorage.getItem('token');
//     const url = `http://localhost:8000/api/logs`;
    
//     try {
//       const response = await fetch(url, { headers: { 'Authorization': `Bearer ${token}` } });
//       const result = await response.json();
      
//       if (result && Array.isArray(result)) {
//         setAllLogs(result.reverse());
//       } else {
//         setAllLogs([]);
//       }
//     } catch (error) { 
//       console.error("Error fetching history:", error); 
//       setAllLogs([]);
//     }
//   };

//   useEffect(() => { 
//     fetchHistory(); 
//   }, []);

//   const handleRefresh = () => {
//     setSearchTerm('');
//     setCurrentPage(1);
//     setSelectedDate(""); 
//     fetchHistory();
//   };

//   const filteredLogs = allLogs.filter(log => {
//     const logTimestamp = log["@timestamp"] || log.Timestamp || log.timestamp || "";
//     let logDate = logTimestamp.includes(" ") ? logTimestamp.split(" ")[0] : (logTimestamp.includes("T") ? logTimestamp.split("T")[0] : logTimestamp);
//     const matchesDate = selectedDate ? logDate.trim() === selectedDate.trim() : true;

//     const query = searchTerm.toLowerCase().trim();
//     if (!query) return matchesDate;

//     const ip = String(log.source_ip || log.ip || "").toLowerCase();
//     const status = String(log.status || "").toLowerCase();
//     const attackType = String(log.sub_type || "").toLowerCase();
//     const stagesStr = String(JSON.stringify(log.stages || log.stage || "")).toLowerCase();
    
//     const isLogAttack = status === 'attack' || status === 'blocked' || status === 'fail' || (attackType !== 'none' && attackType !== '');

//     let matchesSearch = false;
    
//     if (query === "normal") {
//       matchesSearch = !isLogAttack;
//     } else if (query === "attack") {
//       matchesSearch = isLogAttack;
//     } else if (query === "static") {
//       matchesSearch = isLogAttack && stagesStr.includes("static");
//     } else if (query === "threat") {
//       matchesSearch = isLogAttack && stagesStr.includes("threat");
//     } else if (query === "anomaly") {
//       matchesSearch = isLogAttack && stagesStr.includes("anomaly");
//     } else {
//       matchesSearch = ip.includes(query) || attackType.includes(query) || status.includes(query);
//     }

//     return matchesDate && matchesSearch;
//   });

//   const totalPages = Math.ceil(filteredLogs.length / logsPerPage) || 1;
//   const indexOfLastLog = currentPage * logsPerPage;
//   const indexOfFirstLog = indexOfLastLog - logsPerPage;
//   const currentLogs = filteredLogs.slice(indexOfFirstLog, indexOfLastLog);

//   const handleExportCSV = async () => {
//     if (allLogs.length === 0) {
//         return alert("No logs found in backend archive to export!");
//     }
//     try {
//       const logsToExport = allLogs.filter(log => {
//         if (!selectedDate) return true;
//         const logTimestamp = log["@timestamp"] || log.Timestamp || log.timestamp || "";
//         let logDate = logTimestamp.includes(" ") ? logTimestamp.split(" ")[0] : (logTimestamp.includes("T") ? logTimestamp.split("T")[0] : logTimestamp);
//         return logDate.trim() === selectedDate.trim();
//       });

//       if (logsToExport.length === 0) {
//         return alert("No logs found for the selected date to export!");
//       }

//       const headers = Object.keys(logsToExport[0]).join(",");
//       const rows = logsToExport.map(log => 
//         Object.values(log).map(val => {
//           const cleanVal = String(val).replace(/"/g, '""').replace(/\n/g, ' ');
//           return `"${cleanVal}"`;
//         }).join(",")
//       );
      
//       const csvContent = "data:text/csv;charset=utf-8,\uFEFF" + [headers, ...rows].join("\n");
//       const encodedUri = encodeURI(csvContent);
      
//       const link = document.createElement("a");
//       link.setAttribute("href", encodedUri);
      
//       const filenameSuffix = selectedDate ? selectedDate : "Full_System_Report";
//       link.setAttribute("download", `AiSentinel_Report_${filenameSuffix}.csv`);
      
//       document.body.appendChild(link);
//       link.click();
//       document.body.removeChild(link);
//     } catch (error) {
//       console.error("Export failed:", error);
//     }
//   };

//   return (
//     <div className="min-h-screen bg-gray-50 dark:bg-[#060a14] text-gray-900 dark:text-white p-8 relative transition-colors duration-300">
//       <div className="max-w-6xl mx-auto pb-10">

//         {/* --- Header --- */}
//         <header className="mb-12">
//           <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
//             <div className="flex items-center gap-6">
//               <button onClick={onBack} className="p-3 bg-white dark:bg-[#0f172a] border border-gray-200 dark:border-white/5 hover:border-blue-500/50 rounded-2xl transition-all shadow-xl group">
//                 <ArrowLeft size={24} className="group-hover:-translate-x-1 transition-transform text-blue-500" />
//               </button>
//               <div>
//                 <h1 className="text-4xl font-black uppercase tracking-tighter flex items-center gap-3">
//                   <span className="bg-gradient-to-r from-blue-600 to-blue-400 bg-clip-text text-transparent">Logs</span> Archive
//                 </h1>
//                 <div className="h-1 w-20 bg-blue-600 mt-2 rounded-full shadow-[0_0_10px_#2563eb]"></div>
//               </div>
//             </div>
            
//             <div className="flex items-center gap-4 w-full md:w-auto">
//               <div className="relative flex items-center bg-white dark:bg-[#060a14] border border-gray-200 dark:border-white/10 rounded-xl px-4 py-2.5 group hover:border-blue-500/50 transition-colors shadow-md">
//                 <Calendar size={14} className="text-blue-500 mr-2.5" />
//                 <input
//                   type="date"
//                   value={selectedDate}
//                   onChange={(e) => {
//                     setSelectedDate(e.target.value);
//                     setCurrentPage(1); 
//                   }}
//                   className="bg-transparent text-xs font-black font-mono outline-none cursor-pointer text-gray-700 dark:text-slate-200 w-36 focus:text-blue-500"
//                 />
//                 {selectedDate && (
//                   <button 
//                     onClick={(e) => {
//                       e.stopPropagation();
//                       setSelectedDate("");
//                       setCurrentPage(1);
//                     }} 
//                     className="ml-2 text-gray-400 hover:text-red-500 transition-colors"
//                   >
//                     <X size={14} />
//                   </button>
//                 )}
//               </div>

//               <button
//                 onClick={handleExportCSV}
//                 className="flex-1 md:flex-none flex items-center justify-center gap-2 bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-400 text-white px-6 py-3 rounded-xl font-bold transition-all shadow-lg shadow-blue-500/20 active:scale-95"
//               >
//                 <Download size={18} /> Export CSV
//               </button>
//             </div>
//           </div>
//         </header>

//         {/* --- Search Input --- */}
//         <div className="relative flex gap-3 w-full mb-8">
//           <div className="relative flex-grow group">
//             <Search className="absolute left-4 top-3.5 text-gray-400 group-focus-within:text-blue-500 transition-colors" size={20} />
//             <input
//               type="text"
//               value={searchTerm}
//               placeholder="Search by IP, status, Attack_Type, or engine (static, threat, anomaly)..."
//               className="w-full bg-white dark:bg-[#0f172a] border border-gray-200 dark:border-blue-900/20 rounded-2xl py-3.5 pl-12 pr-12 focus:border-blue-500 outline-none transition-all shadow-lg"
//               onChange={(e) => {
//                 setSearchTerm(e.target.value);
//                 setCurrentPage(1);
//               }}
//             />
//             {searchTerm && (
//               <button onClick={() => { setSearchTerm(''); setCurrentPage(1); }} className="absolute right-4 top-3.5 text-gray-400 hover:text-red-500 transition-colors">
//                 <X size={20} />
//               </button>
//             )}
//           </div>
//           <button onClick={handleRefresh} title="Reset & Refresh" className="p-3 bg-white dark:bg-[#0f172a] border border-gray-200 dark:border-blue-900/20 rounded-2xl text-white hover:bg-blue-500/10 transition-all shadow-lg group">
//             <RefreshCw size={24} className="group-active:rotate-180 transition-transform duration-500 text-gray-400 dark:text-white" />
//           </button>
//         </div>

//         {/* --- Table --- */}
//         <div className="bg-white dark:bg-[#0f172a] rounded-[2rem] border border-gray-200 dark:border-blue-900/20 overflow-hidden shadow-2xl">
//           <table className="w-full text-left">
//             <thead className="bg-gray-50 dark:bg-[#060a14]/50 text-gray-400 text-[10px] uppercase font-black tracking-[0.2em] border-b border-gray-100 dark:border-white/5">
//               <tr>
//                 <th className="px-7 py-5">IP Address</th>
//                 <th className="px-7 py-5">Timestamp</th>
//                 <th className="px-7 py-5 text-center">Status</th>
//               </tr>
//             </thead>
//             <tbody className="divide-y divide-gray-100 dark:divide-white/5">
//               {currentLogs.map((log, i) => {
//                 const ipValue = log.source_ip || log.ip || log.IP || "N/A";
//                 const timestampValue = log["@timestamp"] || log.Timestamp || log.timestamp || "-";
//                 const isAttack = log.status === 'attack' || log.status === 'blocked' || log.status === 'fail';
//                 return (
//                   <tr key={i} onClick={() => setSelectedLog(log)} className="hover:bg-blue-500/[0.03] cursor-pointer transition duration-150 group">
//                     <td className="px-6 py-5 font-bold group-hover:text-blue-500 transition-colors text-gray-800 dark:text-slate-200">{ipValue}</td>
//                     <td className="px-6 py-5 text-sm font-mono text-gray-400">{timestampValue}</td>
//                     <td className="px-6 py-5 text-center">
//                       <span className={`px-4 py-1.5 rounded-lg text-[10px] font-black tracking-widest border ${
//                         isAttack ? 'bg-red-500/10 text-red-500 border-red-500/20' : 'bg-green-500/10 text-green-500 border-green-500/20'
//                       }`}>
//                         {isAttack ? 'ATTACK' : 'NORMAL'}
//                       </span>
//                     </td>
//                   </tr>
//                 );
//               })}
//               {filteredLogs.length === 0 && (
//                 <tr>
//                   <td colSpan="3" className="py-14 text-center text-gray-400 font-bold tracking-widest uppercase italic text-xs">
//                     No matching logs captured in this archive window.
//                   </td>
//                 </tr>
//               )}
//             </tbody>
//           </table>
//         </div>

//         {/* --- Pagination --- */}
//         <div className="flex justify-center items-center gap-4 mt-12">
//           <button onClick={() => setCurrentPage(1)} disabled={currentPage === 1} className="p-3 bg-white dark:bg-[#0f172a] border border-gray-200 dark:border-blue-900/20 rounded-xl text-blue-500 disabled:opacity-20 shadow-lg">
//             <ChevronsLeft size={20} />
//           </button>
//           <button disabled={currentPage === 1} onClick={() => setCurrentPage(p => Math.max(p - 1, 1))} className="p-3 bg-white dark:bg-[#0f172a] border border-gray-200 dark:border-blue-900/20 rounded-xl disabled:opacity-20 text-blue-500 shadow-lg">
//             <ChevronLeft size={24} />
//           </button>
//           <span className="text-xs font-black bg-white dark:bg-[#0f172a] px-8 py-3 rounded-full border border-gray-200 dark:border-blue-900/20 tracking-[0.2em] shadow-lg">
//             PAGE {filteredLogs.length > 0 ? currentPage : 0} OF {totalPages}
//           </span>
//           <button disabled={currentPage >= totalPages} onClick={() => setCurrentPage(p => Math.min(p + 1, totalPages))} className="p-3 bg-white dark:bg-[#0f172a] border border-gray-200 dark:border-blue-900/20 rounded-xl disabled:opacity-20 text-blue-500 shadow-lg">
//             <ChevronRight size={24} />
//           </button>
//         </div>
//       </div>

//       {/* --- Log Intelligence Modal --- */}
//       {selectedLog && (
//         <div className="fixed inset-0 bg-black/80 backdrop-blur-md flex items-center justify-center z-[1000] p-4" onClick={() => setSelectedLog(null)}>
//           <div className="bg-[#0b1120] border border-slate-800/60 w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden" onClick={e => e.stopPropagation()}>
            
//             <div className="p-6 border-b border-slate-900/50 flex justify-between items-center bg-[#070b14] text-white">
//               <h2 className="text-sm font-black uppercase tracking-widest text-slate-100">Log Intelligence</h2>
//               <button onClick={() => setSelectedLog(null)} className="text-slate-400 hover:text-red-500 transition-colors"><X size={20} /></button>
//             </div>
            
//             <div className="p-8 max-h-[75vh] overflow-y-auto custom-scrollbar space-y-6 text-slate-300 font-mono text-xs">
              
//               <div>
//                 <label className="text-[10px] font-black uppercase tracking-widest text-blue-400 block mb-1.5">@timestamp</label>
//                 <p className="text-slate-200 text-sm">{selectedLog["@timestamp"] || selectedLog.Timestamp || selectedLog.timestamp || "-"}</p>
//               </div>

//               <div>
//                 <label className="text-[10px] font-black uppercase tracking-widest text-blue-400 block mb-1.5">source_ip</label>
//                 <p className="text-slate-200 text-sm font-bold tracking-tight">{selectedLog.source_ip || selectedLog.ip || "0.0.0.0"}</p>
//               </div>

//               <div>
//                 <label className="text-[10px] font-black uppercase tracking-widest text-blue-400 block mb-1.5">request_url</label>
//                 <p className="text-slate-200 text-sm break-all">{selectedLog.request_url || selectedLog.request || "/"}</p>
//               </div>

//               <div>
//                 <label className="text-[10px] font-black uppercase tracking-widest text-blue-400 block mb-1.5">Detection Stage</label>
//                 <p className="font-bold text-slate-100 text-sm uppercase tracking-wide">
//                   {(() => {
//                     const stagesStr = String(JSON.stringify(selectedLog.stages || selectedLog.stage || "")).toLowerCase();
//                     if (stagesStr.includes("static")) return "static engine";
//                     if (stagesStr.includes("threat")) return "threat model";
//                     if (stagesStr.includes("anomaly")) return "anomaly model";
//                     return selectedLog.status !== 'normal' && selectedLog.status !== 'success' ? "DETECTION GATEWAY" : "CORE WAF COMPLIANT";
//                   })()}
//                 </p>
//               </div>

//               <div>
//                 <label className="text-[10px] font-black uppercase tracking-widest text-blue-400 block mb-1.5">Attack Type</label>
//                 <p className="font-extrabold text-slate-100 text-sm uppercase">
//                   {selectedLog.sub_type && selectedLog.sub_type !== "None" ? selectedLog.sub_type : (selectedLog.status !== 'normal' && selectedLog.status !== 'success' ? "SUSPICIOUS_EXPLOIT" : "-")}
//                 </p>
//               </div>

//               {/* --- Pipeline Inspection Metrics --- */}
//               <div className="border-t border-b border-slate-900/60 py-6 my-2">
//                 <label className="text-[10px] font-black uppercase tracking-widest text-blue-400 block mb-4">
//                   Pipeline Inspection Metrics
//                 </label>
//                 <div className="grid grid-cols-3 gap-3">
                  
//                   {/* 1. static engine */}
//                   <div className="bg-[#070b14] border border-slate-800/40 p-4 rounded-xl flex flex-col justify-center items-center shadow-inner">
//                     <span className="text-slate-500 text-[9px] font-black uppercase tracking-wider mb-2">1. static engine</span>
//                     <span className={`text-[13px] font-black tracking-wide ${String(selectedLog.stages).toLowerCase().includes("static") ? "text-amber-400" : "text-slate-600 font-bold"}`}>
//                       {String(selectedLog.stages).toLowerCase().includes("static") ? "CRITICAL" : "LOW (PASSED)"}
//                     </span>
//                   </div>

//                   {/* 2. threat model */}
//                   <div className="bg-[#070b14] border border-slate-800/40 p-4 rounded-xl flex flex-col justify-center items-center shadow-inner">
//                     <span className="text-slate-500 text-[9px] font-black uppercase tracking-wider mb-2">2. threat model</span>
//                     <span className="text-[13px] font-black tracking-wide">
//                       {(() => {
//                         const stagesStr = String(JSON.stringify(selectedLog.stages || "")).toLowerCase();
//                         if (stagesStr.includes("static") && !stagesStr.includes("threat")) return <span className="text-slate-600 font-bold">BYPASSED</span>;
//                         if (stagesStr.includes("threat")) return <span className="text-orange-400 font-black">{selectedLog.anomaly_score || "0.75"} / 0.70</span>;
//                         return <span className="text-emerald-400 font-bold">PASSED</span>;
//                       })()}
//                     </span>
//                   </div>

//                   {/* 3. anomaly model */}
//                   <div className="bg-[#070b14] border border-slate-800/40 p-4 rounded-xl flex flex-col justify-center items-center shadow-inner">
//                     <span className="text-slate-500 text-[9px] font-black uppercase tracking-wider mb-2">3. anomaly model</span>
//                     <span className="text-[13px] font-black tracking-wide">
//                       {(() => {
//                         const stagesStr = String(JSON.stringify(selectedLog.stages || "")).toLowerCase();
//                         if (stagesStr.includes("static") || stagesStr.includes("threat")) return <span className="text-slate-600 font-bold">NOT REACHED</span>;
//                         if (stagesStr.includes("anomaly") || selectedLog.anomaly_score > 0) return <span className="text-orange-400 font-black">{selectedLog.anomaly_score || "0.68"} / 0.65</span>;
//                         return <span className="text-emerald-400 font-bold">PASSED</span>;
//                       })()}
//                     </span>
//                   </div>

//                 </div>
//               </div>

//               <div>
//                 <label className="text-[10px] font-black uppercase tracking-widest text-blue-400 block mb-2">status</label>
//                 <p className="text-slate-200 text-sm tracking-wide lowercase">{selectedLog.status || "normal"}</p>
//               </div>

//             </div>
//           </div>
//         </div>
//       )}
//     </div>
//   );
// };

// export default LogsHistory;

// import React, { useState, useEffect } from 'react';
// import { ChevronLeft, ChevronRight, ChevronsLeft, Search, ArrowLeft, X, Shield, RefreshCw, Download, Calendar } from 'lucide-react';

// const LogsHistory = ({ onBack }) => {
//   const currentYear = "2026";
//   const [allLogs, setAllLogs] = useState([]); 
//   const [currentPage, setCurrentPage] = useState(1);
//   const [searchTerm, setSearchTerm] = useState('');
//   const [selectedLog, setSelectedLog] = useState(null);
//   const [selectedDate, setSelectedDate] = useState("");
//   const logsPerPage = 15;

//   const fetchHistory = async () => {
//     const token = localStorage.getItem('token');
//     const url = `http://localhost:8000/api/logs`;
    
//     try {
//       const response = await fetch(url, { headers: { 'Authorization': `Bearer ${token}` } });
//       const result = await response.json();
      
//       if (result && Array.isArray(result)) {
//         setAllLogs(result.reverse());
//       } else {
//         setAllLogs([]);
//       }
//     } catch (error) { 
//       console.error("Error fetching history:", error); 
//       setAllLogs([]);
//     }
//   };

//   useEffect(() => { 
//     fetchHistory(); 
//   }, []);

//   const handleRefresh = () => {
//     setSearchTerm('');
//     setCurrentPage(1);
//     setSelectedDate(""); 
//     fetchHistory();
//   };

//   // 🚨 مصفوفة الفلترة الخارقة بعد دعم الفلترة الذكية بالـ Engines (static, threat, anomaly) 🚨
//   const filteredLogs = allLogs.filter(log => {
//     // أ- فلترة التاريخ
//     const logTimestamp = log["@timestamp"] || log.Timestamp || log.timestamp || "";
//     let logDate = logTimestamp.includes(" ") ? logTimestamp.split(" ")[0] : (logTimestamp.includes("T") ? logTimestamp.split("T")[0] : logTimestamp);
//     const matchesDate = selectedDate ? logDate.trim() === selectedDate.trim() : true;

//     // ب- فلترة حقل البحث الشامل المستقر والذكي
//     const query = searchTerm.toLowerCase().trim();
//     if (!query) return matchesDate;

//     const ip = String(log.source_ip || log.ip || "").toLowerCase();
//     const status = String(log.status || "").toLowerCase();
//     const attackType = String(log.sub_type || "").toLowerCase();
//     const stagesStr = String(JSON.stringify(log.stages || log.stage || "")).toLowerCase();
    
//     const isLogAttack = status === 'attack' || status === 'blocked' || status === 'fail' || (attackType !== 'none' && attackType !== '');

//     let matchesSearch = false;
    
//     // الفلاتر الدلالية المخصصة للـ Engines والـ Status
//     if (query === "normal") {
//       matchesSearch = !isLogAttack;
//     } else if (query === "attack") {
//       matchesSearch = isLogAttack;
//     } else if (query === "static") {
//       matchesSearch = isLogAttack && stagesStr.includes("static");
//     } else if (query === "threat") {
//       matchesSearch = isLogAttack && stagesStr.includes("threat");
//     } else if (query === "anomaly") {
//       matchesSearch = isLogAttack && stagesStr.includes("anomaly");
//     } else {
//       // البحث الطبيعي بالـ IP أو نوع الهجوم (XSS, SQLi, etc.)
//       matchesSearch = ip.includes(query) || attackType.includes(query) || status.includes(query);
//     }

//     return matchesDate && matchesSearch;
//   });

//   const totalPages = Math.ceil(filteredLogs.length / logsPerPage) || 1;
//   const indexOfLastLog = currentPage * logsPerPage;
//   const indexOfFirstLog = indexOfLastLog - logsPerPage;
//   const currentLogs = filteredLogs.slice(indexOfFirstLog, indexOfLastLog);

//   const handleExportCSV = async () => {
//     if (allLogs.length === 0) {
//         return alert("No logs found in backend archive to export!");
//     }
//     try {
//       const headers = Object.keys(allLogs[0]).join(",");
//       const rows = allLogs.map(log => 
//         Object.values(log).map(val => {
//           const cleanVal = String(val).replace(/"/g, '""').replace(/\n/g, ' ');
//           return `"${cleanVal}"`;
//         }).join(",")
//       );
      
//       const csvContent = "data:text/csv;charset=utf-8,\uFEFF" + [headers, ...rows].join("\n");
//       const encodedUri = encodeURI(csvContent);
      
//       const link = document.createElement("a");
//       link.setAttribute("href", encodedUri);
//       link.setAttribute("download", `AiSentinel_Full_Report_${new Date().toISOString().split('T')[0]}.csv`);
//       document.body.appendChild(link);
//       link.click();
//       document.body.removeChild(link);
//     } catch (error) {
//       console.error("Export failed:", error);
//     }
//   };

//   return (
//     <div className="min-h-screen bg-gray-50 dark:bg-[#060a14] text-gray-900 dark:text-white p-8 relative transition-colors duration-300">
//       <div className="max-w-6xl mx-auto pb-10">

//         {/* --- Header --- */}
//         <header className="mb-12">
//           <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
//             <div className="flex items-center gap-6">
//               <button onClick={onBack} className="p-3 bg-white dark:bg-[#0f172a] border border-gray-200 dark:border-white/5 hover:border-blue-500/50 rounded-2xl transition-all shadow-xl group">
//                 <ArrowLeft size={24} className="group-hover:-translate-x-1 transition-transform text-blue-500" />
//               </button>
//               <div>
//                 <h1 className="text-4xl font-black uppercase tracking-tighter flex items-center gap-3">
//                   <span className="bg-gradient-to-r from-blue-600 to-blue-400 bg-clip-text text-transparent">Logs</span> Archive
//                 </h1>
//                 <div className="h-1 w-20 bg-blue-600 mt-2 rounded-full shadow-[0_0_10px_#2563eb]"></div>
//               </div>
//             </div>
            
//             <div className="flex items-center gap-4 w-full md:w-auto">
//               <div className="relative flex items-center bg-white dark:bg-[#060a14] border border-gray-200 dark:border-white/10 rounded-xl px-4 py-2.5 group hover:border-blue-500/50 transition-colors shadow-md">
//                 <Calendar size={14} className="text-blue-500 mr-2.5" />
//                 <input
//                   type="date"
//                   value={selectedDate}
//                   onChange={(e) => {
//                     setSelectedDate(e.target.value);
//                     setCurrentPage(1); 
//                   }}
//                   className="bg-transparent text-xs font-black font-mono outline-none cursor-pointer text-gray-700 dark:text-slate-200 w-36 focus:text-blue-500"
//                 />
//                 {selectedDate && (
//                   <button 
//                     onClick={(e) => {
//                       e.stopPropagation();
//                       setSelectedDate("");
//                       setCurrentPage(1);
//                     }} 
//                     className="ml-2 text-gray-400 hover:text-red-500 transition-colors"
//                   >
//                     <X size={14} />
//                   </button>
//                 )}
//               </div>

//               <button
//                 onClick={handleExportCSV}
//                 className="flex-1 md:flex-none flex items-center justify-center gap-2 bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-400 text-white px-6 py-3 rounded-xl font-bold transition-all shadow-lg shadow-blue-500/20 active:scale-95"
//               >
//                 <Download size={18} /> Export CSV
//               </button>
//             </div>
//           </div>
//         </header>

//         {/* --- Search Input --- */}
//         <div className="relative flex gap-3 w-full mb-8">
//           <div className="relative flex-grow group">
//             <Search className="absolute left-4 top-3.5 text-gray-400 group-focus-within:text-blue-500 transition-colors" size={20} />
//             <input
//               type="text"
//               value={searchTerm}
//               placeholder="Search by IP, status, or engine (static, threat, anomaly)..."
//               className="w-full bg-white dark:bg-[#0f172a] border border-gray-200 dark:border-blue-900/20 rounded-2xl py-3.5 pl-12 pr-12 focus:border-blue-500 outline-none transition-all shadow-lg"
//               onChange={(e) => {
//                 setSearchTerm(e.target.value);
//                 setCurrentPage(1);
//               }}
//             />
//             {searchTerm && (
//               <button onClick={() => { setSearchTerm(''); setCurrentPage(1); }} className="absolute right-4 top-3.5 text-gray-400 hover:text-red-500 transition-colors">
//                 <X size={20} />
//               </button>
//             )}
//           </div>
//           <button onClick={handleRefresh} title="Reset & Refresh" className="p-3 bg-white dark:bg-[#0f172a] border border-gray-200 dark:border-blue-900/20 rounded-2xl text-white hover:bg-blue-500/10 transition-all shadow-lg group">
//             <RefreshCw size={24} className="group-active:rotate-180 transition-transform duration-500 text-gray-400 dark:text-white" />
//           </button>
//         </div>

//         {/* --- Table --- */}
//         <div className="bg-white dark:bg-[#0f172a] rounded-[2rem] border border-gray-200 dark:border-blue-900/20 overflow-hidden shadow-2xl">
//           <table className="w-full text-left">
//             <thead className="bg-gray-50 dark:bg-[#060a14]/50 text-gray-400 text-[10px] uppercase font-black tracking-[0.2em] border-b border-gray-100 dark:border-white/5">
//               <tr>
//                 <th className="px-7 py-5">IP Address</th>
//                 <th className="px-7 py-5">Timestamp</th>
//                 <th className="px-7 py-5 text-center">Status</th>
//               </tr>
//             </thead>
//             <tbody className="divide-y divide-gray-100 dark:divide-white/5">
//               {currentLogs.map((log, i) => {
//                 const ipValue = log.source_ip || log.ip || log.IP || "N/A";
//                 const timestampValue = log["@timestamp"] || log.Timestamp || log.timestamp || "-";
//                 const isAttack = log.status === 'attack' || log.status === 'blocked' || log.status === 'fail';
//                 return (
//                   <tr key={i} onClick={() => setSelectedLog(log)} className="hover:bg-blue-500/[0.03] cursor-pointer transition duration-150 group">
//                     <td className="px-6 py-5 font-bold group-hover:text-blue-500 transition-colors text-gray-800 dark:text-slate-200">{ipValue}</td>
//                     <td className="px-6 py-5 text-sm font-mono text-gray-400">{timestampValue}</td>
//                     <td className="px-6 py-5 text-center">
//                       <span className={`px-4 py-1.5 rounded-lg text-[10px] font-black tracking-widest border ${
//                         isAttack ? 'bg-red-500/10 text-red-500 border-red-500/20' : 'bg-green-500/10 text-green-500 border-green-500/20'
//                       }`}>
//                         {isAttack ? 'ATTACK' : 'NORMAL'}
//                       </span>
//                     </td>
//                   </tr>
//                 );
//               })}
//               {filteredLogs.length === 0 && (
//                 <tr>
//                   <td colSpan="3" className="py-14 text-center text-gray-400 font-bold tracking-widest uppercase italic text-xs">
//                     No matching logs captured in this archive window.
//                   </td>
//                 </tr>
//               )}
//             </tbody>
//           </table>
//         </div>

//         {/* --- Pagination --- */}
//         <div className="flex justify-center items-center gap-4 mt-12">
//           <button onClick={() => setCurrentPage(1)} disabled={currentPage === 1} className="p-3 bg-white dark:bg-[#0f172a] border border-gray-200 dark:border-blue-900/20 rounded-xl text-blue-500 disabled:opacity-20 shadow-lg">
//             <ChevronsLeft size={20} />
//           </button>
//           <button disabled={currentPage === 1} onClick={() => setCurrentPage(p => Math.max(p - 1, 1))} className="p-3 bg-white dark:bg-[#0f172a] border border-gray-200 dark:border-blue-900/20 rounded-xl disabled:opacity-20 text-blue-500 shadow-lg">
//             <ChevronLeft size={24} />
//           </button>
//           <span className="text-xs font-black bg-white dark:bg-[#0f172a] px-8 py-3 rounded-full border border-gray-200 dark:border-blue-900/20 tracking-[0.2em] shadow-lg">
//             PAGE {filteredLogs.length > 0 ? currentPage : 0} OF {totalPages}
//           </span>
//           <button disabled={currentPage >= totalPages} onClick={() => setCurrentPage(p => Math.min(p + 1, totalPages))} className="p-3 bg-white dark:bg-[#0f172a] border border-gray-200 dark:border-blue-900/20 rounded-xl disabled:opacity-20 text-blue-500 shadow-lg">
//             <ChevronRight size={24} />
//           </button>
//         </div>
//       </div>

//       {/* --- Log Intelligence Modal --- */}
//       {selectedLog && (
//         <div className="fixed inset-0 bg-black/80 backdrop-blur-md flex items-center justify-center z-[1000] p-4" onClick={() => setSelectedLog(null)}>
//           <div className="bg-[#0b1120] border border-slate-800/60 w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden" onClick={e => e.stopPropagation()}>
            
//             <div className="p-6 border-b border-slate-900/50 flex justify-between items-center bg-[#070b14] text-white">
//               <h2 className="text-sm font-black uppercase tracking-widest text-slate-100">Log Intelligence</h2>
//               <button onClick={() => setSelectedLog(null)} className="text-slate-400 hover:text-red-500 transition-colors"><X size={20} /></button>
//             </div>
            
//             <div className="p-8 max-h-[75vh] overflow-y-auto custom-scrollbar space-y-6 text-slate-300 font-mono text-xs">
              
//               <div>
//                 <label className="text-[10px] font-black uppercase tracking-widest text-blue-400 block mb-1.5">@timestamp</label>
//                 <p className="text-slate-200 text-sm">{selectedLog["@timestamp"] || selectedLog.Timestamp || selectedLog.timestamp || "-"}</p>
//               </div>

//               <div>
//                 <label className="text-[10px] font-black uppercase tracking-widest text-blue-400 block mb-1.5">source_ip</label>
//                 <p className="text-slate-200 text-sm font-bold tracking-tight">{selectedLog.source_ip || selectedLog.ip || "0.0.0.0"}</p>
//               </div>

//               <div>
//                 <label className="text-[10px] font-black uppercase tracking-widest text-blue-400 block mb-1.5">request_url</label>
//                 <p className="text-slate-200 text-sm break-all">{selectedLog.request_url || selectedLog.request || "/"}</p>
//               </div>

//               <div>
//                 <label className="text-[10px] font-black uppercase tracking-widest text-blue-400 block mb-1.5">Detection Stage</label>
//                 <p className="font-bold text-slate-100 text-sm uppercase tracking-wide">
//                   {(() => {
//                     const stagesStr = String(JSON.stringify(selectedLog.stages || selectedLog.stage || "")).toLowerCase();
//                     if (stagesStr.includes("static")) return "STATIC SIGNATURE ENGINE";
//                     if (stagesStr.includes("threat")) return "THREAT ML CORE ENGINE";
//                     if (stagesStr.includes("anomaly")) return "BEHAVIORAL ANOMALY ENGINE";
//                     return selectedLog.status !== 'normal' && selectedLog.status !== 'success' ? "DETECTION GATEWAY" : "CORE WAF COMPLIANT";
//                   })()}
//                 </p>
//               </div>

//               <div>
//                 <label className="text-[10px] font-black uppercase tracking-widest text-blue-400 block mb-1.5">Attack Type</label>
//                 <p className="font-extrabold text-slate-100 text-sm uppercase">
//                   {selectedLog.sub_type && selectedLog.sub_type !== "None" ? selectedLog.sub_type : (selectedLog.status !== 'normal' && selectedLog.status !== 'success' ? "SUSPICIOUS_EXPLOIT" : "-")}
//                 </p>
//               </div>

//               {/* --- Pipeline Inspection Metrics --- */}
//               <div className="border-t border-b border-slate-900/60 py-6 my-2">
//                 <label className="text-[10px] font-black uppercase tracking-widest text-blue-400 block mb-4">
//                   Pipeline Inspection Metrics
//                 </label>
//                 <div className="grid grid-cols-3 gap-3">
                  
//                   {/* 1. static engine */}
//                   <div className="bg-[#070b14] border border-slate-800/40 p-4 rounded-xl flex flex-col justify-center items-center shadow-inner">
//                     <span className="text-slate-500 text-[9px] font-black uppercase tracking-wider mb-2">1. static engine</span>
//                     <span className={`text-[13px] font-black tracking-wide ${String(selectedLog.stages).toLowerCase().includes("static") ? "text-amber-400" : "text-slate-600 font-bold"}`}>
//                       {String(selectedLog.stages).toLowerCase().includes("static") ? "CRITICAL" : "LOW (PASSED)"}
//                     </span>
//                   </div>

//                   {/* 2. threat model */}
//                   <div className="bg-[#070b14] border border-slate-800/40 p-4 rounded-xl flex flex-col justify-center items-center shadow-inner">
//                     <span className="text-slate-500 text-[9px] font-black uppercase tracking-wider mb-2">2. threat model</span>
//                     <span className="text-[13px] font-black tracking-wide">
//                       {(() => {
//                         const stagesStr = String(JSON.stringify(selectedLog.stages || "")).toLowerCase();
//                         if (stagesStr.includes("static") && !stagesStr.includes("threat")) return <span className="text-slate-600 font-bold">BYPASSED</span>;
//                         if (stagesStr.includes("threat")) return <span className="text-orange-400 font-black">{selectedLog.anomaly_score || "0.75"} / 0.70</span>;
//                         return <span className="text-emerald-400 font-bold">PASSED</span>;
//                       })()}
//                     </span>
//                   </div>

//                   {/* 3. anomaly model */}
//                   <div className="bg-[#070b14] border border-slate-800/40 p-4 rounded-xl flex flex-col justify-center items-center shadow-inner">
//                     <span className="text-slate-500 text-[9px] font-black uppercase tracking-wider mb-2">3. anomaly model</span>
//                     <span className="text-[13px] font-black tracking-wide">
//                       {(() => {
//                         const stagesStr = String(JSON.stringify(selectedLog.stages || "")).toLowerCase();
//                         if (stagesStr.includes("static") || stagesStr.includes("threat")) return <span className="text-slate-600 font-bold">NOT REACHED</span>;
//                         if (stagesStr.includes("anomaly") || selectedLog.anomaly_score > 0) return <span className="text-orange-400 font-black">{selectedLog.anomaly_score || "0.68"} / 0.65</span>;
//                         return <span className="text-emerald-400 font-bold">PASSED</span>;
//                       })()}
//                     </span>
//                   </div>

//                 </div>
//               </div>

//               <div>
//                 <label className="text-[10px] font-black uppercase tracking-widest text-blue-400 block mb-2">status</label>
//                 <p className="text-slate-200 text-sm tracking-wide lowercase">{selectedLog.status || "normal"}</p>
//               </div>

//             </div>
//           </div>
//         </div>
//       )}
//     </div>
//   );
// };

// export default LogsHistory;



// import React, { useState, useEffect } from 'react';
// import { ChevronLeft, ChevronRight, ChevronsLeft, Search, ArrowLeft, X, Shield, RefreshCw, Download } from 'lucide-react';

// const LogsHistory = ({ onBack }) => {
//   const [data, setData] = useState({ logs: [], total_pages: 1 });
//   const [page, setPage] = useState(1);
//   const [searchTerm, setSearchTerm] = useState('');
//   const [selectedLog, setSelectedLog] = useState(null);

//   const fetchHistory = async (searchQuery, overridePage) => {
//     const token = localStorage.getItem('token');
//     const currentQuery = typeof searchQuery !== 'undefined' ? searchQuery : searchTerm;
//     const currentPage = typeof overridePage !== 'undefined' ? overridePage : page;
//     const url = `http://localhost:8000/history?page=${currentPage}&size=15${currentQuery ? `&q=${encodeURIComponent(currentQuery)}` : ''}`;
//     // const url = `http://localhost:8000/history?page=${page}&size=15${searchTerm ? `&q=${searchTerm}` : ''}`;
//     try {
//       const response = await fetch(url, { headers: { 'Authorization': `Bearer ${token}` } });
//       const result = await response.json();
      
//       if (result && result.logs) {
//         setData(result);
//       } else {
//         setData({ logs: [], total_pages: 1 });
//       }
//     } catch (error) { 
//       console.error("Error fetching history:", error); 
//       setData({ logs: [], total_pages: 1 });
//     }
//   };

//   useEffect(() => { 
//     fetchHistory(); 
//   }, [page]);

//   const handleRefresh = () => {
//     setSearchTerm('');
//     setPage(1);
//     fetchHistory('', 1);
//   };

//   const handleKeyDown = (e) => {
//     if (e.key === 'Enter') {
//       e.preventDefault();
//       setPage(1);
//       fetchHistory(searchTerm);
//     }
//   };

//   const handleExportCSV = async () => {
//     const token = localStorage.getItem('token');
//     try {
//       const response = await fetch('http://localhost:8000/api/logs', {
//         headers: { 'Authorization': `Bearer ${token}` }
//       });
//       const allLogs = await response.json();

//       if (!allLogs || !Array.isArray(allLogs) || allLogs.length === 0) {
//         return alert("No logs found in backend archive to export!");
//       }

//       const headers = Object.keys(allLogs[0]).join(",");
//       const rows = allLogs.map(log => 
//         Object.values(log).map(val => {
//           const cleanVal = String(val).replace(/"/g, '""').replace(/\n/g, ' ');
//           return `"${cleanVal}"`;
//         }).join(",")
//       );
      
//       const csvContent = "data:text/csv;charset=utf-8,\uFEFF" + [headers, ...rows].join("\n");
//       const encodedUri = encodeURI(csvContent);
      
//       const link = document.createElement("a");
//       link.setAttribute("href", encodedUri);
//       link.setAttribute("download", `AiSentinel_Full_Report_${new Date().toISOString().split('T')[0]}.csv`);
//       document.body.appendChild(link);
//       link.click();
//       document.body.removeChild(link);

//     } catch (error) {
//       console.error("Export failed:", error);
//       alert("Failed to export logs. Connecting to backend failed.");
//     }
//   };
//   // const handleExportCSV = () => {
//   //   if (!data.logs || data.logs.length === 0) return alert("No logs to export!");
//   //   const headers = Object.keys(data.logs[0]).join(",");
//   //   const rows = data.logs.map(log => Object.values(log).map(val => `"${val}"`).join(","));
//   //   const csvContent = "data:text/csv;charset=utf-8," + [headers, ...rows].join("\n");
//   //   const encodedUri = encodeURI(csvContent);
//   //   const link = document.createElement("a");
//   //   link.setAttribute("href", encodedUri);
//   //   link.setAttribute("download", `AiSentinel_Logs_${new Date().toLocaleDateString()}.csv`);
//   //   document.body.appendChild(link);
//   //   link.click();
//   //   document.body.removeChild(link);
//   // };

//   return (
//     <div className="min-h-screen bg-gray-50 dark:bg-[#060a14] text-gray-900 dark:text-white p-8 relative transition-colors duration-300">
//       <div className="max-w-6xl mx-auto pb-10">

//         {/* --- Header --- */}
//         <header className="mb-12">
//           <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
//             <div className="flex items-center gap-6">
//               <button onClick={onBack} className="p-3 bg-white dark:bg-[#0f172a] border border-gray-200 dark:border-white/5 hover:border-blue-500/50 rounded-2xl transition-all shadow-xl group">
//                 <ArrowLeft size={24} className="group-hover:-translate-x-1 transition-transform text-blue-500" />
//               </button>
//               <div>
//                 <h1 className="text-4xl font-black uppercase tracking-tighter flex items-center gap-3">
//                   <span className="bg-gradient-to-r from-blue-600 to-blue-400 bg-clip-text text-transparent">Logs</span> Archive
//                 </h1>
//                 <div className="h-1 w-20 bg-blue-600 mt-2 rounded-full shadow-[0_0_10px_#2563eb]"></div>
//               </div>
//             </div>
//             <div className="flex items-center gap-3 w-full md:w-auto">
//               <button
//                 onClick={handleExportCSV}
//                 className="flex-1 md:flex-none flex items-center justify-center gap-2 bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-400 text-white px-6 py-3 rounded-xl font-bold transition-all shadow-lg shadow-blue-500/20 active:scale-95"
//               >
//                 <Download size={18} /> Export CSV
//               </button>
//             </div>
//             {/* <div className="flex items-center gap-3 w-full md:w-auto">
//               <button
//                 onClick={handleExportCSV}
//                 className="flex-1 md:flex-none flex items-center justify-center gap-2 bg-blue-600/10 hover:bg-blue-600 text-blue-400 hover:text-white px-6 py-3 rounded-xl font-bold border border-blue-500/20 hover:border-blue-500/50 transition-all shadow-lg shadow-blue-500/5 hover:shadow-blue-500/20 active:scale-95"
//               >
//                 <Download size={18} /> Export CSV
//               </button>
//             </div> */}
//           </div>
//         </header>

//         {/* --- Search & Refresh Integrated --- */}
//         <div className="relative flex gap-3 w-full mb-8">
//           <div className="relative flex-grow group">
//             <Search className="absolute left-4 top-3.5 text-gray-400 group-focus-within:text-blue-500 transition-colors" size={20} />
//             <input
//               type="text"
//               value={searchTerm}
//               placeholder="Search by IP, Status, or Attack type..."
//               className="w-full bg-white dark:bg-[#0f172a] border border-gray-200 dark:border-blue-900/20 rounded-2xl py-3.5 pl-12 pr-12 focus:border-blue-500 outline-none transition-all shadow-lg"
//               onChange={(e) => setSearchTerm(e.target.value)}
//               onKeyDown={handleKeyDown}
//             />
//             {searchTerm && (
//               <button onClick={() => { setSearchTerm(''); setPage(1); fetchHistory('', 1);}} className="absolute right-4 top-3.5 text-gray-400 hover:text-red-500 transition-colors">
//                 <X size={20} />
//               </button>
//             )}
//           </div>
//           <button onClick={handleRefresh} title="Reset & Refresh" className="p-3 bg-white dark:bg-[#0f172a] border border-gray-200 dark:border-blue-900/20 rounded-2xl text-white hover:bg-blue-500/10 transition-all shadow-lg group">
//             <RefreshCw size={24} className="group-active:rotate-180 transition-transform duration-500" />
//           </button>
//         </div>

//         {/* --- Table --- */}
//         <div className="bg-white dark:bg-[#0f172a] rounded-[2rem] border border-gray-200 dark:border-blue-900/20 overflow-hidden shadow-2xl">
//           <table className="w-full text-left">
//             <thead className="bg-gray-50 dark:bg-[#060a14]/50 text-gray-400 text-[10px] uppercase font-black tracking-[0.2em] border-b border-gray-100 dark:border-white/5">
//               <tr>
//                 <th className="px-7 py-5">IP Address</th>
//                 <th className="px-7 py-5">Timestamp</th>
//                 <th className="px-7 py-5 text-center">Status</th>
//               </tr>
//             </thead>
//             <tbody className="divide-y divide-gray-100 dark:divide-white/5">
//               {data.logs?.map((log, i) => {
//                 const ipValue = log.ip || log.source_ip || log.IP || "N/A";
//                 const requestPath = log.request_url || log.request || "/";
//                 // const timeValue = log["@timestamp"] || log.Timestamp || log.timestamp || "N/A";
//                 const isAttack = log.status === 'attack' || log.status === 'blocked' || log.status === 'fail';
//                 return (
//                   <tr key={i} onClick={() => setSelectedLog(log)} className="hover:bg-blue-500/[0.03] cursor-pointer transition duration-150 group">
//                     <td className="px-6 py-5 font-bold group-hover:text-blue-500 transition-colors">{ipValue}</td>
//                     <td className="px-6 py-5 text-sm font-mono text-gray-400">{log.Timestamp || log.timestamp}</td>
//                     <td className="px-6 py-5 text-center">
//                       <span className={`px-4 py-1.5 rounded-lg text-[10px] font-black tracking-widest border ${isAttack ? 'bg-red-500/10 text-red-500 border-red-500/20' : 'bg-green-500/10 text-green-500 border-green-500/20'
//                         }`}>
//                         {isAttack ? 'ATTACK' : 'NORMAL'}
//                       </span>
//                     </td>
//                   </tr>
//                 );
//               })}
//             </tbody>
//           </table>
//         </div>

//         {/* --- Pagination --- */}
//         <div className="flex justify-center items-center gap-4 mt-12">
//           <button onClick={() => setPage(1)} disabled={page === 1} className="p-3 bg-white dark:bg-[#0f172a] border border-gray-200 dark:border-blue-900/20 rounded-xl text-blue-500 disabled:opacity-20 shadow-lg">
//             <ChevronsLeft size={20} />
//           </button>
//           <button disabled={page === 1} onClick={() => setPage(p => p - 1)} className="p-3 bg-white dark:bg-[#0f172a] border border-gray-200 dark:border-blue-900/20 rounded-xl disabled:opacity-20 text-blue-500 shadow-lg">
//             <ChevronLeft size={24} />
//           </button>
//           <span className="text-xs font-black bg-white dark:bg-[#0f172a] px-8 py-3 rounded-full border border-gray-200 dark:border-blue-900/20 tracking-[0.2em] shadow-lg">
//             PAGE {data.logs?.length > 0 ? page : 0} OF {data.total_pages || 0}
//           </span>
//           <button disabled={page >= data.total_pages || data.logs?.length === 0} onClick={() => setPage(p => p + 1)} className="p-3 bg-white dark:bg-[#0f172a] border border-gray-200 dark:border-blue-900/20 rounded-xl disabled:opacity-20 text-blue-500 shadow-lg">
//             <ChevronRight size={24} />
//           </button>
//         </div>
//       </div>

//       {/* Modal Details  */}
//       {selectedLog && (
//         <div className="fixed inset-0 bg-black/80 backdrop-blur-md flex items-center justify-center z-[1000] p-4" onClick={() => setSelectedLog(null)}>
//           <div className="bg-white dark:bg-[#0f172a] border border-white/5 w-full max-w-2xl rounded-[2.5rem] shadow-2xl overflow-hidden" onClick={e => e.stopPropagation()}>
//             <div className="p-8 border-b border-white/5 flex justify-between items-center bg-[#060a14]/50 text-white">
//               <h2 className="text-xl font-black uppercase tracking-tight">Log Intelligence</h2>
//               <button onClick={() => setSelectedLog(null)}><X size={28} /></button>
//             </div>
//             <div className="p-8 max-h-[60vh] overflow-y-auto custom-scrollbar font-mono text-sm">
//               {Object.entries(selectedLog).map(([k, v]) => (
//                 <div key={k} className="flex flex-col border-b border-white/5 pb-3 mb-3">
//                   <span className="text-blue-500 text-[10px] font-black uppercase mb-1">{k}</span>
//                   <span className="break-all dark:text-slate-300">{String(v)}</span>
//                 </div>
//               ))}
//             </div>
//           </div>
//         </div>
//       )}
//     </div>
//   );
// };

// export default LogsHistory;
