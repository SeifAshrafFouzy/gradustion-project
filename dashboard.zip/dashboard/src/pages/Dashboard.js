import React, { useState, useEffect } from 'react';
import { Activity, ShieldCheck, ShieldAlert, GlobeLock } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

const StatCard = ({ title, value, icon }) => (
  <div className="bg-[#0f172a] border border-white/5 rounded-[2rem] p-6 shadow-2xl relative group overflow-hidden transition-all duration-500 hover:-translate-y-1.5 flex flex-col justify-between">
    <div className="absolute -right-12 -top-12 w-32 h-32 bg-blue-500/10 rounded-full blur-[60px] group-hover:blur-[45px] transition-all duration-700 pointer-events-none" />
    <div className="flex items-center justify-between relative z-10">
      <div>
        <p className="text-[10px] font-black text-blue-500 uppercase tracking-[0.2em] mb-1">
          {title}
        </p>
        <h3 className="text-3xl font-bold tracking-tighter text-white">
          {value}
        </h3>
      </div>
      <div className="p-3 rounded-xl bg-[#060a14]/50 border border-white/5 text-blue-500 group-hover:scale-105 transition-transform duration-500">
        {icon}
      </div>
    </div>
    <div className="absolute bottom-0 left-0 h-[3px] bg-blue-500 w-0 group-hover:w-full transition-all duration-500 shadow-[0_0_15px_#2563eb]" />
  </div>
);

const Dashboard = ({ 
  stats = { totalLogs: "0", normalTraffic: "0", activeThreats: 0, blockedIPs: 0 }, 
  recentAlerts = [],
  onUnbanIP 
}) => {
  const [timelineData, setTimelineData] = useState([]);
  const [blockedIPsList, setBlockedIPsList] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 5; // تقدري ترفعي الرقم ده لـ 10 لو حابة يعرض سطور أكتر في الصفحة الواحدة
  const currentUserRole = localStorage.getItem('role') || 'analyst';
  const isSuperAdmin = currentUserRole === 'super_admin';

  // 🛠️ لوجيك تفاعلي مطور للـ Graph: يحسب عدد الهجمات في اللحظة الحالية ليعطي حركة صعود وهبوط حية
  useEffect(() => {
    const interval = setInterval(() => {
      const now = new Date();
      // عد البلاغات الحظر الحقيقية اللي حصلت في آخر 4 ثواني فقط
      const activeRightNow = recentAlerts.filter(alert => {
        if (!alert.timestamp) return false;
        const alertTime = new Date(alert.timestamp);
        return (now - alertTime) / 1000 <= 4 && (alert.status === 'blocked' || alert.severity === 'High');
      }).length;

      setTimelineData(current => {
        const updated = [...current, {
          time: now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
          threats: activeRightNow
        }];
        return updated.slice(-15); // الاحتفاظ بآخر 15 ثانية فقط على الشاشة لمنع التكدس
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [recentAlerts]);

  // useEffect(() => {
  //   const initialBlocked = recentAlerts
  //     .filter(alert => alert.severity === 'High' || alert.status === 'blocked')
  //     .map(alert => ({
  //       ...alert,
  //       bannedAt: alert.timestamp ? new Date(alert.timestamp) : new Date(), 
  //     }));
  //   setBlockedIPsList(initialBlocked);
  // }, [recentAlerts]);
  useEffect(() => {
    // 1. تصفية البلاغات المحظورة أولاً
    const blockedAlerts = recentAlerts.filter(
      alert => alert.severity === 'High' || alert.status === 'blocked'
    );

    // 2. استخدام Map لإزالة تكرار الـ IP والاحتفاظ بأحدث ظهور له
    const uniqueIPsMap = new Map();

    blockedAlerts.forEach(alert => {
      if (alert.ip) {
        const existing = uniqueIPsMap.get(alert.ip);
        const currentAlertTime = alert.timestamp ? new Date(alert.timestamp) : new Date();

        // لو الـ IP مش موجود، أو الموجود قديم والريكوست الحالي أحدث -> حدّث البيانات
        if (!existing || currentAlertTime > existing.bannedAt) {
          uniqueIPsMap.set(alert.ip, {
            ...alert,
            bannedAt: currentAlertTime
          });
        }
      }
    });

    // 3. تحويل الـ Map من جديد إلى Array نظيف ووضعه في الستيت
    setBlockedIPsList(Array.from(uniqueIPsMap.values()));
  }, [recentAlerts]);

  useEffect(() => {
    const interval = setInterval(() => {
      const now = new Date();
      setBlockedIPsList(currentList => {
        return currentList.filter(ip => {
          const timeDifference = (now - ip.bannedAt) / 1000 / 60; 
          return timeDifference < 10; 
        });
      });
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const handleUnbanClick = (ipToUnban) => {
    if (!isSuperAdmin) return;
    setBlockedIPsList(current => current.filter(item => item.ip !== ipToUnban));
    if (onUnbanIP) onUnbanIP(ipToUnban);
  };

  const totalPages = Math.ceil(blockedIPsList.length / itemsPerPage) || 1;
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentBlockedIPs = blockedIPsList.slice(indexOfFirstItem, indexOfLastItem);

  const totalLogsNum = parseInt(stats.totalLogs.replace(/,/g, '')) || 0;
  const normalLogsCount = stats.normalTraffic.includes('%') 
    ? Math.max(0, totalLogsNum - stats.activeThreats)
    : stats.normalTraffic;

  return (
    <div className="space-y-10 animate-fadeIn pb-20">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard title="Total Logs" value={stats.totalLogs} icon={<Activity size={24} />} />
        <StatCard title="Normal Traffic" value={String(normalLogsCount)} icon={<ShieldCheck size={24} />} />
        <StatCard title="Active Threats" value={String(stats.activeThreats)} icon={<ShieldAlert size={24} />} />
        <StatCard title="Blocked IPs" value={String(blockedIPsList.length)} icon={<GlobeLock size={24} />} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-[#0f172a] border border-blue-900/20 p-8 rounded-[2rem] shadow-2xl">
          <div className="flex items-center justify-between mb-8">
            <h4 className="text-sm font-bold text-white uppercase tracking-widest">Threat Detection Timeline</h4>
            <span className="flex items-center gap-2 text-[10px] text-emerald-500 font-black uppercase tracking-widest bg-emerald-500/10 px-3 py-1 rounded-full">
               <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span> Live Sync
            </span>
          </div>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={timelineData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#ffffff05" vertical={false} />
              <XAxis dataKey="time" stroke="#475569" fontSize={11} fontWeight="bold" tickLine={false} axisLine={false} />
              <YAxis stroke="#475569" fontSize={10} tickLine={false} axisLine={false} allowDecimals={false} />
              <Tooltip contentStyle={{ backgroundColor: '#0a0f1d', border: '1px solid #1e293b', borderRadius: '8px' }} itemStyle={{ color: '#ef4444', fontSize: '12px', fontWeight: 'bold' }} />
              <Line type="monotone" dataKey="threats" stroke="#de0202" strokeWidth={3} dot={{ r: 2, stroke: '#de0202', strokeWidth: 1 }} animationDuration={150} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-[#0f172a] border border-blue-900/20 p-8 rounded-[2rem] shadow-2xl">
           <h4 className="text-sm font-bold text-white uppercase tracking-widest mb-8">Decision Status</h4>
           <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie
                  data={[
                    { name: 'Normal', value: totalLogsNum - stats.activeThreats || 100 },
                    { name: 'Attacks', value: stats.activeThreats || 0 },
                  ]}
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  <Cell fill="#10b981" /> 
                  <Cell fill="#ab0808" /> 
                </Pie>
                <Tooltip contentStyle={{ backgroundColor: '#0a0f1d', border: '1px solid #1e293b', borderRadius: '8px' }} />
              </PieChart>
            </ResponsiveContainer>
        </div>
      </div>

      <div className="bg-[#0f172a] rounded-[2rem] border border-blue-900/20 overflow-hidden shadow-2xl w-full">
        <div className="p-6 border-b border-white/5 bg-[#060a14]/30 flex justify-between items-center">
           <h4 className="text-sm font-bold text-white uppercase tracking-widest">Active Blocklist Registry</h4>
        </div>
        <div className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead className="bg-[#060a14]/80 text-gray-400 text-[10px] uppercase font-black tracking-[0.15em] border-b border-white/5 sticky top-0 z-10 backdrop-blur-md">
                <tr>
                  <th className="px-6 py-4">Banned Timestamp</th>
                  <th className="px-6 py-4">Targeted IP Address</th>
                  <th className="px-6 py-4">Attack Signature</th>
                  <th className="px-6 py-4 text-center">Action Authority</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 font-mono text-[15px]">
                {currentBlockedIPs.map((alert, index) => (
                  <tr key={index} className="hover:bg-blue-500/[0.02] transition duration-150 group">
                    <td className="px-6 py-4 text-slate-400 font-sans">{alert.bannedAt.toLocaleTimeString()}</td>
                    <td className="px-6 py-4 font-bold text-red-400">{alert.ip}</td>
                    <td className="px-6 py-4 uppercase text-slate-400 font-mono text-[15px] tracking-wider">{alert.type}</td>
                    <td className="px-6 py-4 text-center">
                      <button
                        onClick={() => handleUnbanClick(alert.ip)}
                        disabled={!isSuperAdmin}
                        title={isSuperAdmin ? "Revoke Ban Instantly" : "Requires Super Admin Privilege"}
                        className={`px-3 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all duration-300 flex items-center gap-1 mx-auto border ${
                          isSuperAdmin
                            ? 'bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-400 text-white border-blue-400/20 shadow-md shadow-blue-500/10 active:scale-95 cursor-pointer'
                            : 'bg-white/5 text-slate-600 border-white/5 cursor-not-allowed opacity-40'
                        }`}
                      >
                        Lift Ban
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {blockedIPsList.length === 0 && (
              <div className="py-12 text-center text-slate-600 font-bold tracking-widest uppercase italic text-xs">
                No IPs currently restricted by the system.
              </div>
            )}
          </div>

          {blockedIPsList.length > itemsPerPage && (
            <div className="p-4 bg-white/[0.01] border-t border-white/5 flex justify-center items-center gap-2">
              <button 
                onClick={() => setCurrentPage(p => Math.max(p - 1, 1))} 
                disabled={currentPage === 1}
                className="px-2.5 py-1 bg-[#060a14] border border-white/5 rounded-lg text-slate-400 disabled:opacity-30 text-[10px] font-bold uppercase"
              >
                Prev
              </button>
              <span className="text-slate-500 text-[10px] font-bold font-mono">
                {currentPage} / {totalPages}
              </span>
              <button 
                onClick={() => setCurrentPage(p => Math.min(p + 1, totalPages))} 
                disabled={currentPage === totalPages}
                className="px-2.5 py-1 bg-[#060a14] border border-white/5 rounded-lg text-slate-400 disabled:opacity-30 text-[10px] font-bold uppercase"
              >
                Next
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;


// import React, { useState, useEffect } from 'react';
// import { Activity, ShieldCheck, ShieldAlert, GlobeLock, ShieldX } from 'lucide-react';
// import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

// // 🚨 كارت الإحصائيات المطور: يجمع بين الـ Layout الأفقي الأصلي ومميزات فخامة الـ Detection Hub 🚨
// const StatCard = ({ title, value, icon }) => (
//   <div className="bg-[#0f172a] border border-white/5 rounded-[2rem] p-6 shadow-2xl relative group overflow-hidden transition-all duration-500 hover:-translate-y-1.5 flex flex-col justify-between">
//     {/* تأثير النيون الخلفي الدائري المقتبس من الـ Detection Hub */}
//     <div className="absolute -right-12 -top-12 w-32 h-32 bg-blue-500/10 rounded-full blur-[60px] group-hover:blur-[45px] transition-all duration-700 pointer-events-none" />
    
//     {/* الـ Layout الأفقي الأصلي مستقر تماماً (العناوين والأرقام يسار، والأيقونة يمين) */}
//     <div className="flex items-center justify-between relative z-10">
//       <div>
//         {/* 🚨 العناوين الأربعة تحولت للأزرق النيون الفخم 🚨 */}
//         <p className="text-[10px] font-black text-blue-500 uppercase tracking-[0.2em] mb-1">
//           {title}
//         </p>
//         {/* الأرقام تظل باللون الأبيض الناصع المستقر */}
//         <h3 className="text-3xl font-bold tracking-tighter text-white">
//           {value}
//         </h3>
//       </div>
//       {/* الأيقونة محاطة ببوردر ناعم وموحدة باللون الأزرق النيون */}
//       <div className="p-3 rounded-xl bg-[#060a14]/50 border border-white/5 text-blue-500 group-hover:scale-105 transition-transform duration-500">
//         {icon}
//       </div>
//     </div>

//     {/* الخط السفلي المتوهج المقتبس من الـ Detection Hub عند الـ Hover */}
//     <div className="absolute bottom-0 left-0 h-[3px] bg-blue-500 w-0 group-hover:w-full transition-all duration-500 shadow-[0_0_15px_#2563eb]" />
//   </div>
// );

// const Dashboard = ({ 
//   stats = { totalLogs: "0", normalTraffic: "0", activeThreats: 0, blockedIPs: 0 }, 
//   recentAlerts = [],
//   onUnbanIP 
// }) => {
//   const [timelineData, setTimelineData] = useState([]);
//   const [blockedIPsList, setBlockedIPsList] = useState([]);
//   const [currentPage, setCurrentPage] = useState(1);
//   const itemsPerPage = 5;
//   const currentUserRole = localStorage.getItem('role') || 'analyst';
//   const isSuperAdmin = currentUserRole === 'super_admin';

//   useEffect(() => {
//     if (stats && typeof stats.activeThreats !== 'undefined') {
//       setTimelineData(current => [...current.slice(-19), {
//         time: new Date().toLocaleTimeString(),
//         threats: stats.activeThreats
//       }]);
//     }
//   }, [stats.activeThreats]);

//   useEffect(() => {
//     const initialBlocked = recentAlerts
//       .filter(alert => alert.severity === 'High' || alert.status === 'blocked')
//       .map(alert => ({
//         ...alert,
//         bannedAt: alert.timestamp ? new Date(alert.timestamp) : new Date(), 
//       }));
//     setBlockedIPsList(initialBlocked);
//   }, [recentAlerts]);

//   useEffect(() => {
//     const interval = setInterval(() => {
//       setBlockedIPsList(currentList => {
//         const now = new Date();
//         return currentList.filter(ip => {
//           const timeDifference = (now - ip.bannedAt) / 1000 / 60; 
//           return timeDifference < 10; 
//         });
//       });
//     }, 1000);

//     return () => clearInterval(interval);
//   }, []);

//   const handleUnbanClick = (ipToUnban) => {
//     if (!isSuperAdmin) return;
    
//     setBlockedIPsList(current => current.filter(item => item.ip !== ipToUnban));
    
//     if (onUnbanIP) {
//       onUnbanIP(ipToUnban);
//     }
//   };

//   const totalPages = Math.ceil(blockedIPsList.length / itemsPerPage) || 1;
//   const indexOfLastItem = currentPage * itemsPerPage;
//   const indexOfFirstItem = indexOfLastItem - itemsPerPage;
//   const currentBlockedIPs = blockedIPsList.slice(indexOfFirstItem, indexOfLastItem);

//   const totalLogsNum = parseInt(stats.totalLogs.replace(/,/g, '')) || 0;
//   const normalLogsCount = stats.normalTraffic.includes('%') 
//     ? Math.max(0, totalLogsNum - stats.activeThreats)
//     : stats.normalTraffic;

//   return (
//     <div className="space-y-10 animate-fadeIn pb-20">
      
//       {/* 1. Stats Grid */}
//       <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
//         <StatCard title="Total Logs" value={stats.totalLogs} icon={<Activity size={24} />} />
//         <StatCard title="Normal Traffic" value={String(normalLogsCount)} icon={<ShieldCheck size={24} />} />
//         <StatCard title="Active Threats" value={String(stats.activeThreats)} icon={<ShieldAlert size={24} />} />
//         <StatCard title="Blocked IPs" value={String(blockedIPsList.length)} icon={<GlobeLock size={24} />} />
//       </div>

//       {/* 2. Charts & Alerts Section */}
//       <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
//         {/* Threat Detection Chart */}
//         <div className="lg:col-span-2 bg-[#0f172a] border border-blue-900/20 p-8 rounded-[2rem] shadow-2xl">
//           <div className="flex items-center justify-between mb-8">
//             <h4 className="text-sm font-bold text-white uppercase tracking-widest">Threat Detection Timeline</h4>
//             <span className="flex items-center gap-2 text-[10px] text-emerald-500 font-black uppercase tracking-widest bg-emerald-500/10 px-3 py-1 rounded-full">
//                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span> Live Sync
//             </span>
//           </div>
//           <ResponsiveContainer width="100%" height={250}>
//             <LineChart data={timelineData}>
//               <CartesianGrid strokeDasharray="3 3" stroke="#ffffff05" vertical={false} />
//               <XAxis dataKey="time" stroke="#475569" fontSize={11} fontWeight="bold" tickLine={false} axisLine={false} />
//               <YAxis stroke="#475569" fontSize={10} tickLine={false} axisLine={false} />
//               <Tooltip contentStyle={{ backgroundColor: '#0a0f1d', border: '1px solid #1e293b', borderRadius: '8px' }} itemStyle={{ color: '#ef4444', fontSize: '12px', fontWeight: 'bold' }} />
//               <Line type="monotone" dataKey="threats" stroke="#de0202" strokeWidth={3} dot={false} animationDuration={300} />
//               {/* <Line type="monotone" dataKey="threats" stroke="#ef4444" strokeWidth={3} dot={false} animationDuration={300} /> */}

//             </LineChart>
//           </ResponsiveContainer>
//         </div>

//         {/* AI Decision Status (Pie Chart) */}
//         <div className="bg-[#0f172a] border border-blue-900/20 p-8 rounded-[2rem] shadow-2xl">
//            <h4 className="text-sm font-bold text-white uppercase tracking-widest mb-8">Decision Status</h4>
//            <ResponsiveContainer width="100%" height={250}>
//               <PieChart>
//                 <Pie
//                   data={[
//                     { name: 'Normal', value: totalLogsNum - stats.activeThreats || 100 },
//                     { name: 'Attacks', value: stats.activeThreats || 0 },
//                   ]}
//                   innerRadius={60}
//                   outerRadius={80}
//                   paddingAngle={5}
//                   dataKey="value"
//                 >
//                   <Cell fill="#10b981" /> 
//                   <Cell fill="#ab0808" /> 
//                 </Pie>
//                 <Tooltip contentStyle={{ backgroundColor: '#0a0f1d', border: '1px solid #1e293b', borderRadius: '8px' }} />
//               </PieChart>
//             </ResponsiveContainer>
//         </div>
//       </div>

//       {/* 3. Active Firewall Blocklist Table */}
//       <div className="bg-[#0f172a] rounded-[2rem] border border-blue-900/20 overflow-hidden shadow-2xl w-full">
//         <div className="p-6 border-b border-white/5 bg-[#060a14]/30 flex justify-between items-center">
//            <h4 className="text-sm font-bold text-white uppercase tracking-widest">Active Blocklist Registry</h4>
//         </div>
//         <div className="p-0">
//           <div className="overflow-x-auto">
//             <table className="w-full text-left border-collapse">
//               <thead className="bg-[#060a14]/80 text-gray-400 text-[10px] uppercase font-black tracking-[0.15em] border-b border-white/5 sticky top-0 z-10 backdrop-blur-md">
//                 <tr>
//                   <th className="px-6 py-4">Banned Timestamp</th>
//                   <th className="px-6 py-4">Targeted IP Address</th>
//                   <th className="px-6 py-4">Attack Signature</th>
//                   <th className="px-6 py-4 text-center">Action Authority</th>
//                 </tr>
//               </thead>
//               <tbody className="divide-y divide-white/5 font-mono text-[15px]">
//                 {currentBlockedIPs.map((alert, index) => (
//                   <tr key={index} className="hover:bg-blue-500/[0.02] transition duration-150 group">
//                     <td className="px-6 py-4 text-slate-400 font-sans">{alert.bannedAt.toLocaleTimeString()}</td>
//                     <td className="px-6 py-4 font-bold text-red-400">{alert.ip}</td>
//                     <td className="px-6 py-4 uppercase text-slate-400 font-mono text-[15px] tracking-wider">{alert.type}</td>
                    
//                     <td className="px-6 py-4 text-center">
//                       <button
//                         onClick={() => handleUnbanClick(alert.ip)}
//                         disabled={!isSuperAdmin}
//                         title={isSuperAdmin ? "Revoke Ban Instantly" : "Requires Super Admin Privilege"}
//                         className={`px-3 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all duration-300 flex items-center gap-1 mx-auto border ${
//                           isSuperAdmin
//                             ? 'bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-400 text-white border-blue-400/20 shadow-md shadow-blue-500/10 active:scale-95 cursor-pointer'
//                             : 'bg-white/5 text-slate-600 border-white/5 cursor-not-allowed opacity-40'
//                         }`}
//                       >
//                         Lift Ban
//                       </button>
//                     </td>
//                   </tr>
//                 ))}
//               </tbody>
//             </table>
            
//             {blockedIPsList.length === 0 && (
//               <div className="py-12 text-center text-slate-600 font-bold tracking-widest uppercase italic text-xs">
//                 No IPs currently restricted by the system.
//               </div>
//             )}
//           </div>

//           {/* Pagination */}
//           {blockedIPsList.length > itemsPerPage && (
//             <div className="p-4 bg-white/[0.01] border-t border-white/5 flex justify-center items-center gap-2">
//               <button 
//                 onClick={() => setCurrentPage(p => Math.max(p - 1, 1))} 
//                 disabled={currentPage === 1}
//                 className="px-2.5 py-1 bg-[#060a14] border border-white/5 rounded-lg text-slate-400 disabled:opacity-30 text-[10px] font-bold uppercase"
//               >
//                 Prev
//               </button>
//               <span className="text-slate-500 text-[10px] font-bold font-mono">
//                 {currentPage} / {totalPages}
//               </span>
//               <button 
//                 onClick={() => setCurrentPage(p => Math.min(p + 1, totalPages))} 
//                 disabled={currentPage === totalPages}
//                 className="px-2.5 py-1 bg-[#060a14] border border-white/5 rounded-lg text-slate-400 disabled:opacity-30 text-[10px] font-bold uppercase"
//               >
//                 Next
//               </button>
//             </div>
//           )}
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Dashboard;
















// import React, { useState, useEffect } from 'react';
// import { Activity, ShieldCheck, ShieldAlert, GlobeLock, ShieldX } from 'lucide-react';
// import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

// // المكون الفرعي للكروت مع التنسيق اللوني الجديد والمصلح
// const StatCard = ({ title, value, icon, colorClass, isBlockedCard = false }) => (
//   <div className="bg-[#0f172a] border border-blue-900/20 p-6 rounded-2xl shadow-2xl relative group overflow-hidden transition-all duration-300 hover:border-blue-500/30">
//     <div className={`absolute -right-4 -top-4 w-24 h-24 rounded-full blur-3xl opacity-5 ${isBlockedCard ? 'bg-white' : colorClass.replace('text-', 'bg-')}`}></div>
//     <div className="flex items-center justify-between relative z-10">
//       <div>
//         {/* 🚨 العناوين الصغيرة رجعت للرمادي الأصلي الفخم المريح للعين 🚨 */}
//         <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] mb-1">
//           {title}
//         </p>
//         {/* 🚨 كرت الـ Blocked IPs أصبح أبيض ناصع والباقي بألوانه النيون الذكية 🚨 */}
//         <h3 className={`text-3xl font-bold tracking-tighter ${isBlockedCard ? 'text-white' : colorClass}`}>
//           {value}
//         </h3>
//       </div>
//       <div className={`p-3 rounded-xl bg-[#060a14]/50 border border-white/5 ${isBlockedCard ? 'text-white' : colorClass}`}>
//         {icon}
//       </div>
//     </div>
//   </div>
// );

// const Dashboard = ({ 
//   stats = { totalLogs: "0", normalTraffic: "0", activeThreats: 0, blockedIPs: 0 }, 
//   recentAlerts = [],
//   onUnbanIP 
// }) => {
//   const [timelineData, setTimelineData] = useState([]);
//   const [blockedIPsList, setBlockedIPsList] = useState([]);
//   const [currentPage, setCurrentPage] = useState(1);
//   const itemsPerPage = 5;
//   const currentUserRole = localStorage.getItem('role') || 'analyst';
//   const isSuperAdmin = currentUserRole === 'super_admin';

//   useEffect(() => {
//     if (stats && typeof stats.activeThreats !== 'undefined') {
//       setTimelineData(current => [...current.slice(-19), {
//         time: new Date().toLocaleTimeString(),
//         threats: stats.activeThreats
//       }]);
//     }
//   }, [stats.activeThreats]);

//   useEffect(() => {
//     const initialBlocked = recentAlerts
//       .filter(alert => alert.severity === 'High' || alert.status === 'blocked')
//       .map(alert => ({
//         ...alert,
//         bannedAt: alert.timestamp ? new Date(alert.timestamp) : new Date(), 
//       }));
//     setBlockedIPsList(initialBlocked);
//   }, [recentAlerts]);

//   useEffect(() => {
//     const interval = setInterval(() => {
//       setBlockedIPsList(currentList => {
//         const now = new Date();
//         return currentList.filter(ip => {
//           const timeDifference = (now - ip.bannedAt) / 1000 / 60; 
//           return timeDifference < 10; 
//         });
//       });
//     }, 1000);

//     return () => clearInterval(interval);
//   }, []);

//   const handleUnbanClick = (ipToUnban) => {
//     if (!isSuperAdmin) return;
    
//     setBlockedIPsList(current => current.filter(item => item.ip !== ipToUnban));
    
//     if (onUnbanIP) {
//       onUnbanIP(ipToUnban);
//     }
//   };

//   const totalPages = Math.ceil(blockedIPsList.length / itemsPerPage) || 1;
//   const indexOfLastItem = currentPage * itemsPerPage;
//   const indexOfFirstItem = indexOfLastItem - itemsPerPage;
//   const currentBlockedIPs = blockedIPsList.slice(indexOfFirstItem, indexOfLastItem);

//   const totalLogsNum = parseInt(stats.totalLogs.replace(/,/g, '')) || 0;
//   const normalLogsCount = stats.normalTraffic.includes('%') 
//     ? Math.max(0, totalLogsNum - stats.activeThreats)
//     : stats.normalTraffic;

//   return (
//     /* 🚨 تم إضافة h-full و overflow-y-auto لضمان عمل السكرول بار بكفاءة تامة 🚨 */
//     <div className="space-y-10 animate-fadeIn h-full overflow-y-auto pr-1 pb-10 custom-scrollbar">
//       {/* 1. Stats Grid */}
//       <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
//         <StatCard title="Total Logs" value={stats.totalLogs} icon={<Activity size={24} />} colorClass="text-blue-500" />
//         <StatCard title="Normal Traffic" value={String(normalLogsCount)} icon={<ShieldCheck size={24} />} colorClass="text-emerald-500" />
//         <StatCard title="Active Threats" value={String(stats.activeThreats)} icon={<ShieldAlert size={24} />} colorClass="text-red-500" />
//         <StatCard title="Blocked IPs" value={String(blockedIPsList.length)} icon={<GlobeLock size={24} />} colorClass="text-purple-500" isBlockedCard={true} />
//       </div>

//       {/* 2. Charts & Alerts Section */}
//       <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
//         {/* Threat Detection Chart */}
//         <div className="lg:col-span-2 bg-[#0f172a] border border-blue-900/20 p-8 rounded-3xl shadow-2xl">
//           <div className="flex items-center justify-between mb-8">
//             <h4 className="text-sm font-bold text-white uppercase tracking-widest">Threat Detection Timeline</h4>
//             <span className="flex items-center gap-2 text-[10px] text-emerald-500 font-black uppercase tracking-widest bg-emerald-500/10 px-3 py-1 rounded-full">
//                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span> Live Sync
//             </span>
//           </div>
//           <ResponsiveContainer width="100%" height={250}>
//             <LineChart data={timelineData}>
//               <CartesianGrid strokeDasharray="3 3" stroke="#ffffff05" vertical={false} />
//               <XAxis dataKey="time" stroke="#475569" fontSize={11} fontWeight="bold" tickLine={false} axisLine={false} />
//               <YAxis stroke="#475569" fontSize={10} tickLine={false} axisLine={false} />
//               <Tooltip contentStyle={{ backgroundColor: '#0a0f1d', border: '1px solid #1e293b', borderRadius: '8px' }} itemStyle={{ color: '#ef4444', fontSize: '12px', fontWeight: 'bold' }} />
//               <Line type="monotone" dataKey="threats" stroke="#ef4444" strokeWidth={3} dot={false} animationDuration={300} />
//             </LineChart>
//           </ResponsiveContainer>
//         </div>

//         {/* AI Decision Status (Pie Chart) */}
//         <div className="bg-[#0f172a] border border-blue-900/20 p-8 rounded-3xl shadow-2xl">
//            <h4 className="text-sm font-bold text-white uppercase tracking-widest mb-8">Decision Status</h4>
//            <ResponsiveContainer width="100%" height={250}>
//               <PieChart>
//                 <Pie
//                   data={[
//                     { name: 'Normal', value: totalLogsNum - stats.activeThreats || 100 },
//                     { name: 'Suspicious', value: stats.activeThreats || 0 },
//                   ]}
//                   innerRadius={60}
//                   outerRadius={80}
//                   paddingAngle={5}
//                   dataKey="value"
//                 >
//                   <Cell fill="#10b981" /> 
//                   <Cell fill="#ef4444" /> 
//                 </Pie>
//                 <Tooltip contentStyle={{ backgroundColor: '#0a0f1d', border: '1px solid #1e293b', borderRadius: '8px' }} />
//               </PieChart>
//             </ResponsiveContainer>
//         </div>
//       </div>

//       {/* 4. Active Firewall Blocklist */}
//       <div className="bg-[#0f172a] border border-blue-900/20 rounded-3xl shadow-2xl overflow-hidden">
//         <div className="p-6 border-b border-white/5 bg-white/5 flex justify-between items-center">
//            <h4 className="text-sm font-bold text-white uppercase tracking-widest">Active Blocklist Registry</h4>
//         </div>
//         <div className="p-0">
//           <div className="overflow-x-auto">
//             <table className="w-full text-left border-collapse">
//               <thead className="bg-white/5 text-[10px] font-black text-slate-500 uppercase tracking-[0.2em]">
//                 <tr>
//                   <th className="px-6 py-4">Banned Timestamp</th>
//                   <th className="px-6 py-4">Targeted IP Address</th>
//                   <th className="px-6 py-4">Attack Signature</th>
//                   <th className="px-6 py-4 text-center">Action Authority</th>
//                 </tr>
//               </thead>
//               <tbody className="divide-y divide-white/5 font-mono text-[11px]">
//                 {currentBlockedIPs.map((alert, index) => (
//                   <tr key={index} className="hover:bg-white/[0.02] transition-colors">
//                     <td className="px-6 py-4 text-xs text-slate-400 font-sans">
//                       {alert.bannedAt.toLocaleTimeString()}
//                     </td>
//                     <td className="px-6 py-4 text-xs text-red-400 font-bold">{alert.ip}</td>
//                     <td className="px-6 py-4 text-xs text-white font-sans font-semibold">{alert.type}</td>
                    
//                     <td className="px-6 py-4 text-center">
//                       <button
//                         onClick={() => handleUnbanClick(alert.ip)}
//                         disabled={!isSuperAdmin}
//                         title={isSuperAdmin ? "Revoke Ban Instantly" : "Requires Super Admin Privilege"}
//                         className={`px-3 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all duration-300 flex items-center gap-1 mx-auto border ${
//                           isSuperAdmin
//                             ? 'bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-400 text-white border-blue-400/20 shadow-md shadow-blue-500/10 active:scale-95 cursor-pointer'
//                             : 'bg-white/5 text-slate-600 border-white/5 cursor-not-allowed opacity-40'
//                         }`}
//                       >
//                         <ShieldX size={12} /> Lift Ban
//                       </button>
//                     </td>
//                   </tr>
//                 ))}
//               </tbody>
//             </table>
            
//             {blockedIPsList.length === 0 && (
//               <div className="py-12 text-center text-slate-600 font-bold tracking-widest uppercase italic text-xs">
//                 No IPs currently restricted by the system.
//               </div>
//             )}
//           </div>

//           {/* ديزاين التقسيم */}
//           {blockedIPsList.length > itemsPerPage && (
//             <div className="p-4 bg-white/[0.01] border-t border-white/5 flex justify-center items-center gap-2">
//               <button 
//                 onClick={() => setCurrentPage(p => Math.max(p - 1, 1))} 
//                 disabled={currentPage === 1}
//                 className="px-2.5 py-1 bg-[#060a14] border border-white/5 rounded-lg text-slate-400 disabled:opacity-30 text-[10px] font-bold uppercase"
//               >
//                 Prev
//               </button>
//               <span className="text-slate-500 text-[10px] font-bold font-mono">
//                 {currentPage} / {totalPages}
//               </span>
//               <button 
//                 onClick={() => setCurrentPage(p => Math.min(p + 1, totalPages))} 
//                 disabled={currentPage === totalPages}
//                 className="px-2.5 py-1 bg-[#060a14] border border-white/5 rounded-lg text-slate-400 disabled:opacity-30 text-[10px] font-bold uppercase"
//               >
//                 Next
//               </button>
//             </div>
//           )}
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Dashboard;


// import React, { useState, useEffect } from 'react';
// import { Activity, ShieldCheck, ShieldAlert, GlobeLock, ShieldX } from 'lucide-react';
// import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

// // 🚨 تم تصليح المكون وإعادة العنوان ليقرأ الـ colorClass الأصلي بتاعه 🚨
// const StatCard = ({ title, value, icon, colorClass }) => (
//   <div className="bg-[#0f172a] border border-blue-900/20 p-6 rounded-2xl shadow-2xl relative group overflow-hidden transition-all duration-300 hover:border-blue-500/30">
//     <div className={`absolute -right-4 -top-4 w-24 h-24 rounded-full blur-3xl opacity-5 ${colorClass.replace('text-', 'bg-')}`}></div>
//     <div className="flex items-center justify-between relative z-10">
//       <div>
//         <p className={`text-[10px] font-black uppercase tracking-[0.2em] mb-1 ${colorClass} opacity-80`}>
//           {title}
//         </p>
//         <h3 className={`text-3xl font-bold tracking-tighter ${colorClass}`}>
//           {value}
//         </h3>
//       </div>
//       <div className={`p-3 rounded-xl bg-[#060a14]/50 border border-white/5 ${colorClass}`}>
//         {icon}
//       </div>
//     </div>
//   </div>
// );

// const Dashboard = ({ 
//   stats = { totalLogs: "0", normalTraffic: "0", activeThreats: 0, blockedIPs: 0 }, 
//   recentAlerts = [],
//   onUnbanIP 
// }) => {
//   const [timelineData, setTimelineData] = useState([]);
//   const [blockedIPsList, setBlockedIPsList] = useState([]);
//   const [currentPage, setCurrentPage] = useState(1);
//   const itemsPerPage = 5;
//   const currentUserRole = localStorage.getItem('role') || 'analyst';
//   const isSuperAdmin = currentUserRole === 'super_admin';

//   useEffect(() => {
//     if (stats && typeof stats.activeThreats !== 'undefined') {
//       setTimelineData(current => [...current.slice(-19), {
//         time: new Date().toLocaleTimeString(),
//         threats: stats.activeThreats
//       }]);
//     }
//   }, [stats.activeThreats]);

//   useEffect(() => {
//     const initialBlocked = recentAlerts
//       .filter(alert => alert.severity === 'High' || alert.status === 'blocked')
//       .map(alert => ({
//         ...alert,
//         bannedAt: alert.timestamp ? new Date(alert.timestamp) : new Date(), 
//       }));
//     setBlockedIPsList(initialBlocked);
//   }, [recentAlerts]);

//   useEffect(() => {
//     const interval = setInterval(() => {
//       setBlockedIPsList(currentList => {
//         const now = new Date();
//         return currentList.filter(ip => {
//           const timeDifference = (now - ip.bannedAt) / 1000 / 60; 
//           return timeDifference < 10; 
//         });
//       });
//     }, 1000);

//     return () => clearInterval(interval);
//   }, []);

//   const handleUnbanClick = (ipToUnban) => {
//     if (!isSuperAdmin) return;
    
//     setBlockedIPsList(current => current.filter(item => item.ip !== ipToUnban));
    
//     if (onUnbanIP) {
//       onUnbanIP(ipToUnban);
//     }
//   };

//   const totalPages = Math.ceil(blockedIPsList.length / itemsPerPage) || 1;
//   const indexOfLastItem = currentPage * itemsPerPage;
//   const indexOfFirstItem = indexOfLastItem - itemsPerPage;
//   const currentBlockedIPs = blockedIPsList.slice(indexOfFirstItem, indexOfLastItem);

//   const totalLogsNum = parseInt(stats.totalLogs.replace(/,/g, '')) || 0;
//   const normalLogsCount = stats.normalTraffic.includes('%') 
//     ? Math.max(0, totalLogsNum - stats.activeThreats)
//     : stats.normalTraffic;

//   return (
//     <div className="space-y-10 animate-fadeIn">
//       {/* 1. Stats Grid */}
//       <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
//         <StatCard title="Total Logs" value={stats.totalLogs} icon={<Activity size={24} />} colorClass="text-blue-500" />
//         <StatCard title="Normal Traffic" value={String(normalLogsCount)} icon={<ShieldCheck size={24} />} colorClass="text-emerald-500" />
//         <StatCard title="Active Threats" value={String(stats.activeThreats)} icon={<ShieldAlert size={24} />} colorClass="text-red-500" />
//         <StatCard title="Blocked IPs" value={String(blockedIPsList.length)} icon={<GlobeLock size={24} />} colorClass="text-purple-500" />
//       </div>

//       {/* 2. Charts & Alerts Section */}
//       <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
//         {/* Threat Detection Chart */}
//         <div className="lg:col-span-2 bg-[#0f172a] border border-blue-900/20 p-8 rounded-3xl shadow-2xl">
//           <div className="flex items-center justify-between mb-8">
//             <h4 className="text-sm font-bold text-white uppercase tracking-widest">Threat Detection Timeline</h4>
//             <span className="flex items-center gap-2 text-[10px] text-emerald-500 font-black uppercase tracking-widest bg-emerald-500/10 px-3 py-1 rounded-full">
//                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span> Live Sync
//             </span>
//           </div>
//           <ResponsiveContainer width="100%" height={250}>
//             <LineChart data={timelineData}>
//               <CartesianGrid strokeDasharray="3 3" stroke="#ffffff05" vertical={false} />
//               <XAxis dataKey="time" stroke="#475569" fontSize={11} fontWeight="bold" tickLine={false} axisLine={false} />
//               <YAxis stroke="#475569" fontSize={10} tickLine={false} axisLine={false} />
//               <Tooltip contentStyle={{ backgroundColor: '#0a0f1d', border: '1px solid #1e293b', borderRadius: '8px' }} itemStyle={{ color: '#ef4444', fontSize: '12px', fontWeight: 'bold' }} />
//               <Line type="monotone" dataKey="threats" stroke="#ef4444" strokeWidth={3} dot={false} animationDuration={300} />
//             </LineChart>
//           </ResponsiveContainer>
//         </div>

//         {/* AI Decision Status (Pie Chart) */}
//         <div className="bg-[#0f172a] border border-blue-900/20 p-8 rounded-3xl shadow-2xl">
//            <h4 className="text-sm font-bold text-white uppercase tracking-widest mb-8">Decision Status</h4>
//            <ResponsiveContainer width="100%" height={250}>
//               <PieChart>
//                 <Pie
//                   data={[
//                     { name: 'Normal', value: totalLogsNum - stats.activeThreats || 100 },
//                     { name: 'Suspicious', value: stats.activeThreats || 0 },
//                   ]}
//                   innerRadius={60}
//                   outerRadius={80}
//                   paddingAngle={5}
//                   dataKey="value"
//                 >
//                   <Cell fill="#10b981" /> 
//                   <Cell fill="#ef4444" /> 
//                 </Pie>
//                 <Tooltip contentStyle={{ backgroundColor: '#0a0f1d', border: '1px solid #1e293b', borderRadius: '8px' }} />
//               </PieChart>
//             </ResponsiveContainer>
//         </div>
//       </div>

//       {/* 4. Active Firewall Blocklist */}
//       <div className="bg-[#0f172a] border border-blue-900/20 rounded-3xl shadow-2xl overflow-hidden">
//         <div className="p-6 border-b border-white/5 bg-white/5 flex justify-between items-center">
//            <h4 className="text-sm font-bold text-white uppercase tracking-widest">Active Blocklist Registry</h4>
//         </div>
//         <div className="p-0">
//           <div className="overflow-x-auto">
//             <table className="w-full text-left border-collapse">
//               <thead className="bg-white/5 text-[10px] font-black text-slate-500 uppercase tracking-[0.2em]">
//                 <tr>
//                   <th className="px-6 py-4">Banned Timestamp</th>
//                   <th className="px-6 py-4">Targeted IP Address</th>
//                   <th className="px-6 py-4">Attack Signature</th>
//                   <th className="px-6 py-4 text-center">Action Authority</th>
//                 </tr>
//               </thead>
//               <tbody className="divide-y divide-white/5 font-mono text-[11px]">
//                 {currentBlockedIPs.map((alert, index) => (
//                   <tr key={index} className="hover:bg-white/[0.02] transition-colors">
//                     <td className="px-6 py-4 text-xs text-slate-400 font-sans">
//                       {alert.bannedAt.toLocaleTimeString()}
//                     </td>
//                     <td className="px-6 py-4 text-xs text-red-400 font-bold">{alert.ip}</td>
//                     <td className="px-6 py-4 text-xs text-white font-sans font-semibold">{alert.type}</td>
                    
//                     <td className="px-6 py-4 text-center">
//                       <button
//                         onClick={() => handleUnbanClick(alert.ip)}
//                         disabled={!isSuperAdmin}
//                         title={isSuperAdmin ? "Revoke Ban Instantly" : "Requires Super Admin Privilege"}
//                         className={`px-3 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all duration-300 flex items-center gap-1 mx-auto border ${
//                           isSuperAdmin
//                             ? 'bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-400 text-white border-blue-400/20 shadow-md shadow-blue-500/10 active:scale-95 cursor-pointer'
//                             : 'bg-white/5 text-slate-600 border-white/5 cursor-not-allowed opacity-40'
//                         }`}
//                       >
//                         <ShieldX size={12} /> Lift Ban
//                       </button>
//                     </td>
//                   </tr>
//                 ))}
//               </tbody>
//             </table>
            
//             {blockedIPsList.length === 0 && (
//               <div className="py-12 text-center text-slate-600 font-bold tracking-widest uppercase italic text-xs">
//                 No IPs currently restricted by the system.
//               </div>
//             )}
//           </div>

//           {/* ديزاين التقسيم */}
//           {blockedIPsList.length > itemsPerPage && (
//             <div className="p-4 bg-white/[0.01] border-t border-white/5 flex justify-center items-center gap-2">
//               <button 
//                 onClick={() => setCurrentPage(p => Math.max(p - 1, 1))} 
//                 disabled={currentPage === 1}
//                 className="px-2.5 py-1 bg-[#060a14] border border-white/5 rounded-lg text-slate-400 disabled:opacity-30 text-[10px] font-bold uppercase"
//               >
//                 Prev
//               </button>
//               <span className="text-slate-500 text-[10px] font-bold font-mono">
//                 {currentPage} / {totalPages}
//               </span>
//               <button 
//                 onClick={() => setCurrentPage(p => Math.min(p + 1, totalPages))} 
//                 disabled={currentPage === totalPages}
//                 className="px-2.5 py-1 bg-[#060a14] border border-white/5 rounded-lg text-slate-400 disabled:opacity-30 text-[10px] font-bold uppercase"
//               >
//                 Next
//               </button>
//             </div>
//           )}
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Dashboard;






// import React, { useState, useEffect } from 'react';
// import { Activity, ShieldCheck, ShieldAlert, GlobeLock, RefreshCw, ShieldX } from 'lucide-react';
// import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

// const StatCard = ({ title, value, icon, colorClass }) => (
//   <div className="bg-[#0f172a] border border-blue-900/20 p-6 rounded-2xl shadow-2xl relative group overflow-hidden transition-all duration-300 hover:border-blue-500/30">
//     <div className={`absolute -right-4 -top-4 w-24 h-24 rounded-full blur-3xl opacity-5 ${colorClass.replace('text-', 'bg-')}`}></div>
//     <div className="flex items-center justify-between relative z-10">
//       <div>
//         <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] mb-1">
//           {title}
//         </p>
//         <h3 className={`text-3xl font-bold tracking-tighter ${colorClass}`}>
//           {value}
//         </h3>
//       </div>
//       <div className={`p-3 rounded-xl bg-[#060a14]/50 border border-white/5 ${colorClass}`}>
//         {icon}
//       </div>
//     </div>
//   </div>
// );

// const Dashboard = ({ 
//   stats = { totalLogs: "0", normalTraffic: "0", activeThreats: 0, blockedIPs: 0 }, 
//   recentAlerts = [],
//   onUnbanIP 
// }) => {
//   const [timelineData, setTimelineData] = useState([]);
//   const [blockedIPsList, setBlockedIPsList] = useState([]);
//   const [currentPage, setCurrentPage] = useState(1);
//   const itemsPerPage = 5;
//   const currentUserRole = localStorage.getItem('role') || 'analyst';
//   const isSuperAdmin = currentUserRole === 'super_admin';

//   useEffect(() => {
//     if (stats && typeof stats.activeThreats !== 'undefined') {
//       setTimelineData(current => [...current.slice(-19), {
//         time: new Date().toLocaleTimeString(),
//         threats: stats.activeThreats
//       }]);
//     }
//   }, [stats.activeThreats]);

//   useEffect(() => {
//     const initialBlocked = recentAlerts
//       .filter(alert => alert.severity === 'High' || alert.status === 'blocked')
//       .map(alert => ({
//         ...alert,
//         bannedAt: alert.timestamp ? new Date(alert.timestamp) : new Date(), 
//       }));
//     setBlockedIPsList(initialBlocked);
//   }, [recentAlerts]);

//   useEffect(() => {
//     const interval = setInterval(() => {
//       setBlockedIPsList(currentList => {
//         const now = new Date();
//         return currentList.filter(ip => {
//           const timeDifference = (now - ip.bannedAt) / 1000 / 60; 
//           return timeDifference < 10; 
//         });
//       });
//     }, 1000);

//     return () => clearInterval(interval);
//   }, []);

//   const handleUnbanClick = (ipToUnban) => {
//     if (!isSuperAdmin) return;
    
//     setBlockedIPsList(current => current.filter(item => item.ip !== ipToUnban));
    
//     if (onUnbanIP) {
//       onUnbanIP(ipToUnban);
//     }
//   };

//   const totalPages = Math.ceil(blockedIPsList.length / itemsPerPage) || 1;
//   const indexOfLastItem = currentPage * itemsPerPage;
//   const indexOfFirstItem = indexOfLastItem - itemsPerPage;
//   const currentBlockedIPs = blockedIPsList.slice(indexOfFirstItem, indexOfLastItem);

//   const totalLogsNum = parseInt(stats.totalLogs.replace(/,/g, '')) || 0;
//   const normalLogsCount = stats.normalTraffic.includes('%') 
//     ? Math.max(0, totalLogsNum - stats.activeThreats)
//     : stats.normalTraffic;

//   return (
//     <div className="space-y-10 animate-fadeIn">
//       {/* 1. Stats Grid */}
//       <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
//         <StatCard title="Total Logs" value={stats.totalLogs} icon={<Activity size={24} />} colorClass="text-blue-500" />
//         <StatCard title="Normal Traffic" value={String(normalLogsCount)} icon={<ShieldCheck size={24} />} colorClass="text-emerald-500" />
//         <StatCard title="Active Threats" value={String(stats.activeThreats)} icon={<ShieldAlert size={24} />} colorClass="text-red-500" />
//         <StatCard title="Blocked IPs" value={String(blockedIPsList.length)} icon={<GlobeLock size={24} />} colorClass="text-purple-500" />
//       </div>

//       {/* 2. Charts & Alerts Section */}
//       <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
//         {/* Threat Detection Chart */}
//         <div className="lg:col-span-2 bg-[#0f172a] border border-blue-900/20 p-8 rounded-3xl shadow-2xl">
//           <div className="flex items-center justify-between mb-8">
//             <h4 className="text-sm font-bold text-white uppercase tracking-widest">Threat Detection Timeline</h4>
//             <span className="flex items-center gap-2 text-[10px] text-emerald-500 font-black uppercase tracking-widest bg-emerald-500/10 px-3 py-1 rounded-full">
//                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span> Live Sync
//             </span>
//           </div>
//           <ResponsiveContainer width="100%" height={250}>
//             <LineChart data={timelineData}>
//               <CartesianGrid strokeDasharray="3 3" stroke="#ffffff05" vertical={false} />
//               <XAxis dataKey="time" stroke="#475569" fontSize={11} fontWeight="bold" tickLine={false} axisLine={false} />
//               <YAxis stroke="#475569" fontSize={10} tickLine={false} axisLine={false} />
//               <Tooltip contentStyle={{ backgroundColor: '#0a0f1d', border: '1px solid #1e293b', borderRadius: '8px' }} itemStyle={{ color: '#ef4444', fontSize: '12px', fontWeight: 'bold' }} />
//               <Line type="monotone" dataKey="threats" stroke="#ef4444" strokeWidth={3} dot={false} animationDuration={300} />
//             </LineChart>
//           </ResponsiveContainer>
//         </div>

//         {/* AI Decision Status (Pie Chart) */}
//         <div className="bg-[#0f172a] border border-blue-900/20 p-8 rounded-3xl shadow-2xl">
//            <h4 className="text-sm font-bold text-white uppercase tracking-widest mb-8">Decision Status</h4>
//            <ResponsiveContainer width="100%" height={250}>
//               <PieChart>
//                 <Pie
//                   data={[
//                     { name: 'Normal', value: totalLogsNum - stats.activeThreats || 100 },
//                     { name: 'Suspicious', value: stats.activeThreats || 0 },
//                   ]}
//                   innerRadius={60}
//                   outerRadius={80}
//                   paddingAngle={5}
//                   dataKey="value"
//                 >
//                   <Cell fill="#10b981" /> 
//                   <Cell fill="#ef4444" /> 
//                 </Pie>
//                 <Tooltip contentStyle={{ backgroundColor: '#0a0f1d', border: '1px solid #1e293b', borderRadius: '8px' }} />
//               </PieChart>
//             </ResponsiveContainer>
//         </div>
//       </div>

//       {/* 4. Active Firewall Blocklist (10m Dynamic TTL) */}
//       <div className="bg-[#0f172a] border border-blue-900/20 rounded-3xl shadow-2xl overflow-hidden">
//         <div className="p-6 border-b border-white/5 bg-white/5 flex justify-between items-center">
//            <h4 className="text-sm font-bold text-white uppercase tracking-widest">Active Firewall Mitigation Pool</h4>
//            <span className="text-[10px] text-red-400 font-black uppercase tracking-widest bg-red-500/10 px-3 py-1 rounded-full flex items-center gap-1.5">
//              <RefreshCw size={10} className="animate-spin" /> Auto-Expiring (10m TTL)
//            </span>
//         </div>
//         <div className="p-0">
//           <div className="overflow-x-auto">
//             <table className="w-full text-left border-collapse">
//               <thead className="bg-white/5 text-[10px] font-black text-slate-500 uppercase tracking-[0.2em]">
//                 <tr>
//                   <th className="px-6 py-4">Banned Timestamp</th>
//                   <th className="px-6 py-4">Targeted IP Address</th>
//                   <th className="px-6 py-4">Attack Signature</th>
//                   <th className="px-6 py-4 text-center">Action Authority</th>
//                 </tr>
//               </thead>
//               <tbody className="divide-y divide-white/5 font-mono text-[11px]">
//                 {currentBlockedIPs.map((alert, index) => (
//                   <tr key={index} className="hover:bg-white/[0.02] transition-colors">
//                     <td className="px-6 py-4 text-xs text-slate-500 font-sans">
//                       {alert.bannedAt.toLocaleTimeString()}
//                     </td>
//                     <td className="px-6 py-4 text-xs text-red-400 font-bold">{alert.ip}</td>
//                     <td className="px-6 py-4 text-xs text-white font-sans font-semibold">{alert.type}</td>
                    
//                     {/* عمود الصلاحيات والـ Unban الاحترافي */}
//                     <td className="px-6 py-4 text-center">
//                       <button
//                         onClick={() => handleUnbanClick(alert.ip)}
//                         disabled={!isSuperAdmin}
//                         title={isSuperAdmin ? "Revoke Ban Instantly" : "Requires Super Admin Privilege"}
//                         className={`px-3 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all duration-300 flex items-center gap-1 mx-auto border ${
//                           isSuperAdmin
//                             ? 'bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-400 text-white border-blue-400/20 shadow-md shadow-blue-500/10 active:scale-95 cursor-pointer'
//                             : 'bg-white/5 text-slate-600 border-white/5 cursor-not-allowed opacity-40'
//                         }`}
//                       >
//                         <ShieldX size={12} /> Lift Ban
//                       </button>
//                     </td>
//                   </tr>
//                 ))}
//               </tbody>
//             </table>
            
//             {blockedIPsList.length === 0 && (
//               <div className="py-12 text-center text-slate-600 font-bold tracking-widest uppercase italic text-xs">
//                 No active IPs isolated in the mitigation pool.
//               </div>
//             )}
//           </div>

//           {/* ديزاين التقسيم (Pagination Control) المدمج أسفل الجدول */}
//           {blockedIPsList.length > itemsPerPage && (
//             <div className="p-4 bg-white/[0.01] border-t border-white/5 flex justify-center items-center gap-2">
//               <button 
//                 onClick={() => setCurrentPage(p => Math.max(p - 1, 1))} 
//                 disabled={currentPage === 1}
//                 className="px-2.5 py-1 bg-[#060a14] border border-white/5 rounded-lg text-slate-400 disabled:opacity-30 text-[10px] font-bold uppercase"
//               >
//                 Prev
//               </button>
//               <span className="text-slate-500 text-[10px] font-bold font-mono">
//                 {currentPage} / {totalPages}
//               </span>
//               <button 
//                 onClick={() => setCurrentPage(p => Math.min(p + 1, totalPages))} 
//                 disabled={currentPage === totalPages}
//                 className="px-2.5 py-1 bg-[#060a14] border border-white/5 rounded-lg text-slate-400 disabled:opacity-30 text-[10px] font-bold uppercase"
//               >
//                 Next
//               </button>
//             </div>
//           )}
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Dashboard;














// import React, { useState, useEffect } from 'react';
// // import io from 'socket.io-client';
// import { Activity, ShieldCheck, ShieldAlert, GlobeLock } from 'lucide-react';
// import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

// const StatCard = ({ title, value, icon, colorClass }) => (
//   <div className="bg-[#0f172a] border border-blue-900/20 p-6 rounded-2xl shadow-2xl relative group overflow-hidden transition-all duration-300 hover:border-blue-500/30">
//     <div className={`absolute -right-4 -top-4 w-24 h-24 rounded-full blur-3xl opacity-5 ${colorClass.replace('text-', 'bg-')}`}></div>
    
//     <div className="flex items-center justify-between relative z-10">
//       <div>
//         <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] mb-1">
//           {title}
//         </p>
//         <h3 className={`text-3xl font-bold tracking-tighter ${colorClass}`}>
//           {value}
//         </h3>
//       </div>
//       <div className={`p-3 rounded-xl bg-[#060a14]/50 border border-white/5 ${colorClass}`}>
//         {icon}
//       </div>
//     </div>
//   </div>
// );


// const Dashboard = ({ 
//   stats = { totalLogs: "0", normalTraffic: "0%", activeThreats: 0, blockedIPs: 0 }, 
//   recentAlerts = [] 
// }) => {

//   const [timelineData, setTimelineData] = useState([]);
//   useEffect(() => {
//         if (stats && typeof stats.activeThreats !== 'undefined') {
//             setTimelineData(current => [...current.slice(-19), {
//                 time: new Date().toLocaleTimeString(),
//                 threats: stats.activeThreats
//             }]);
//         }
//     }, [stats.activeThreats]);

//   return (
//     <div className="space-y-10 animate-fadeIn">
//       {/* 1. Stats Grid */}
//     <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
//       <StatCard title="Total Logs" value={stats.totalLogs} icon={<Activity size={24} />} colorClass="text-blue-500" />
//       <StatCard title="Normal Traffic" value={stats.normalTraffic} icon={<ShieldCheck size={24} />} colorClass="text-emerald-500" />
//       <StatCard title="Active Threats" value={stats.activeThreats} icon={<ShieldAlert size={24} />} colorClass="text-red-500" />
//       <StatCard title="Blocked IPs" value={stats.blockedIPs} icon={<GlobeLock size={24} />} colorClass="text-purple-500" />
//     </div>

//       {/* 2. Charts & Alerts Section */}
//       <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
//         {/* الـ Threat Detection Chart (2/3 من المساحة) */}
//         <div className="lg:col-span-2 bg-[#0f172a] border border-blue-900/20 p-8 rounded-3xl shadow-2xl">
//           <div className="flex items-center justify-between mb-8">
//             <h4 className="text-sm font-bold text-white uppercase tracking-widest">Threat Detection Timeline</h4>
//             <span className="flex items-center gap-2 text-[10px] text-emerald-500 font-black uppercase tracking-widest bg-emerald-500/10 px-3 py-1 rounded-full">
//                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span> Live Sync
//             </span>
//           </div>
//           {/* Line Chart  */}
//           {/*[ AI Analysis Graph Area ] */}
//           <ResponsiveContainer width="100%" height={250}>
//             <LineChart data={timelineData}>
//               <CartesianGrid strokeDasharray="3 3" stroke="#ffffff05" vertical={false} />
//               <XAxis 
//                 dataKey="time" 
//                 stroke="#475569" 
//                 fontSize={11} 
//                 fontWeight="bold"
//                 tickLine={false} 
//                 axisLine={false}
//               />
//               <YAxis 
//                 stroke="#475569" 
//                 fontSize={10} 
//                 tickLine={false} 
//                 axisLine={false}
//               />
//               <Tooltip 
//                 contentStyle={{ backgroundColor: '#0a0f1d', border: '1px solid #1e293b', borderRadius: '8px' }}
//                 itemStyle={{ color: '#ef4444', fontSize: '12px', fontWeight: 'bold' }}
//               />
//               <Line 
//                 type="monotone" 
//                 dataKey="threats" 
//                 stroke="#ef4444" 
//                 strokeWidth={3} 
//                 dot={false}
//                 animationDuration={300}
//               />
//             </LineChart>
//           </ResponsiveContainer>
//         </div>

//         {/* 3. AI Decision Status (Pie Chart) */}
//         <div className="bg-[#0f172a] border border-blue-900/20 p-8 rounded-3xl shadow-2xl">
//            <h4 className="text-sm font-bold text-white uppercase tracking-widest mb-8">Decision Status</h4>
//            <ResponsiveContainer width="100%" height={250}>
//               <PieChart>
//                 <Pie
//                   data={[
//                     { name: 'Normal', value: parseFloat(stats.normalTraffic) || 100 },
//                     { name: 'Suspicious', value: stats.activeThreats || 0 },
//                   ]}
//                   innerRadius={60}
//                   outerRadius={80}
//                   paddingAngle={5}
//                   dataKey="value"
//                 >
//                   <Cell fill="#10b981" /> 
//                   <Cell fill="#ef4444" /> 
//                 </Pie>
//                 <Tooltip 
//                   contentStyle={{ backgroundColor: '#0a0f1d', border: '1px solid #1e293b', borderRadius: '8px' }}
//                 />
//               </PieChart>
//             </ResponsiveContainer>
//         </div>

//       </div>

//       {/* 4. Recent Security Alerts (Full Width) */}
//       <div className="bg-[#0f172a] border border-blue-900/20 rounded-3xl shadow-2xl overflow-hidden">
//         <div className="p-6 border-b border-white/5 bg-white/5">
//            <h4 className="text-sm font-bold text-white uppercase tracking-widest">Recent Security Alerts</h4>
//         </div>
//         <div className="p-0">
//            {/* هنا جدول التنبيهات - 5 صفوف فقط */}
//            <div className="overflow-x-auto">
//             <table className="w-full text-left border-collapse">
//               <thead className="bg-white/5 text-[10px] font-black text-slate-500 uppercase tracking-[0.2em]">
//                 <tr>
//                   <th className="px-6 py-4">Timestamp</th>
//                   <th className="px-6 py-4">Source IP</th>
//                   <th className="px-6 py-4">Attack Type</th>
//                   <th className="px-6 py-4">Severity</th>
//                 </tr>
//               </thead>
//               <tbody className="divide-y divide-white/5">
//                 {recentAlerts.map((alert, index) => (
//                   <tr key={index} className="hover:bg-white/[0.02] transition-colors">
//                     <td className="px-6 py-4 text-xs text-slate-400 font-medium">{alert.time}</td>
//                     <td className="px-6 py-4 text-xs text-blue-400 font-bold font-mono">{alert.ip}</td>
//                     <td className="px-6 py-4 text-xs text-white font-bold">{alert.type}</td>
//                     <td className="px-6 py-4">
//                       <span className={`px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest ${
//                         alert.severity === 'High' ? 'bg-red-500/10 text-red-500' : 
//                         alert.severity === 'Medium' ? 'bg-amber-500/10 text-amber-500' : 'bg-blue-500/10 text-blue-500'
//                       }`}>
//                         {alert.severity}
//                       </span>
//                     </td>
//                   </tr>
//                 ))}
//               </tbody>
//             </table>
//             {recentAlerts.length === 0 && (
//               <div className="py-12 text-center text-slate-600 font-bold tracking-widest uppercase italic text-xs">
//                 No recent threats detected by AiSentinel
//               </div>
//             )}
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Dashboard;
