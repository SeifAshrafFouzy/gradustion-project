import React, { useState, useEffect } from 'react';
import { Users, Trash2, ArrowLeft, UserPlus, X, ShieldCheck, Loader2, Lock } from 'lucide-react';

const UserManagement = ({ onBack }) => {
  const [users, setUsers] = useState([]);
  const [showAddModal, setShowAddModal] = useState(false);
  const [newUser, setNewUser] = useState({ username: '', role: 'analyst' });
  const [addLoading, setAddLoading] = useState(false);
  const token = localStorage.getItem('token');

  const fetchUsers = async () => {
    try {
      const response = await fetch('http://localhost:8000/users', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await response.json();
      setUsers(Array.isArray(data) ? data : []);
    } catch (error) { console.error("Error fetching users"); }
  };

  useEffect(() => { fetchUsers(); }, []);

  const handleAddUser = async (e) => {
    e.preventDefault();
    setAddLoading(true);
    try {
      const response = await fetch('http://localhost:8000/users', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(newUser)
      });

      if (response.ok) {
        alert(`User ${newUser.username} added successfully! Password: temp123`);
        setShowAddModal(false);
        setNewUser({ username: '', role: 'analyst' });
        fetchUsers();
      } else {
        const err = await response.json();
        alert(err.detail || "Failed to add user");
      }
    } catch (error) { alert("API Connection Error"); }
    setAddLoading(false);
  };

  const handleDelete = async (username) => {
    if (!window.confirm(`Delete ${username}?`)) return;

    try {
      const response = await fetch(`http://127.0.0.1:8000/users/${username}`, {
        method: 'DELETE', 
        headers: { 
          'Authorization': `Bearer ${token}`
        }
      });

      if (response.ok) {
        fetchUsers(); 
      } else {
        const err = await response.json();
        alert(err.detail || "Failed to delete user");
      }
    } catch (error) {
      alert("Connection Error");
    }
  };

  // const handleDelete = async (username) => {
  //   if (!window.confirm(`Delete ${username}?`)) return;
  //   try {
  //     await fetch(`http://127.0.0.1:8000/users/${username}`, {
  //       method: 'DELETE',
  //       headers: { 'Authorization': `Bearer ${token}` }
  //     });
  //     fetchUsers();
  //   } catch (error) { alert("Delete failed"); }
  // };

  return (
    <div className="min-h-screen p-2 text-gray-900 dark:text-white transition-colors duration-300 font-sans">
      <div className="max-w-7xl mx-auto pb-10">
        
        {/* --- 1. Header (Synchronized Theme) --- */}
        <header className="mb-16">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
            <div className="flex items-center gap-6">
              <button 
                onClick={onBack} 
                className="p-3 bg-white dark:bg-[#0f172a] border border-gray-200 dark:border-white/5 hover:border-blue-500/50 rounded-2xl transition-all duration-300 text-blue-500 shadow-xl group"
              >
                <ArrowLeft size={24} className="group-hover:-translate-x-1 transition-transform text-blue-500" />
              </button>
              <div>
                <h1 className="text-4xl md:text-5xl font-black text-slate-900 dark:text-white uppercase tracking-tighter flex items-center gap-4">
                  <span className="bg-gradient-to-r from-blue-600 to-blue-400 bg-clip-text text-transparent">
                    User
                  </span> 
                  Management
                </h1>
                <div className="h-1 w-20 bg-blue-600 mt-2 rounded-full shadow-[0_0_10px_#2563eb]"></div>
              </div>
            </div>

            <button 
              onClick={() => setShowAddModal(true)}
              className="flex items-center gap-2 bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-400 text-white px-6 py-3.5 rounded-xl font-bold transition-all shadow-lg shadow-blue-500/20 active:scale-[0.99] w-full md:w-auto justify-center"
            >
              <UserPlus size={18} /> Add New User
            </button>
          </div>
        </header>

        {/* --- 2. Advanced Access Control Registry Table --- */}
        <div className="bg-white dark:bg-[#0f172a] rounded-[2rem] border border-gray-200 dark:border-blue-900/20 overflow-hidden shadow-2xl w-full">
          <div className="p-6 border-b border-gray-100 dark:border-white/5 bg-gray-50/50 dark:bg-[#060a14]/30 flex items-center gap-2">
            <Users size={16} className="text-blue-500" />
            <h3 className="font-black text-xs uppercase tracking-widest text-white-400">User Accounts</h3>
          </div>

          {/* Custom Slim Scrollbar */}
          <div className="max-h-[55vh] overflow-y-auto w-full pr-1
            [&::-webkit-scrollbar]:w-1.5 
            [&::-webkit-scrollbar-track]:bg-transparent 
            [&::-webkit-scrollbar-thumb]:bg-gray-300 dark:[&::-webkit-scrollbar-thumb]:bg-blue-900/40 
            [&::-webkit-scrollbar-thumb]:rounded-full 
            hover:[&::-webkit-scrollbar-thumb]:bg-blue-500 transition-colors">
            
            <table className="w-full table-fixed text-left border-collapse">
              <thead className="bg-gray-50 dark:bg-[#060a14]/80 text-gray-400 text-[10px] uppercase font-black tracking-[0.15em] border-b border-gray-100 dark:border-white/5 sticky top-0 z-10 backdrop-blur-md">
                <tr>
                  <th className="w-[35%] px-6 py-4">Username</th>
                  <th className="w-[25%] px-6 py-4">Role</th>
                  <th className="w-[25%] px-6 py-4">Status</th>
                  <th className="w-[15%] px-6 py-4 text-center">Revoke Access</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 dark:divide-white/5 font-mono text-[15px]">
                {users.map((user) => (
                  <tr key={user.username} className="hover:bg-blue-500/[0.02] transition duration-150 group">
                    <td className="px-6 py-4 font-bold font-sans tracking-tight text-slate-800 dark:text-slate-200 group-hover:text-blue-500 transition-colors">{user.username}</td>
                    <td className="px-6 py-4 uppercase text-slate-400 font-mono text-[15px] tracking-wider">{user.role}</td>
                    <td className="px-6 py-4 font-sans">
                      <span className={`px-2.5 py-1 rounded-md text-[10px] font-black tracking-wider border inline-block ${
                        user.must_change 
                          ? 'bg-orange-500/10 text-orange-500 border-orange-500/20' 
                          : 'bg-green-500/10 text-green-500 border-green-500/20'
                      }`}>
                        {user.must_change ? 'PENDING UPDATE' : 'ACTIVE'}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-center">
                      <button 
                        onClick={() => handleDelete(user.username)} 
                        className="p-2 text-red-500 hover:bg-red-500/10 rounded-xl transition-all duration-200 active:scale-90"
                      >
                        <Trash2 size={16} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* --- 3. Glassmorphic Pro Modal --- */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-md flex items-center justify-center z-[1000] p-4 animate-in fade-in duration-200">
          <div className="bg-white dark:bg-[#0a0f1d] w-full max-w-md rounded-[2rem] shadow-2xl p-8 border border-gray-200 dark:border-blue-500/20 animate-in zoom-in-95 duration-200 text-gray-900 dark:text-white relative overflow-hidden">
            <div className="absolute -top-20 -right-20 w-48 h-48 bg-blue-500/10 rounded-full blur-3xl pointer-events-none"></div>
            
            <div className="flex justify-between items-center mb-6 relative z-10">
              <h2 className="text-xl font-black flex items-center gap-2 uppercase tracking-tight">
                <UserPlus size={22} className="text-blue-500"/> Provision Identity
              </h2>
              <button 
                onClick={() => setShowAddModal(false)} 
                className="text-gray-400 hover:text-red-500 p-1 hover:bg-red-500/10 rounded-lg transition-colors"
              >
                <X size={20}/>
              </button>
            </div>
            
            <form onSubmit={handleAddUser} className="space-y-5 relative z-10">
              <div className="relative">
                <Lock className="absolute left-4 top-3.5 text-gray-400" size={16}/>
                <input 
                  type="text" placeholder="Username" required
                  className="w-full bg-gray-50 dark:bg-[#060a14] border border-gray-200 dark:border-blue-500/10 rounded-xl py-3.5 pl-11 pr-4 outline-none focus:border-blue-500 dark:text-white text-xs font-medium font-mono transition-colors"
                  onChange={(e) => setNewUser({...newUser, username: e.target.value})}
                />
              </div>

              <div className="relative">
                <select 
                  className="w-full bg-gray-50 dark:bg-[#060a14] border border-gray-200 dark:border-blue-500/10 rounded-xl p-3.5 outline-none focus:border-blue-500 dark:text-white text-xs font-bold tracking-wider uppercase cursor-pointer transition-colors appearance-none"
                  onChange={(e) => setNewUser({...newUser, role: e.target.value})}
                  value={newUser.role}
                >
                  <option value="analyst">Analyst</option>
                  <option value="super_admin">Super Admin</option>
                </select>
                <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-4 text-gray-400">
                  <svg className="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/></svg>
                </div>
              </div>

              <button 
                type="submit" disabled={addLoading}
                className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-blue-800 text-white font-black uppercase text-xs tracking-widest py-4 rounded-xl shadow-lg shadow-blue-500/10 flex items-center justify-center gap-2 active:scale-[0.98] transition-all"
              >
                {addLoading ? <Loader2 className="animate-spin" size={16}/> : <ShieldCheck size={16}/>}
                {addLoading ? "Authorizing..." : "Commit Credentials"}
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default UserManagement;
