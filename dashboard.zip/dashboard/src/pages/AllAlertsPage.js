import React, { useState } from 'react';
import { ArrowLeft, Calendar, ChevronLeft, ChevronRight } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const AllAlertsPage = ({ onBack, allLogs = [] }) => {
  const currentYear = "2026";
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [currentPage, setCurrentPage] = useState(1);
  const logsPerPage = 100;

  const cyberColors = {
    normal: "#10b981",  
    static: "#f59e0b", 
    threat: "#ef4444",  
    anomaly: "#a855f7"  
  };

  const filteredLogsByDate = allLogs.filter(log => {
    const logTimestamp = log["@timestamp"] || log.time || "";
    if (logTimestamp.includes(" ")) {
      return logTimestamp.split(" ")[0] === selectedDate;
    } else if (logTimestamp.includes("T")) {
      return logTimestamp.split("T")[0] === selectedDate;
    }
    return logTimestamp.includes(selectedDate);
  });

  const normalCount = filteredLogsByDate.filter(l => l.status === "normal" || l.status === "success").length;
  const staticCount = filteredLogsByDate.filter(l => String(JSON.stringify(l.stages)).toLowerCase().includes("static")).length;
  const threatCount = filteredLogsByDate.filter(l => String(JSON.stringify(l.stages)).toLowerCase().includes("threat")).length;
  const anomalyCount = filteredLogsByDate.filter(l => String(JSON.stringify(l.stages)).toLowerCase().includes("anomaly")).length;


  const localChartData = (() => {
    const hourlyMap = {};
    
    filteredLogsByDate.forEach(log => {
      const ts = log["@timestamp"] || log.time || "";
      let hour = "00:00";
      if (ts.includes(" ")) {
        hour = ts.split(" ")[1].substring(0, 5); 
      } else if (ts.includes("T")) {
        hour = ts.split("T")[1].substring(0, 5);
      }
      
      if (!hourlyMap[hour]) {
        hourlyMap[hour] = { time: hour, Normal: 0, Static: 0, Threat: 0, Anomaly: 0 };
      }
      
      const status = String(log.status || "").toLowerCase();
      const stages = String(JSON.stringify(log.stages || log.stage || "")).toLowerCase();
      
      if (status === "normal" || status === "success") {
        hourlyMap[hour].Normal += 1;
      } else if (stages.includes("static")) {
        hourlyMap[hour].Static += 1;
      } else if (stages.includes("threat")) {
        hourlyMap[hour].Threat += 1;
      } else if (stages.includes("anomaly")) {
        hourlyMap[hour].Anomaly += 1;
      } else {
        hourlyMap[hour].Static += 1; 
      }
    });
    
    return Object.values(hourlyMap).sort((a, b) => a.time.localeCompare(b.time));
  })();

  const totalPages = Math.ceil(filteredLogsByDate.length / logsPerPage) || 1;
  const indexOfLastLog = currentPage * logsPerPage;
  const indexOfFirstLog = indexOfLastLog - logsPerPage;
  const currentLogs = filteredLogsByDate.slice(indexOfFirstLog, indexOfLastLog);

  return (
    <div className="min-h-screen p-2 text-white font-sans animate-fadeIn">
      <div className="max-w-7xl mx-auto pb-10">
        
        {/* --- 1. Top Integrated Header --- */}
        <header className="mb-8 flex flex-col md:flex-row justify-between items-start md:items-center gap-6 pb-6 border-b border-white/5">
          <div className="flex items-center gap-6 min-w-0">
            <button 
              onClick={onBack} 
              className="p-3 bg-[#0f172a] border border-white/5 hover:border-blue-500/50 rounded-2xl transition-all duration-300 text-blue-400 shadow-xl group flex-shrink-0"
            >
              <ArrowLeft size={24} className="group-hover:-translate-x-1 transition-transform" />
            </button>
            <div>
              <h1 className="text-3xl md:text-2xl lg:text-5xl font-black uppercase tracking-tighter whitespace-nowrap">
                <span className="bg-gradient-to-r from-blue-600 to-blue-400 bg-clip-text text-transparent">
                  AiSentinel
                </span> Central Alerts
              </h1>
              <div className="h-1 w-20 bg-blue-600 mt-2 rounded-full shadow-[0_0_10px_#2563eb]"></div>
            </div>
          </div>

          {/* Time Window Input */}
          <div className="flex flex-col items-start md:items-end gap-2 flex-shrink-0 translate-y-[3px]">
            <label className="text-xs font-black text-white uppercase tracking-widest">
              Time Window
            </label>
            <div className="relative flex items-center bg-blue-900/20 border border-blue-500/50 rounded-xl px-4 py-2.5 transition-colors cursor-pointer hover:bg-blue-900/40">
              <Calendar size={14} className="text-blue-500 mr-2.5" />
              <input
                type="date"
                min={`${currentYear}-01-01`}
                max={`${currentYear}-12-31`}
                value={selectedDate}
                onChange={(e) => {
                  setSelectedDate(e.target.value);
                  setCurrentPage(1);
                }}
                className="bg-transparent text-xs font-black font-mono outline-none cursor-pointer text-white w-36"
              />
            </div>
            {/* <div className="relative flex items-center bg-[#060a14] border border-white/10 rounded-xl px-4 py-2.5 group hover:border-blue-500/50 transition-colors cursor-pointer">
              <Calendar size={14} className="text-blue-500 mr-2.5" />
              <input
                type="date"
                min={`${currentYear}-01-01`}
                max={`${currentYear}-12-31`}
                value={selectedDate}
                onChange={(e) => {
                  setSelectedDate(e.target.value);
                  setCurrentPage(1); 
                }}
                className="bg-transparent text-xs font-black font-mono outline-none cursor-pointer text-slate-200 w-36 focus:text-white"
              />
            </div> */}
          </div>
        </header>

        {/* --- 2. Security Analytics Chart Stage --- */}
        <div className="bg-[#0f172a] border border-white/5 rounded-[2rem] p-8 shadow-2xl mb-8 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-96 h-96 bg-blue-500/5 rounded-full blur-[120px] pointer-events-none" />
          
          <div className="mb-8">
            <h3 className="font-black text-sm uppercase tracking-widest text-white">
              Multi-Layered Detection Distribution ({filteredLogsByDate.length} Logs)
            </h3>
          </div>

          <div className="w-full h-[300px] font-mono text-xs">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={localChartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorNormal" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor={cyberColors.normal} stopOpacity={0.2}/>
                    <stop offset="95%" stopColor={cyberColors.normal} stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorStatic" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor={cyberColors.static} stopOpacity={0.2}/>
                    <stop offset="95%" stopColor={cyberColors.static} stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorThreat" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor={cyberColors.threat} stopOpacity={0.2}/>
                    <stop offset="95%" stopColor={cyberColors.threat} stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorAnomaly" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor={cyberColors.anomaly} stopOpacity={0.2}/>
                    <stop offset="95%" stopColor={cyberColors.anomaly} stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" opacity={0.2} />
                <XAxis dataKey="time" stroke="#475569" />
                <YAxis stroke="#475569" />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#060a14', borderColor: 'rgba(255,255,255,0.05)', borderRadius: '1rem' }}
                  itemStyle={{ fontFamily: 'sans-serif', fontWeight: 'bold' }}
                />
                <Area type="monotone" dataKey="Normal" stroke={cyberColors.normal} fillOpacity={1} fill="url(#colorNormal)" name="Normal Traffic" />
                <Area type="monotone" dataKey="Static" stroke={cyberColors.static} fillOpacity={1} fill="url(#colorStatic)" name="Static Rules" />
                <Area type="monotone" dataKey="Threat" stroke={cyberColors.threat} fillOpacity={1} fill="url(#colorThreat)" name="Threat ML Engine" />
                <Area type="monotone" dataKey="Anomaly" stroke={cyberColors.anomaly} fillOpacity={1} fill="url(#colorAnomaly)" name="Anomaly Behavioral" />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          <div className="mt-8 pt-6 border-t border-white/5 flex flex-wrap justify-center items-center gap-x-12 gap-y-4 text-[10px] font-black uppercase tracking-[0.15em] text-slate-400">
            <div className="flex items-center gap-3"><span className="w-3 h-3 rounded-md shadow-[0_0_8px_#10b981]" style={{ backgroundColor: cyberColors.normal }}></span> Normal Traffic</div>
            <div className="flex items-center gap-3"><span className="w-3 h-3 rounded-md shadow-[0_0_8px_#f59e0b]" style={{ backgroundColor: cyberColors.static }}></span> Static Rules</div>
            <div className="flex items-center gap-3"><span className="w-3 h-3 rounded-md shadow-[0_0_8px_#ef4444]" style={{ backgroundColor: cyberColors.threat }}></span> Threat ML Engine</div>
            <div className="flex items-center gap-3"><span className="w-3 h-3 rounded-md shadow-[0_0_8px_#a855f7]" style={{ backgroundColor: cyberColors.anomaly }}></span> Anomaly Behavioral</div>
          </div>
        </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {[
            { title: "Total Normal", val: normalCount, color: "border-emerald-500/30 bg-emerald-500/5 text-emerald-400" },
            { title: "Total Static", val: staticCount, color: "border-amber-500/30 bg-amber-500/5 text-amber-400" },
            { title: "Total Threat", val: threatCount, color: "border-red-500/30 bg-red-500/5 text-red-400" },
            { title: "Total Anomaly", val: anomalyCount, color: "border-purple-500/30 bg-purple-500/5 text-purple-400" }
          ].map((card, i) => (
            <div key={i} className={`p-5 rounded-3xl border ${card.color} flex flex-col justify-center items-center shadow-lg`}>
              <span className="text-[9px] font-black uppercase tracking-[0.2em] opacity-80 mb-2">{card.title}</span>
              <span className="text-2xl font-black font-mono">{card.val}</span>
            </div>
          ))}
        </div>


        {/* --- 3. Centralized Security Events Table --- */}
        <div className="bg-[#0f172a] rounded-[2rem] border border-white/5 overflow-hidden shadow-2xl w-full">
          <div className="p-6 border-b border-white/5 bg-[#060a14]/30 flex justify-between items-center">
            <h3 className="font-black text-xs uppercase tracking-widest text-slate-400">
              Centralized Security Events
            </h3>
            <span className="text-[10px] bg-blue-500/10 text-blue-400 px-3 py-1 rounded-lg border border-blue-500/10 font-bold font-mono">
              TOTAL LOGS FOR DAY: {filteredLogsByDate.length}
            </span>
          </div>

          <div className="max-h-[72vh] overflow-y-auto w-full pr-1
            [&::-webkit-scrollbar]:w-2 
            [&::-webkit-scrollbar-track]:bg-transparent 
            [&::-webkit-scrollbar-thumb]:bg-blue-900/40 
            [&::-webkit-scrollbar-thumb]:rounded-full 
            hover:[&::-webkit-scrollbar-thumb]:bg-blue-500 transition-colors">
            
            <table className="w-full table-fixed text-left border-collapse">
              <thead className="bg-[#060a14]/80 text-slate-400 text-[10px] uppercase font-black tracking-[0.15em] border-b border-white/5 sticky top-0 z-10 backdrop-blur-md">
                <tr>
                  <th className="w-[15%] px-6 py-4">Timestamp</th>
                  <th className="w-[15%] px-6 py-4">Source IP</th>
                  <th className="w-[30%] px-6 py-4">Payload Content / Event</th>
                  <th className="w-[10%] px-6 py-4 text-center">Status</th>
                  <th className="w-[15%] px-6 py-4">Attack Type</th>
                  <th className="w-[15%] px-6 py-4">Triggered Stage</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 font-mono text-[11px]">
                {currentLogs.map((log, i) => {
                  const isAttack = log.status !== 'normal' && log.status !== 'success';
                  const payloadContent = log.request_url || log.request || log.payload || "N/A";
                  // const payloadContent = log.request || log.payload || log.message || "HTTP GET /index.php compliant";
                  
                  // let displayStage = "CORE_PIPELINE";
                  // if (log.stage) displayStage = log.stage;
                  // else if (log.stages) displayStage = Array.isArray(log.stages) ? log.stages.join(' -> ') : String(log.stages);
                  // else if (isAttack) displayStage = "DETECTION_GATEWAY";
                  let displayStage = "CORE_PIPELINE";
                  if (log.stage) {
                    displayStage = log.stage;
                  } else if (log.stages) {
                    displayStage = Array.isArray(log.stages) ? log.stages.join(' -> ') : String(log.stages);
                  }

                  if (displayStage.includes("->")) {
                    const stagesArray = displayStage.split("->");
                    displayStage = stagesArray[stagesArray.length - 1].strip ? stagesArray[stagesArray.length - 1].trim() : stagesArray[stagesArray.length - 1];
                  } else if (displayStage.includes(":")) {
                    displayStage = displayStage.split(":")[0];
                  }

                  return (
                    <tr key={i} className="hover:bg-blue-500/[0.02] transition">
                      <td className="px-6 py-4 text-slate-500 font-sans">{log["@timestamp"] || log.time}</td>
                      <td className="px-6 py-4 font-bold text-slate-300">{log.source_ip || log.ip}</td>
                      <td className="px-6 py-4 text-slate-400 truncate" title={payloadContent}>{payloadContent}</td>
                      
                      {/* Status */}
                      <td className="px-6 py-4 text-center font-sans">
                        <span className={`px-2.5 py-1 rounded-md text-[9px] font-black tracking-wider border block w-full text-center ${
                          isAttack ? 'bg-red-500/10 text-red-500 border-red-500/20 shadow-[0_0_10px_rgba(239,68,68,0.05)]' : 'bg-green-500/10 text-green-500 border-green-500/20'
                        }`}>
                          {isAttack ? 'ATTACK' : 'NORMAL'}
                        </span>
                      </td>

                      {/* Attack Type */}
                      <td className="px-6 py-4">
                        <span className={isAttack ? "text-red-400 font-extrabold uppercase" : "text-slate-600"}>
                          {log.sub_type && log.sub_type !== "None" ? log.sub_type : (isAttack ? "UNKNOWN_EXPLOIT" : "-")}
                        </span>
                      </td>

                      {/* Triggered Stage */}
                      <td className="px-6 py-4 text-blue-400 font-sans font-bold truncate" title={displayStage}>
                        {displayStage.toUpperCase()}
                      </td>
                    </tr>
                  );
                })}

                {filteredLogsByDate.length === 0 && (
                  <tr>
                    <td colSpan="6" className="py-12 text-center text-slate-600 font-bold tracking-widest uppercase italic text-xs">
                      No events captured in the current pipeline matrix for this date.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          <div className="p-4 bg-[#060a14]/50 border-t border-white/5 flex justify-center items-center w-full">
            <div className="flex items-center gap-2 max-w-md justify-center overflow-x-auto px-2 py-1">
              <button
                onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                disabled={currentPage === 1}
                className="p-2 bg-[#0f172a] border border-white/5 rounded-xl text-slate-400 hover:text-white disabled:opacity-40 disabled:hover:text-slate-400 transition flex-shrink-0"
              >
                <ChevronLeft size={16} />
              </button>

              {Array.from({ length: totalPages }, (_, index) => {
                const pageNum = index + 1;
                if (totalPages > 6 && Math.abs(currentPage - pageNum) > 2 && pageNum !== 1 && pageNum !== totalPages) {
                  return null;
                }
                return (
                  <button
                    key={pageNum}
                    onClick={() => setCurrentPage(pageNum)}
                    className={`w-8 h-8 rounded-xl text-xs font-bold font-mono transition-all flex-shrink-0 ${
                      currentPage === pageNum 
                        ? 'bg-blue-600 text-white shadow-md shadow-blue-500/20 border border-blue-500/30' 
                        : 'bg-[#0f172a] border border-white/5 text-slate-400 hover:text-white'
                    }`}
                  >
                    {pageNum}
                  </button>
                );
              })}

              <button
                onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                disabled={currentPage === totalPages}
                className="p-2 bg-[#0f172a] border border-white/5 rounded-xl text-slate-400 hover:text-white disabled:opacity-40 disabled:hover:text-slate-400 transition flex-shrink-0"
              >
                <ChevronRight size={16} />
              </button>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};

export default AllAlertsPage;



// import React, { useState } from 'react';
// import { ArrowLeft, Calendar, ChevronLeft, ChevronRight } from 'lucide-react';
// import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

// const AllAlertsPage = ({ onBack, allLogs = [], chartData = [] }) => {
//   const currentYear = "2026";
//   const [selectedDate, setSelectedDate] = useState(`${currentYear}-06-21`);
//   const [currentPage, setCurrentPage] = useState(1);
//   const logsPerPage = 50;
//   const totalPages = Math.ceil(allLogs.length / logsPerPage) || 1;
//   const indexOfLastLog = currentPage * logsPerPage;
//   const indexOfFirstLog = indexOfLastLog - logsPerPage;
//   const currentLogs = allLogs.slice(indexOfFirstLog, indexOfLastLog);

//   const cyberColors = {
//     normal: "#10b981",  
//     static: "#f59e0b", 
//     threat: "#ef4444",  
//     anomaly: "#a855f7"  
//   };

//   return (
//     <div className="min-h-screen p-2 text-white font-sans animate-fadeIn">
//       <div className="max-w-7xl mx-auto pb-10">
        
//         {/* --- 1. Top Integrated Header --- */}
//         <header className="mb-8 flex flex-col md:flex-row justify-between items-start md:items-center gap-6 pb-6 border-b border-white/5">
//           <div className="flex items-center gap-6 min-w-0">
//             <button 
//               onClick={onBack} 
//               className="p-3 bg-[#0f172a] border border-white/5 hover:border-blue-500/50 rounded-2xl transition-all duration-300 text-blue-400 shadow-xl group flex-shrink-0"
//             >
//               <ArrowLeft size={24} className="group-hover:-translate-x-1 transition-transform" />
//             </button>
//             <div>
//               <h1 className="text-3xl md:text-2xl lg:text-5xl font-black uppercase tracking-tighter whitespace-nowrap">
//                 <span className="bg-gradient-to-r from-blue-600 to-blue-400 bg-clip-text text-transparent">
//                   AiSentinel
//                 </span> Central Alerts
//               </h1>
//               <div className="h-1 w-20 bg-blue-600 mt-2 rounded-full shadow-[0_0_10px_#2563eb]"></div>
//             </div>
//           </div>

//           {/*Time Window */}
//                   <div className="flex flex-col items-start md:items-end gap-2 flex-shrink-0 translate-y-[3px]">
//                       <label className="text-xs font-black text-white uppercase tracking-widest">
//                           Time Window
//                       </label>

//                       <div className="relative flex items-center bg-[#060a14] border border-white/10 rounded-xl px-4 py-2.5 group hover:border-blue-500/50 transition-colors cursor-pointer">
//                           <Calendar size={14} className="text-blue-500 mr-2.5" />
//                           <input
//                               type="date"
//                               min={`${currentYear}-01-01`}
//                               max={`${currentYear}-12-31`}
//                               value={selectedDate}
//                               onChange={(e) => setSelectedDate(e.target.value)}
//                               className="bg-transparent text-xs font-black font-mono outline-none cursor-pointer text-slate-200 w-36 focus:text-white"
//                           />
//                       </div>
//                   </div>
//         </header>

//         {/* --- 2. Security Analytics Chart Stage --- */}
//         <div className="bg-[#0f172a] border border-white/5 rounded-[2rem] p-8 shadow-2xl mb-8 relative overflow-hidden">
//           <div className="absolute top-0 right-0 w-96 h-96 bg-blue-500/5 rounded-full blur-[120px] pointer-events-none" />
          
//           <div className="mb-8">
//             <h3 className="font-black text-sm uppercase tracking-widest text-white">
//               Multi-Layered Detection Distribution
//             </h3>
//           </div>

//           {/* Area Chart Component */}
//           <div className="w-full h-[300px] font-mono text-xs">
//             <ResponsiveContainer width="100%" height="100%">
//               <AreaChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
//                 <defs>
//                   <linearGradient id="colorNormal" x1="0" y1="0" x2="0" y2="1">
//                     <stop offset="5%" stopColor={cyberColors.normal} stopOpacity={0.2}/>
//                     <stop offset="95%" stopColor={cyberColors.normal} stopOpacity={0}/>
//                   </linearGradient>
//                   <linearGradient id="colorStatic" x1="0" y1="0" x2="0" y2="1">
//                     <stop offset="5%" stopColor={cyberColors.static} stopOpacity={0.2}/>
//                     <stop offset="95%" stopColor={cyberColors.static} stopOpacity={0}/>
//                   </linearGradient>
//                   <linearGradient id="colorThreat" x1="0" y1="0" x2="0" y2="1">
//                     <stop offset="5%" stopColor={cyberColors.threat} stopOpacity={0.2}/>
//                     <stop offset="95%" stopColor={cyberColors.threat} stopOpacity={0}/>
//                   </linearGradient>
//                   <linearGradient id="colorAnomaly" x1="0" y1="0" x2="0" y2="1">
//                     <stop offset="5%" stopColor={cyberColors.anomaly} stopOpacity={0.2}/>
//                     <stop offset="95%" stopColor={cyberColors.anomaly} stopOpacity={0}/>
//                   </linearGradient>
//                 </defs>
//                 <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" opacity={0.2} />
//                 <XAxis dataKey="time" stroke="#475569" />
//                 <YAxis stroke="#475569" />
//                 <Tooltip 
//                   contentStyle={{ backgroundColor: '#060a14', borderColor: 'rgba(255,255,255,0.05)', borderRadius: '1rem' }}
//                   itemStyle={{ fontFamily: 'sans-serif', fontWeight: 'bold' }}
//                 />
//                 <Area type="monotone" dataKey="Normal" stroke={cyberColors.normal} fillOpacity={1} fill="url(#colorNormal)" name="Normal Traffic" />
//                 <Area type="monotone" dataKey="Static" stroke={cyberColors.static} fillOpacity={1} fill="url(#colorStatic)" name="Static Rules" />
//                 <Area type="monotone" dataKey="Threat" stroke={cyberColors.threat} fillOpacity={1} fill="url(#colorThreat)" name="Threat ML Engine" />
//                 <Area type="monotone" dataKey="Anomaly" stroke={cyberColors.anomaly} fillOpacity={1} fill="url(#colorAnomaly)" name="Anomaly Behavioral" />
//               </AreaChart>
//             </ResponsiveContainer>
//           </div>

//           <div className="mt-8 pt-6 border-t border-white/5 flex flex-wrap justify-center items-center gap-x-12 gap-y-4 text-[10px] font-black uppercase tracking-[0.15em] text-slate-400">
//             <div className="flex items-center gap-3"><span className="w-3 h-3 rounded-md shadow-[0_0_8px_#10b981]" style={{ backgroundColor: cyberColors.normal }}></span> Normal Traffic</div>
//             <div className="flex items-center gap-3"><span className="w-3 h-3 rounded-md shadow-[0_0_8px_#f59e0b]" style={{ backgroundColor: cyberColors.static }}></span> Static Rules</div>
//             <div className="flex items-center gap-3"><span className="w-3 h-3 rounded-md shadow-[0_0_8px_#ef4444]" style={{ backgroundColor: cyberColors.threat }}></span> Threat ML Engine</div>
//             <div className="flex items-center gap-3"><span className="w-3 h-3 rounded-md shadow-[0_0_8px_#a855f7]" style={{ backgroundColor: cyberColors.anomaly }}></span> Anomaly Behavioral</div>
//           </div>
//         </div>

//         {/* --- 3. Centralized Security Events Table --- */}
//         <div className="bg-[#0f172a] rounded-[2rem] border border-white/5 overflow-hidden shadow-2xl w-full">
//           <div className="p-6 border-b border-white/5 bg-[#060a14]/30 flex justify-between items-center">
//             <h3 className="font-black text-xs uppercase tracking-widest text-slate-400">
//               Centralized Security Events
//             </h3>
//             <span className="text-[10px] bg-blue-500/10 text-blue-400 px-3 py-1 rounded-lg border border-blue-500/10 font-bold font-mono">
//               TOTAL LOGS: {allLogs.length}
//             </span>
//           </div>

//           <div className="max-h-[50vh] overflow-y-auto w-full pr-1
//             [&::-webkit-scrollbar]:w-1.5 
//             [&::-webkit-scrollbar-track]:bg-transparent 
//             [&::-webkit-scrollbar-thumb]:bg-blue-900/40 
//             [&::-webkit-scrollbar-thumb]:rounded-full 
//             hover:[&::-webkit-scrollbar-thumb]:bg-blue-500 transition-colors">
            
//             <table className="w-full table-fixed text-left border-collapse">
//               <thead className="bg-[#060a14]/80 text-slate-400 text-[10px] uppercase font-black tracking-[0.15em] border-b border-white/5 sticky top-0 z-10 backdrop-blur-md">
//                 <tr>
//                   <th className="w-[12%] px-6 py-4">Timestamp</th>
//                   <th className="w-[15%] px-6 py-4">Source IP</th>
//                   <th className="w-[33%] px-6 py-4">Payload Content / Event</th>
//                   <th className="w-[10%] px-6 py-4 text-center">Status</th>
//                   <th className="w-[15%] px-6 py-4">Attack Type</th>
//                   <th className="w-[15%] px-6 py-4">Triggered Stage</th>
//                 </tr>
//               </thead>
//               <tbody className="divide-y divide-white/5 font-mono text-[11px]">
//                 {currentLogs.map((log, i) => {
//                   const isAttack = log.status !== 'normal';
//                   return (
//                     <tr key={i} className="hover:bg-blue-500/[0.02] transition">
//                       <td className="px-6 py-4 text-slate-500 font-sans">{log["@timestamp"] || log.time}</td>
//                       <td className="px-6 py-4 font-bold text-slate-300">{log.source_ip || log.ip}</td>
//                       <td className="px-6 py-4 text-slate-400 truncate" title={log.request}>{log.request}</td>
                      
//                       {/* 1.Status*/}
//                       <td className="px-6 py-4 text-center font-sans">
//                         <span className={`px-2.5 py-1 rounded-md text-[9px] font-black tracking-wider border block w-full text-center ${
//                           isAttack ? 'bg-red-500/10 text-red-500 border-red-500/20 shadow-[0_0_10px_rgba(239,68,68,0.05)]' : 'bg-green-500/10 text-green-500 border-green-500/20'
//                         }`}>
//                           {isAttack ? 'ATTACK' : 'NORMAL'}
//                         </span>
//                       </td>

//                       {/* 2. Attack Type */}
//                       <td className="px-6 py-4">
//                         <span className={isAttack ? "text-red-400 font-extrabold uppercase" : "text-slate-600"}>
//                           {log.sub_type || "-"}
//                         </span>
//                       </td>

//                       {/* 3. Triggered Stage */}
//                       <td className="px-6 py-4 text-slate-400 font-sans truncate" title={log.stage}>{log.stage}</td>
//                     </tr>
//                   );
//                 })}

//                 {allLogs.length === 0 && (
//                   <tr>
//                     <td colSpan="6" className="py-12 text-center text-slate-600 font-bold tracking-widest uppercase italic text-xs">
//                       No events captured in the current pipeline matrix.
//                     </td>
//                   </tr>
//                 )}
//               </tbody>
//             </table>
//           </div>

//           {/*  5. Clean Pages Controller Panel */}
//           <div className="p-4 bg-[#060a14]/50 border-t border-white/5 flex justify-center items-center">
//             <div className="flex items-center gap-2">
//               <button
//                 onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
//                 disabled={currentPage === 1}
//                 className="p-2 bg-[#0f172a] border border-white/5 rounded-xl text-slate-400 hover:text-white disabled:opacity-40 disabled:hover:text-slate-400 transition"
//               >
//                 <ChevronLeft size={16} />
//               </button>

//               {Array.from({ length: totalPages }, (_, index) => (
//                 <button
//                   key={index + 1}
//                   onClick={() => setCurrentPage(index + 1)}
//                   className={`w-8 h-8 rounded-xl text-xs font-bold font-mono transition-all ${
//                     currentPage === index + 1 
//                       ? 'bg-blue-600 text-white shadow-md shadow-blue-500/20 border border-blue-500/30' 
//                       : 'bg-[#0f172a] border border-white/5 text-slate-400 hover:text-white'
//                   }`}
//                 >
//                   {index + 1}
//                 </button>
//               ))}

//               <button
//                 onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
//                 disabled={currentPage === totalPages}
//                 className="p-2 bg-[#0f172a] border border-white/5 rounded-xl text-slate-400 hover:text-white disabled:opacity-40 disabled:hover:text-slate-400 transition"
//               >
//                 <ChevronRight size={16} />
//               </button>
//             </div>
//           </div>

//         </div>

//       </div>
//     </div>
//   );
// };

// export default AllAlertsPage;
