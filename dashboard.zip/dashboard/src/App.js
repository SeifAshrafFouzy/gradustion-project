import React, { useState, useEffect, useCallback } from 'react';
import io from 'socket.io-client';
import Dashboard from './pages/Dashboard';
import LogsHistory from './pages/LogsHistory';
import LoginPage from './pages/LoginPage';
import ChangePasswordPage from './pages/ChangePasswordPage';
import UserManagement from './pages/UserManagement';
import DetectionHub from './pages/DetectionHub';
import AllAlertsPage from './pages/AllAlertsPage';
import StaticEnginePage from './pages/StaticEnginePage';
import ThreatDetectionPage from './pages/ThreatDetectionPage';
import AnomalyDetectionPage from './pages/AnomalyDetectionPage';
import MainLayout from './components/MainLayout';
import ThemeToggle from './components/ThemeToggle';
import { initParticlesEngine } from "@tsparticles/react";
import { loadFull } from "tsparticles";
import LogAnalyzer from './pages/LogAnalyzer';

function App() {
  const [init, setInit] = useState(false);
  const [view, setView] = useState('dashboard');
  const [darkMode, setDarkMode] = useState(true);
  const [isLoggedIn, setIsLoggedIn] = useState(!!localStorage.getItem('token'));
  const [mustChangePwd, setMustChangePwd] = useState(localStorage.getItem('mustChange') === 'true');
  const [currentUser, setCurrentUser] = useState(() => {
    const localUser = localStorage.getItem('username');
    if (!localUser) return null;

    if (localUser.trim().startsWith('{') || localUser.trim().startsWith('[')) {
      try {
        return JSON.parse(localUser).username || null;
      } catch (e) {
        return null;
      }
    }

    if (localUser === "[object Object]") {
      const localRole = localStorage.getItem('role') || "";
      return localRole === "super_admin" ? "admin_boss" : null;
    }

    return localUser;
  });
  const [userRole, setUserRole] = useState(localStorage.getItem('role') || "");
  const [recentAlerts, setRecentAlerts] = useState([]);
  const [allLogsState, setAllLogsState] = useState([]); 
  const [chartDataState, setChartDataState] = useState([]); 
  const [isConnected, setIsConnected] = useState(false);
  const [stats, setStats] = useState({
      totalLogs: "0",
      normalTraffic: "0", 
      activeThreats: 0,
      blockedIPs: 0
  });
  const [analyzerFile, setAnalyzerFile] = useState(null);
  const [analyzerLoading, setAnalyzerLoading] = useState(false);
  const [analyzerResult, setAnalyzerResult] = useState(null);
  const [alertInitialDate, setAlertInitialDate] = useState(new Date().toISOString().split('T')[0]);

  const generateChartData = (logs) => {
    const hourlyData = {};
    const recentLogs = logs.slice(-200); 
    
    recentLogs.forEach(log => {
      const ts = log["@timestamp"] || log.time || "";
      let hour = "00:00";
      if (ts && ts.includes(" ")) {
        hour = ts.split(" ")[1].substring(0, 5); 
      } else if (ts && ts.includes("T")) {
        hour = ts.split("T")[1].substring(0, 5);
      }
      
      if (!hourlyData[hour]) {
        hourlyData[hour] = { time: hour, Normal: 0, Static: 0, Threat: 0, Anomaly: 0 };
      }
      
      const status = String(log.status || "").toLowerCase();
      const stages = String(JSON.stringify(log.stages || "")).toLowerCase();
      
      if (status === "normal" || status === "success") {
        hourlyData[hour].Normal += 1;
      } else if (stages.includes("static")) {
        hourlyData[hour].Static += 1;
      } else if (stages.includes("threat")) {
        hourlyData[hour].Threat += 1;
      } else if (stages.includes("anomaly")) {
        hourlyData[hour].Anomaly += 1;
      } else {
        hourlyData[hour].Static += 1; 
      }
    });
    
    return Object.values(hourlyData).sort((a, b) => a.time.localeCompare(b.time));
  };

  useEffect(() => {
      if (!isLoggedIn) return;

      const fetchInitialData = async () => {
          try {
              const token = localStorage.getItem('token');
              const response = await fetch('http://localhost:8000/api/logs', {
                  headers: { 'Authorization': `Bearer ${token}` }
              });
              const allLogs = await response.json(); 
              
              if (allLogs && allLogs.length > 0) {
                  setAllLogsState(allLogs);
                  setChartDataState(generateChartData(allLogs));

                  const localUser = localStorage.getItem('username');
                  if (!localUser || localUser === "[object Object]" || localUser.startsWith('{')) {
                      const currentRole = localStorage.getItem('role') || "";
                      const cleanName = currentRole === "super_admin" ? "admin_boss" : "Analyst User";
                      localStorage.setItem('username', cleanName);
                      setCurrentUser(cleanName);
                  }

                  const total = allLogs.length; 
                  const attacks = allLogs.filter(l => l.status === 'attack' || l.status === 'blocked' || l.status === 'fail').length;
                  const blocked = allLogs.filter(l => l.status === 'blocked').length;
                  const normalCount = total - attacks;

                  setStats({
                      totalLogs: String(total), 
                      normalTraffic: String(normalCount), 
                      activeThreats: attacks,
                      blockedIPs: blocked
                  });

                  const readTimestamps = JSON.parse(localStorage.getItem('read_alerts_timestamps') || '[]');

                  const alerts = allLogs
                      .filter(l => l.status === 'attack' || l.status === 'blocked' || l.status === 'fail')
                      .filter(l => !readTimestamps.includes(l["@timestamp"])) 
                      .slice(-5)
                      .map(l => ({
                          time: l["@timestamp"],
                          ip: l.source_ip,
                          type: l.sub_type && l.sub_type !== "None" ? l.sub_type : "Malicious Behavior",
                          severity: l.status === "blocked" ? "High" : "Medium",
                          status: l.status,
                          timestamp: l["@timestamp"]
                      })).reverse();
                  
                  setRecentAlerts(alerts);
              }
          } catch (error) {
              console.error("Error loading initial metrics:", error);
          }
      };

      fetchInitialData();

      const socket = io('http://localhost:8000', {
          transports: ['polling', 'websocket'], 
          reconnection: true,
          reconnectionAttempts: 5,
          reconnectionDelay: 5000,
      });
      socket.on('connect', () => {
          setIsConnected(true);
          console.log("Connected to AiSentinel Backend via WebSockets ");
      });

      socket.on('disconnect', () => {
          setIsConnected(false);
          console.log("Disconnected from Backend ");
      });

      socket.on('security_update_live', (newLog) => {
          if (!newLog) return;
          
          const isAttack = newLog.status === "attack" || newLog.status === "blocked" || newLog.status === "fail";

          setAllLogsState(prev => {
             const updated = [...prev, newLog];
             setChartDataState(generateChartData(updated));
             return updated;
          });

          setStats(prev => {
              const currentTotal = parseInt(prev.totalLogs) + 1;
              const currentThreats = prev.activeThreats + (isAttack ? 1 : 0);
              const currentBlocked = prev.blockedIPs + (newLog.status === "blocked" ? 1 : 0);
              const currentNormalCount = currentTotal - currentThreats;

              return {
                  totalLogs: String(currentTotal),
                  normalTraffic: String(currentNormalCount),
                  activeThreats: currentThreats,
                  blockedIPs: currentBlocked
              };
          });
          
          if (isAttack) {
              const readTimestamps = JSON.parse(localStorage.getItem('read_alerts_timestamps') || '[]');
              if (!readTimestamps.includes(newLog["@timestamp"])) {
                  setRecentAlerts(prev => [
                      {
                          time: newLog["@timestamp"] || new Date().toLocaleTimeString(),
                          ip: newLog.source_ip,
                          type: newLog.sub_type && newLog.sub_type !== "None" ? newLog.sub_type : "Anomaly Detected",
                          severity: newLog.status === "blocked" ? "High" : "Medium",
                          status: newLog.status,
                          timestamp: newLog["@timestamp"] || new Date().toISOString()
                      },
                      ...prev
                  ].slice(0, 5));
              }
          }
      });

      socket.on('connect_error', (err) => {
          console.error("Socket Connection Error: ", err.message);
      });

      return () => {
          socket.off('security_update_live');
          socket.disconnect();
      };
  }, [isLoggedIn]);

  const particlesInit = useCallback(async (engine) => { 
    await loadFull(engine); 
  }, []);

  useEffect(() => {
    initParticlesEngine(async (engine) => {
      await loadFull(engine);
    }).then(() => {
      setInit(true);
    });
  }, []);

  useEffect(() => {
    if (!isLoggedIn) return;

    let timeout;
    const resetTimer = () => {
      clearTimeout(timeout);
      timeout = setTimeout(() => {
        handleLogout();
        alert("Session expired due to inactivity. Please login again.");
      }, 900000); 
    };

    window.addEventListener('mousemove', resetTimer);
    window.addEventListener('keypress', resetTimer);
    resetTimer();

    return () => {
      window.removeEventListener('mousemove', resetTimer);
      window.removeEventListener('keypress', resetTimer);
      clearTimeout(timeout);
    };
  }, [isLoggedIn]);

  const handleLogout = () => {
    localStorage.clear();
    setIsLoggedIn(false);
    setCurrentUser(null);
    setUserRole("");
    setView('dashboard');
  };

  const handleLoginSuccess = (username, token, role, mustChange) => {
    localStorage.setItem('token', token);
    localStorage.setItem('role', role);
    localStorage.setItem('username', username);
    localStorage.setItem('mustChange', String(mustChange));
    
    setMustChangePwd(Boolean(mustChange));
    setUserRole(role);
    setCurrentUser(username); 
    setIsLoggedIn(true);
  };

  const handleUnbanIP = async (ip) => {
    try {
      const token = localStorage.getItem('token');
      await fetch(`http://localhost:8000/api/firewall/unban`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ ip })
      });
      console.log(`IP ${ip} has been successfully whitelisted/unbanned.`);
    } catch (error) {
      console.error("Error executing manual unban action:", error);
    }
  };

  if (!isLoggedIn) {
    return (
      <div className={darkMode ? "dark" : ""}>
        <LoginPage onLoginSuccess={handleLoginSuccess} particlesInit={particlesInit} />
        <ThemeToggle darkMode={darkMode} setDarkMode={setDarkMode} />
      </div>
    );
  }

  if (mustChangePwd) {
    return (
      <div className={darkMode ? "dark" : ""}>
        <div className="min-h-screen bg-gray-50 dark:bg-[#060a14] transition-colors duration-300">
          <ChangePasswordPage 
            onPasswordChanged={() => {
              setMustChangePwd(false);
              localStorage.setItem('mustChange', 'false');
            }} 
            particlesInit={particlesInit} 
          />
          <ThemeToggle darkMode={darkMode} setDarkMode={setDarkMode} />
        </div>
      </div>
    );
  }

  return (
    <div className={darkMode ? "dark" : ""}>
      <MainLayout 
        particlesInit={init}
        darkMode={darkMode}             
        setDarkMode={setDarkMode}      
        isLoggedIn={isLoggedIn}        
        onNavigate={setView} 
        onLogout={handleLogout}
        currentView={view}
        user={currentUser}
        userRole={userRole}
        recentAlerts={recentAlerts}
        onNavigateToAlerts={(actionOrDate) => {
          if (actionOrDate === 'clear_all') {
            const attackTimestamps = allLogsState
              .filter(l => l.status === 'attack' || l.status === 'blocked' || l.status === 'fail')
              .map(l => l["@timestamp"])
              .filter(Boolean); 

            const oldSaved = JSON.parse(localStorage.getItem('read_alerts_timestamps') || '[]');

            const updatedTimestamps = Array.from(new Set([...oldSaved, ...attackTimestamps]));

            localStorage.setItem('read_alerts_timestamps', JSON.stringify(updatedTimestamps));
            setRecentAlerts([]);
          } else {
            setAlertInitialDate(actionOrDate);
            setView('all-alerts');
          }
        }} >
          {view === 'dashboard' && (
            <Dashboard 
              stats={stats} 
              recentAlerts={recentAlerts} 
              onUnbanIP={handleUnbanIP} 
            />
          )}
          {view === 'hub' && (
            <DetectionHub 
              recentAlerts={recentAlerts} 
              onNavigate={setView} 
              onBack={() => setView('dashboard')} 
              isConnected={isConnected}
            />
          )}
          {view === 'all-alerts' && (
            <AllAlertsPage onBack={() => setView('hub')} allLogs={allLogsState} chartData={chartDataState} />
          )}
          {view === 'static' && (
            <StaticEnginePage onBack={() => setView('hub')} allLogs={allLogsState} />
          )}
          {view === 'threat' && (
            <ThreatDetectionPage onBack={() => setView('hub')} allLogs={allLogsState} />
          )}
          {view === 'anomaly' && (
            <AnomalyDetectionPage onBack={() => setView('hub')} allLogs={allLogsState} />
          )}
          {view === 'analyzer' && (
            <LogAnalyzer 
              onBack={() => setView('dashboard')} 
              file={analyzerFile}
              setFile={setAnalyzerFile}
              loading={analyzerLoading}
              setLoading={setAnalyzerLoading}
              analytics={analyzerResult}
              setAnalytics={setAnalyzerResult}
            />
          )}
          {view === 'archive' && <LogsHistory onBack={() => setView('dashboard')} />}
          {view === 'users' && <UserManagement onBack={() => setView('dashboard')} />}
      </MainLayout>
    </div>
  );
}

export default App;
