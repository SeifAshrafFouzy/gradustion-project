import os
import re
import json
import urllib.parse
from pathlib import Path
from core.redis_client import redis_client as r
from typing import Dict, List
from collections import defaultdict
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


from functools import lru_cache

@lru_cache(maxsize=1)
def get_cached_config():
    return load_dynamic_config()


# =========================================================
# DYNAMIC CONFIGURATION LOADER (Tuning System)
# =========================================================
BASE_DIR = Path(__file__).resolve().parent.parent
CONFIG_PATH = BASE_DIR / "api" / "config.json"

def load_dynamic_config() -> dict:
    default_config = {
        "rate_limiting": {
            "enabled": True,
            "max_requests_per_window": 100,
            "window_seconds": 60
        },
        "static_engine": {
            "paranoia_level": 2,
            "block_on_regex_match": True
        }
    }
    
    if CONFIG_PATH.exists():
        try:
            with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                config_data = json.load(f)
                logger.info(f"Successfully loaded dynamic WAF configuration from {CONFIG_PATH}")
                return config_data
        except Exception as e:
            logger.error(f"Error parsing config.json: {e}. Using safe defaults.")
    else:
        logger.warning(f"config.json not found at {CONFIG_PATH}. Using fallback defaults.")
        
    return default_config

WAF_CONFIG = load_dynamic_config()

# =========================================================
# STATIC CONFIGS
# =========================================================
ATTACK_WEIGHTS = {
    "SQL_INJECTION": 5,
    "XSS": 5,
    "COMMAND_INJECTION": 5,
    "LFI_RFI": 4,
    "BRUTE_FORCE": 4,
    "SCANNING": 2,
    "DOS": 5,
    "RCE": 6,
    "OTHER": 1
}

THRESHOLD = 8
MIN_MATCHES =2

DOS_THRESHOLD = WAF_CONFIG["rate_limiting"]["max_requests_per_window"]
DOS_WINDOW = WAF_CONFIG["rate_limiting"]["window_seconds"]

BRUTE_FORCE_THRESHOLD = WAF_CONFIG["rate_limiting"]["max_requests_per_window"]
BRUTE_FORCE_WINDOW = WAF_CONFIG["rate_limiting"]["window_seconds"]

# =========================================================
# SMART WHITELIST
# =========================================================
def is_whitelisted(data: dict) -> bool:
    url_path = data.get("request_url", "").split("?")[0].strip().lower()
    ip = data.get("source_ip", "unknown")

    static_patterns = [
        r'\.js$', r'\.css$', r'\.png$', r'\.jpg$', r'\.jpeg$'
    ]
    for p in static_patterns:
        if re.search(p, url_path, re.IGNORECASE):
            return True

    if r:
        try:
            if r.sismember("whitelist_ips", ip):
                return True
            if r.sismember("whitelist_urls", url_path):
                return True
        except Exception as e:
            logger.error(f"Whitelist Redis Error: {e}")

    return False

# =========================================================
# HELPERS
# =========================================================
def get_attack_type(rule_id: str):
    if rule_id.startswith("942"):
        return "SQL_INJECTION"
    elif rule_id.startswith("941"):
        return "XSS"
    elif rule_id.startswith("932"):
        return "COMMAND_INJECTION"
    elif rule_id.startswith("930"):
        return "LFI_RFI"
    elif rule_id.startswith("913"):
        return "SCANNING"
    return "OTHER"

def normalize_input(data):
    if isinstance(data, dict):
        raw = f"{data.get('request_url','')} {data.get('query_params','')} {data.get('body','')}"
    else:
        raw = str(data)

    decoded = urllib.parse.unquote(raw)
    decoded = urllib.parse.unquote(decoded)
    return decoded.lower()

# =========================================================
# RULE CLASS
# =========================================================
class CRSRule:
    def __init__(self, rule_id: str, file_name: str):
        self.id = rule_id
        self.file = file_name
        self.pattern = None

    def add_line(self, line: str):
        if '@rx' in line:
            try:
                pattern_part = line.split('@rx', 1)[1].strip()

                if pattern_part.startswith('"'):
                    pattern_part = pattern_part[1:]
                if '"' in pattern_part:
                    pattern_part = pattern_part.split('"')[0]

                pattern_part = pattern_part.strip()
                self.pattern = re.compile(pattern_part, re.IGNORECASE)
            except Exception as e:
                pass  

# =========================================================
# PARSER + INDEXING
# =========================================================
class CRSParser:
    def __init__(self, rules_dir: str):
        self.rules_dir = Path(rules_dir)
        self.rules: Dict[str, CRSRule] = {}
        self.keyword_index = defaultdict(list)

    def parse_all(self):
        if not self.rules_dir.exists():
            logger.error("Rules folder not found")
            return {}

        for file in self.rules_dir.rglob("*.conf"):
            self._parse_file(file)

        logger.info(f"Loaded {len(self.rules)} CRS Core Rules successfully.")
        return self.rules

    def _extract_keywords(self, pattern: str):
        words = re.findall(r'[a-zA-Z]{3,}', pattern)
        return words[:5]

    def _parse_file(self, file_path: Path):
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()

        blocks = re.split(r'(?=SecRule\s+)', content)

        for block in blocks:
            id_match = re.search(r'id:(\d+)', block)
            if not id_match:
                continue

            rule_id = id_match.group(1)
            rule = CRSRule(rule_id, file_path.name)

            for line in block.split('\n'):
                rule.add_line(line)

            self.rules[rule_id] = rule

            if rule.pattern:
                keywords = self._extract_keywords(rule.pattern.pattern)
                for kw in keywords:
                    self.keyword_index[kw.lower()].append(rule)

# =========================================================
# CONTEXT FILTER (SMART)
# =========================================================
SUSPICIOUS_PATTERNS = [
    r"(union\s+select)",
    r"(select\s+.+\s+from)",
    r"(\bor\b\s+1=1)",
    r"(information_schema)",
    r"(<script.*?>)",
    r"(javascript:)",
    r"(onerror=|onload=)",
    r"(\.\./|\.\.\\)",
    r"(/etc/passwd)",
    r"(boot\.ini)",
    r"(;|\|\||&&)\s*(ls|cat|whoami|id|bash|sh)",
    r"(bash\s+-i|nc\s+-e|python\s+-c|perl\s+-e|powershell)",
    r"(nmap|sqlmap|nikto|dirbuster)",
    r"(login|signin|password)",
    r"(sleep\(\d+\))",
    r"(benchmark\()"
]

COMPILED_PATTERNS = [re.compile(p, re.IGNORECASE) for p in SUSPICIOUS_PATTERNS]

# =========================================================
# DETECTOR (Optimized)
# =========================================================
class AttackDetector:
    def __init__(self, parser: CRSParser):
        self.parser = parser
        self.rules = list(parser.rules.values())

    def _get_candidate_rules(self, text):
        words = set(re.findall(r'\w+', text))
        candidates = set()
        for w in words:
            if w in self.parser.keyword_index:
                candidates.update(self.parser.keyword_index[w])
        return candidates if candidates else self.rules

    def detect(self, data):
        global DOS_THRESHOLD, DOS_WINDOW
        current_config = get_cached_config()
        DOS_THRESHOLD = current_config["rate_limiting"]["max_requests_per_window"]
        DOS_WINDOW = current_config["rate_limiting"]["window_seconds"]

        decoded = normalize_input(data)
        ip = data.get("source_ip", "unknown")
        
        logger.info(f"Decoded request: {decoded}")

        # 1. Whitelist Check
        if is_whitelisted(data):
            return {"status": "normal", "reason": "whitelisted"}
        
        # 2. OVERRIDE DETECTION
        if "../" in decoded or "/etc/passwd" in decoded:
            return {
                "status": "attack",
                "score": 7,
                "matches": ["LFI"],
                "top_attack": "LFI_RFI",
                "severity": "High"
            }

        if re.search(r"(;|\|\||&&)\s*(ls|cat|whoami|id|bash|sh)", decoded):
            return {
                "status": "attack",
                "score": 7,
                "matches": ["CMD"],
                "top_attack": "COMMAND_INJECTION",
                "severity": "High"
            }
        
        if re.search(r"(bash\s+-i|nc\s+-e|python\s+-c|perl\s+-e|powershell)", decoded):
            return {
                "status": "attack",
                "score": 8,
                "matches": ["RCE"],
                "top_attack": "REMOTE_CODE_EXECUTION",
                "severity": "Critical"
            }

        if "nmap" in decoded or "sqlmap" in decoded or "nikto" in decoded:
            return {
                "status": "attack",
                "score": 6,
                "matches": ["SCAN"],
                "top_attack": "SCANNING",
                "severity": "High"
            }

        # 3. Brute Force Engine via Redis
        if r and ("login" in decoded or "password" in decoded):
            key = f"bf:{ip}"
            count = r.incr(key)
            r.expire(key, BRUTE_FORCE_WINDOW)

            if count > BRUTE_FORCE_THRESHOLD:
                return {
                    "status": "attack",
                    "score": ATTACK_WEIGHTS["BRUTE_FORCE"],
                    "matches": ["BRUTE_FORCE"],
                    "top_attack": "BRUTE_FORCE",
                    "severity": "High"
                }

        # 4. Smart DoS Engine via Redis (Uses Dynamic Config thresholds)
        if r and current_config["rate_limiting"]["enabled"]:
            key = f"dos:{ip}"
            count = r.incr(key)
            r.expire(key, DOS_WINDOW)

            if count > DOS_THRESHOLD:
                return {
                    "status": "attack",
                    "score": ATTACK_WEIGHTS["DOS"],
                    "matches": ["DOS Flooding"],
                    "top_attack": "DOS",
                    "severity": "Critical",
                    "reason": f"Rate limit exceeded: {count}/{DOS_THRESHOLD} requests"
                }
        
        # 5. Context Filter 
        if not any(p.search(decoded) for p in COMPILED_PATTERNS):
            return {"status": "normal", "reason": "no suspicious patterns"}

        candidates = self._get_candidate_rules(decoded)
        
        # Scoring System
        score = 0
        matches = []
        attack_scores = defaultdict(int)

        for rule in candidates:
            if not rule.pattern:
                continue

            try:
                if rule.pattern.search(decoded):
                    attack_type = get_attack_type(rule.id)
                    weight = ATTACK_WEIGHTS.get(attack_type, 1)

                    score += weight
                    matches.append(rule.id)
                    attack_scores[attack_type] += weight
            except:
                continue

        if score < THRESHOLD and len(matches) < MIN_MATCHES:
            return {
                "status": "normal",
                "score": score,
                "matches": matches
            }

        # Severity Assessment
        if len(matches) == 1 and score >= 5:
            severity = "High"
        else:
            if score >= 10:
                severity = "Critical"
            elif score >= 6:
                severity = "High"
            elif score >= 3:
                severity = "Medium"
            else:
                severity = "Low"

        top_attack = max(attack_scores, key=attack_scores.get) if attack_scores else "Unknown"

        xss_type = None
        if re.search(r"<script.*?>", decoded):
            xss_type = "Reflected XSS"
        elif "onerror=" in decoded or "onload=" in decoded:
            xss_type = "Event-based XSS"
        elif "javascript:" in decoded:
            xss_type = "DOM XSS"

        return {
            "status": "attack",
            "score": score,
            "matches": matches,
            "top_attack": top_attack,
            "details": dict(attack_scores),
            "severity": severity,
            "sub_type": xss_type if top_attack == "XSS" else top_attack
        }

# =========================================================
# SINGLETON INSTANTIATION
# =========================================================
_detector_instance = None

def get_static_detector():
    global _detector_instance
    if _detector_instance is None:
        current_dir = os.path.dirname(os.path.abspath(__file__))
        rules_path = os.path.join(current_dir, 'coreruleset')

        logger.info(f"Initializing Static Engine CRS Rules from: {rules_path}")

        parser = CRSParser(rules_path)
        parser.parse_all()

        _detector_instance = AttackDetector(parser)

    return _detector_instance

# =========================================================
# MIDDLEWARE ENTRYPOINT
# =========================================================
def check_log_static(log_entry):
    detector = get_static_detector()
    result = detector.detect(log_entry)

    if result["status"] == "attack":
        return True, result, result["severity"]

    return False, result, "Low"




# ========================دى النسخة اللى كانت شغالة أغلب ال testiing=======================================
# import os
# import re
# import json
# import urllib.parse
# from pathlib import Path
# from core.redis_client import redis_client as r
# from typing import Dict, List
# from collections import defaultdict
# import logging

# logging.basicConfig(level=logging.INFO)
# logger = logging.getLogger(__name__)

# # =========================================================
# # DYNAMIC CONFIGURATION LOADER (Tuning System)
# # =========================================================
# BASE_DIR = Path(__file__).resolve().parent.parent
# CONFIG_PATH = BASE_DIR / "api" / "config.json"

# def load_dynamic_config() -> dict:
#     default_config = {
#         "rate_limiting": {
#             "enabled": True,
#             "max_requests_per_window": 100,
#             "window_seconds": 60
#         },
#         "static_engine": {
#             "paranoia_level": 2,
#             "block_on_regex_match": True
#         }
#     }
    
#     if CONFIG_PATH.exists():
#         try:
#             with open(CONFIG_PATH, "r", encoding="utf-8") as f:
#                 config_data = json.load(f)
#                 logger.info(f"Successfully loaded dynamic WAF configuration from {CONFIG_PATH}")
#                 return config_data
#         except Exception as e:
#             logger.error(f"Error parsing config.json: {e}. Using safe defaults.")
#     else:
#         logger.warning(f"config.json not found at {CONFIG_PATH}. Using fallback defaults.")
        
#     return default_config

# WAF_CONFIG = load_dynamic_config()

# # =========================================================
# # STATIC CONFIGS
# # =========================================================
# ATTACK_WEIGHTS = {
#     "SQL_INJECTION": 5,
#     "XSS": 5,
#     "COMMAND_INJECTION": 5,
#     "LFI_RFI": 4,
#     "BRUTE_FORCE": 4,
#     "SCANNING": 2,
#     "DOS": 5,
#     "RCE": 6,
#     "OTHER": 1
# }

# THRESHOLD = 4
# MIN_MATCHES = 1

# DOS_THRESHOLD = WAF_CONFIG["rate_limiting"]["max_requests_per_window"]
# DOS_WINDOW = WAF_CONFIG["rate_limiting"]["window_seconds"]

# BRUTE_FORCE_THRESHOLD = 10
# BRUTE_FORCE_WINDOW = 60

# # =========================================================
# # SMART WHITELIST
# # =========================================================
# def is_whitelisted(data: dict) -> bool:
#     url_path = data.get("request_url", "").split("?")[0].strip().lower()
#     ip = data.get("source_ip", "unknown")

#     static_patterns = [
#         r'\.js$', r'\.css$', r'\.png$', r'\.jpg$', r'\.jpeg$'
#     ]
#     for p in static_patterns:
#         if re.search(p, url_path, re.IGNORECASE):
#             return True

#     if r:
#         try:
#             if r.sismember("whitelist_ips", ip):
#                 return True
#             if r.sismember("whitelist_urls", url_path):
#                 return True
#         except Exception as e:
#             logger.error(f"Whitelist Redis Error: {e}")

#     return False

# # =========================================================
# # HELPERS
# # =========================================================
# def get_attack_type(rule_id: str):
#     if rule_id.startswith("942"):
#         return "SQL_INJECTION"
#     elif rule_id.startswith("941"):
#         return "XSS"
#     elif rule_id.startswith("932"):
#         return "COMMAND_INJECTION"
#     elif rule_id.startswith("930"):
#         return "LFI_RFI"
#     elif rule_id.startswith("913"):
#         return "SCANNING"
#     return "OTHER"

# def normalize_input(data):
#     if isinstance(data, dict):
#         raw = f"{data.get('request_url','')} {data.get('query_params','')} {data.get('body','')}"
#     else:
#         raw = str(data)

#     decoded = urllib.parse.unquote(raw)
#     decoded = urllib.parse.unquote(decoded)
#     return decoded.lower()

# # =========================================================
# # RULE CLASS
# # =========================================================
# class CRSRule:
#     def __init__(self, rule_id: str, file_name: str):
#         self.id = rule_id
#         self.file = file_name
#         self.pattern = None

#     def add_line(self, line: str):
#         if '@rx' in line:
#             try:
#                 pattern_part = line.split('@rx', 1)[1].strip()

#                 if pattern_part.startswith('"'):
#                     pattern_part = pattern_part[1:]
#                 if '"' in pattern_part:
#                     pattern_part = pattern_part.split('"')[0]

#                 pattern_part = pattern_part.strip()
#                 self.pattern = re.compile(pattern_part, re.IGNORECASE)
#             except Exception as e:
#                 pass  

# # =========================================================
# # PARSER + INDEXING
# # =========================================================
# class CRSParser:
#     def __init__(self, rules_dir: str):
#         self.rules_dir = Path(rules_dir)
#         self.rules: Dict[str, CRSRule] = {}
#         self.keyword_index = defaultdict(list)

#     def parse_all(self):
#         if not self.rules_dir.exists():
#             logger.error("Rules folder not found")
#             return {}

#         for file in self.rules_dir.rglob("*.conf"):
#             self._parse_file(file)

#         logger.info(f"Loaded {len(self.rules)} CRS Core Rules successfully.")
#         return self.rules

#     def _extract_keywords(self, pattern: str):
#         words = re.findall(r'[a-zA-Z]{3,}', pattern)
#         return words[:5]

#     def _parse_file(self, file_path: Path):
#         with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
#             content = f.read()

#         blocks = re.split(r'(?=SecRule\s+)', content)

#         for block in blocks:
#             id_match = re.search(r'id:(\d+)', block)
#             if not id_match:
#                 continue

#             rule_id = id_match.group(1)
#             rule = CRSRule(rule_id, file_path.name)

#             for line in block.split('\n'):
#                 rule.add_line(line)

#             self.rules[rule_id] = rule

#             if rule.pattern:
#                 keywords = self._extract_keywords(rule.pattern.pattern)
#                 for kw in keywords:
#                     self.keyword_index[kw.lower()].append(rule)

# # =========================================================
# # CONTEXT FILTER (SMART)
# # =========================================================
# SUSPICIOUS_PATTERNS = [
#     r"(union\s+select)",
#     r"(select\s+.+\s+from)",
#     r"(\bor\b\s+1=1)",
#     r"(information_schema)",
#     r"(<script.*?>)",
#     r"(javascript:)",
#     r"(onerror=|onload=)",
#     r"(\.\./|\.\.\\)",
#     r"(/etc/passwd)",
#     r"(boot\.ini)",
#     r"(;|\|\||&&)\s*(ls|cat|whoami|id|bash|sh)",
#     r"(bash\s+-i|nc\s+-e|python\s+-c|perl\s+-e|powershell)",
#     r"(nmap|sqlmap|nikto|dirbuster)",
#     r"(login|signin|password)",
#     r"(sleep\(\d+\))",
#     r"(benchmark\()"
# ]

# COMPILED_PATTERNS = [re.compile(p, re.IGNORECASE) for p in SUSPICIOUS_PATTERNS]

# # =========================================================
# # DETECTOR (Optimized)
# # =========================================================
# class AttackDetector:
#     def __init__(self, parser: CRSParser):
#         self.parser = parser
#         self.rules = list(parser.rules.values())

#     def _get_candidate_rules(self, text):
#         words = set(re.findall(r'\w+', text))
#         candidates = set()
#         for w in words:
#             if w in self.parser.keyword_index:
#                 candidates.update(self.parser.keyword_index[w])
#         return candidates if candidates else self.rules

#     def detect(self, data):
#         global DOS_THRESHOLD, DOS_WINDOW
#         current_config = load_dynamic_config()
#         DOS_THRESHOLD = current_config["rate_limiting"]["max_requests_per_window"]
#         DOS_WINDOW = current_config["rate_limiting"]["window_seconds"]

#         decoded = normalize_input(data)
#         ip = data.get("source_ip", "unknown")
        
#         logger.info(f"Decoded request: {decoded}")

#         # 1. Whitelist Check
#         if is_whitelisted(data):
#             return {"status": "normal", "reason": "whitelisted"}
        
#         # 2. OVERRIDE DETECTION
#         if "../" in decoded or "/etc/passwd" in decoded:
#             return {
#                 "status": "attack",
#                 "score": 7,
#                 "matches": ["LFI"],
#                 "top_attack": "LFI_RFI",
#                 "severity": "High"
#             }

#         if re.search(r"(;|\|\||&&)\s*(ls|cat|whoami|id|bash|sh)", decoded):
#             return {
#                 "status": "attack",
#                 "score": 7,
#                 "matches": ["CMD"],
#                 "top_attack": "COMMAND_INJECTION",
#                 "severity": "High"
#             }
        
#         if re.search(r"(bash\s+-i|nc\s+-e|python\s+-c|perl\s+-e|powershell)", decoded):
#             return {
#                 "status": "attack",
#                 "score": 8,
#                 "matches": ["RCE"],
#                 "top_attack": "REMOTE_CODE_EXECUTION",
#                 "severity": "Critical"
#             }

#         if "nmap" in decoded or "sqlmap" in decoded or "nikto" in decoded:
#             return {
#                 "status": "attack",
#                 "score": 6,
#                 "matches": ["SCAN"],
#                 "top_attack": "SCANNING",
#                 "severity": "High"
#             }

#         # 3. Brute Force Engine via Redis
#         if r and ("login" in decoded or "password" in decoded):
#             key = f"bf:{ip}"
#             count = r.incr(key)
#             r.expire(key, BRUTE_FORCE_WINDOW)

#             if count > BRUTE_FORCE_THRESHOLD:
#                 return {
#                     "status": "attack",
#                     "score": ATTACK_WEIGHTS["BRUTE_FORCE"],
#                     "matches": ["BRUTE_FORCE"],
#                     "top_attack": "BRUTE_FORCE",
#                     "severity": "High"
#                 }

#         # 4. Smart DoS Engine via Redis (Uses Dynamic Config thresholds)
#         if r and current_config["rate_limiting"]["enabled"]:
#             key = f"dos:{ip}"
#             count = r.incr(key)
#             r.expire(key, DOS_WINDOW)

#             if count > DOS_THRESHOLD:
#                 return {
#                     "status": "attack",
#                     "score": ATTACK_WEIGHTS["DOS"],
#                     "matches": ["DOS Flooding"],
#                     "top_attack": "DOS",
#                     "severity": "Critical",
#                     "reason": f"Rate limit exceeded: {count}/{DOS_THRESHOLD} requests"
#                 }
        
#         # 5. Context Filter 
#         if not any(p.search(decoded) for p in COMPILED_PATTERNS):
#             return {"status": "normal", "reason": "no suspicious patterns"}

#         candidates = self._get_candidate_rules(decoded)
        
#         # Scoring System
#         score = 0
#         matches = []
#         attack_scores = defaultdict(int)

#         for rule in candidates:
#             if not rule.pattern:
#                 continue

#             try:
#                 if rule.pattern.search(decoded):
#                     attack_type = get_attack_type(rule.id)
#                     weight = ATTACK_WEIGHTS.get(attack_type, 1)

#                     score += weight
#                     matches.append(rule.id)
#                     attack_scores[attack_type] += weight
#             except:
#                 continue

#         if score < THRESHOLD and len(matches) < MIN_MATCHES:
#             return {
#                 "status": "normal",
#                 "score": score,
#                 "matches": matches
#             }

#         # Severity Assessment
#         if len(matches) == 1 and score >= 5:
#             severity = "High"
#         else:
#             if score >= 10:
#                 severity = "Critical"
#             elif score >= 6:
#                 severity = "High"
#             elif score >= 3:
#                 severity = "Medium"
#             else:
#                 severity = "Low"

#         top_attack = max(attack_scores, key=attack_scores.get) if attack_scores else "Unknown"

#         xss_type = None
#         if re.search(r"<script.*?>", decoded):
#             xss_type = "Reflected XSS"
#         elif "onerror=" in decoded or "onload=" in decoded:
#             xss_type = "Event-based XSS"
#         elif "javascript:" in decoded:
#             xss_type = "DOM XSS"

#         return {
#             "status": "attack",
#             "score": score,
#             "matches": matches,
#             "top_attack": top_attack,
#             "details": dict(attack_scores),
#             "severity": severity,
#             "sub_type": xss_type if top_attack == "XSS" else top_attack
#         }

# # =========================================================
# # SINGLETON INSTANTIATION
# # =========================================================
# _detector_instance = None

# def get_static_detector():
#     global _detector_instance
#     if _detector_instance is None:
#         current_dir = os.path.dirname(os.path.abspath(__file__))
#         rules_path = os.path.join(current_dir, 'coreruleset')

#         logger.info(f"Initializing Static Engine CRS Rules from: {rules_path}")

#         parser = CRSParser(rules_path)
#         parser.parse_all()

#         _detector_instance = AttackDetector(parser)

#     return _detector_instance

# # =========================================================
# # MIDDLEWARE ENTRYPOINT
# # =========================================================
# def check_log_static(log_entry):
#     detector = get_static_detector()
#     result = detector.detect(log_entry)

#     if result["status"] == "attack":
#         return True, result, result["severity"]

#     return False, result, "Low"




# ==============================================
# import os
# import re
# import json
# import urllib.parse
# from pathlib import Path
# from core.redis_client import redis_client as r
# from typing import Dict, List
# from collections import defaultdict
# import logging

# logging.basicConfig(level=logging.INFO)
# logger = logging.getLogger(__name__)


# # =========================================================
# # CONFIG
# # =========================================================

# ATTACK_WEIGHTS = {
#     "SQL_INJECTION": 5,
#     "XSS": 5,
#     "COMMAND_INJECTION": 5,
#     "LFI_RFI": 4,
#     "BRUTE_FORCE": 4,
#     "SCANNING": 2,
#     "DOS": 5,
#     "RCE": 6,
#     "OTHER": 1
# }

# THRESHOLD = 4
# MIN_MATCHES = 1

# # WHITELIST = [
# #     r'\.js$', r'\.css$', r'\.png$', r'\.jpg$', r'\.jpeg$',
# #     r'googlebot', r'bingbot', r'Mozilla/5\.0'
# # ]
# # =========================================================
# # SMART WHITELIST
# # =========================================================
# def is_whitelisted(data: dict) -> bool:
#     url_path = data.get("request_url", "").split("?")[0].strip().lower()
#     ip = data.get("source_ip", "unknown")

#     static_patterns = [
#         r'\.js$', r'\.css$', r'\.png$', r'\.jpg$', r'\.jpeg$'
#     ]
#     for p in static_patterns:
#         if re.search(p, url_path, re.IGNORECASE):
#             return True

#     if r:
#         try:
#             if r.sismember("whitelist_ips", ip):
#                 return True
#             if r.sismember("whitelist_urls", url_path):
#                 return True
#         except Exception as e:
#             logger.error(f"Whitelist Redis Error: {e}")

#     return False

# # def is_whitelisted(decoded, ip):
# #     # static
# #     static_patterns = [
# #         r'\.js$', r'\.css$', r'\.png$', r'\.jpg$', r'\.jpeg$'
# #     ]

# #     for p in static_patterns:
# #         if re.search(p, decoded, re.IGNORECASE):
# #             return True

# #     # dynamic
# #     if r:
# #         try:
# #             if r.sismember("whitelist_ips", ip):
# #                 return True
# #             if r.sismember("whitelist_urls", decoded):
# #                 return True
# #         except Exception as e:
# #             logger.error(f"Whitelist Redis Error: {e}")

# #     return False

# # =========================================================
# # THRESHOLDS
# # =========================================================
# DOS_THRESHOLD = 50     # عدد الريكوستات
# DOS_WINDOW = 10        # بالثواني

# BRUTE_FORCE_THRESHOLD = 10
# BRUTE_FORCE_WINDOW = 60
# # =========================================================
# # HELPERS
# # =========================================================

# def get_attack_type(rule_id: str):
#     if rule_id.startswith("942"):
#         return "SQL_INJECTION"
#     elif rule_id.startswith("941"):
#         return "XSS"
#     elif rule_id.startswith("932"):
#         return "COMMAND_INJECTION"
#     elif rule_id.startswith("930"):
#         return "LFI_RFI"
#     elif rule_id.startswith("913"):
#         return "SCANNING"
#     return "OTHER"


# # def is_whitelisted(text: str):
# #     for pattern in WHITELIST:
# #         if re.search(pattern, text, re.IGNORECASE):
# #             return True
# #     return False


# def normalize_input(data):
#     if isinstance(data, dict):
#         raw = f"{data.get('request_url','')} {data.get('query_params','')} {data.get('body','')}"
#     else:
#         raw = str(data)

#     decoded = urllib.parse.unquote(raw)
#     decoded = urllib.parse.unquote(decoded)
#     return decoded.lower()

# # =========================================================
# # RULE CLASS
# # =========================================================

# class CRSRule:
#     def __init__(self, rule_id: str, file_name: str):
#         self.id = rule_id
#         self.file = file_name
#         self.pattern = None

#     def add_line(self, line: str):
#         if '@rx' in line:
#             try:
#                 # خد كل اللي بعد @rx
#                 pattern_part = line.split('@rx', 1)[1].strip()

#                 # شيل quotes لو موجودة
#                 if pattern_part.startswith('"'):
#                     pattern_part = pattern_part[1:]
#                 if '"' in pattern_part:
#                     pattern_part = pattern_part.split('"')[0]

#                 # تنظيف
#                 pattern_part = pattern_part.strip()

#                 # compile
#                 self.pattern = re.compile(pattern_part, re.IGNORECASE)

#             except Exception as e:
#                 print(f"Regex error in rule {self.id}: {e}")

# # =========================================================
# # PARSER + INDEXING
# # =========================================================

# class CRSParser:
#     def __init__(self, rules_dir: str):
#         self.rules_dir = Path(rules_dir)
#         self.rules: Dict[str, CRSRule] = {}
#         self.keyword_index = defaultdict(list)

#     def parse_all(self):
#         if not self.rules_dir.exists():
#             logger.error("Rules folder not found")
#             return {}

#         for file in self.rules_dir.rglob("*.conf"):
#             self._parse_file(file)

#         logger.info(f"Loaded {len(self.rules)} rules")

#         print("Rules with pattern:",
#           sum(1 for r in self.rules.values() if r.pattern))
        
#         return self.rules

#     def _extract_keywords(self, pattern: str):
#         # words = re.findall(r'[a-zA-Z]{4,}', pattern)
#         words = re.findall(r'[a-zA-Z]{3,}', pattern)
#         return words[:5]

#     def _parse_file(self, file_path: Path):
#         with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
#             content = f.read()

#         blocks = re.split(r'(?=SecRule\s+)', content)

#         for block in blocks:
#             id_match = re.search(r'id:(\d+)', block)
#             if not id_match:
#                 continue

#             rule_id = id_match.group(1)
#             rule = CRSRule(rule_id, file_path.name)

#             for line in block.split('\n'):
#                 rule.add_line(line)

#             self.rules[rule_id] = rule

#             # Indexing
#             if rule.pattern:
#                 keywords = self._extract_keywords(rule.pattern.pattern)
#                 for kw in keywords:
#                     self.keyword_index[kw.lower()].append(rule)

# # =========================================================
# # CONTEXT FILTER (SMART)
# # =========================================================

# SUSPICIOUS_PATTERNS = [
#     # SQLi
#     r"(union\s+select)",
#     r"(select\s+.+\s+from)",
#     r"(\bor\b\s+1=1)",
#     r"(information_schema)",
#     # XSS
#     r"(<script.*?>)",
#     r"(javascript:)",
#     r"(onerror=|onload=)",
#     # LFI
#     r"(\.\./|\.\.\\)",
#     r"(/etc/passwd)",
#     r"(boot\.ini)",
#     # Command Injection / RCE
#     r"(;|\|\||&&)\s*(ls|cat|whoami|id|bash|sh)",
#     r"(bash\s+-i|nc\s+-e|python\s+-c|perl\s+-e|powershell)",
#     #Scanning
#     r"(nmap|sqlmap|nikto|dirbuster)",
#     # Brute Force
#     r"(login|signin|password)",
#     # DoS
#     r"(sleep\(\d+\))",
#     r"(benchmark\()"
# ]

# COMPILED_PATTERNS = [
#     re.compile(p, re.IGNORECASE) for p in SUSPICIOUS_PATTERNS
# ]

# # =========================================================
# # DETECTOR (Optimized)
# # =========================================================

# class AttackDetector:
#     def __init__(self, parser: CRSParser):
#         self.parser = parser
#         self.rules = list(parser.rules.values())

#     def _get_candidate_rules(self, text):
#         words = set(re.findall(r'\w+', text))
#         candidates = set()

#         for w in words:
#             if w in self.parser.keyword_index:
#                 candidates.update(self.parser.keyword_index[w])

#         return candidates if candidates else self.rules

#     def detect(self, data):

#         decoded = normalize_input(data)
#         ip = data.get("source_ip", "unknown")
        
#         logger.info(f"Decoded request: {decoded}")

#         # 1. Whitelist
#         if is_whitelisted(data):
#             return {"status": "normal", "reason": "whitelisted"}
#         # if is_whitelisted(decoded, ip):
#         #     return {"status": "normal", "reason": "whitelisted"}
        
#         # =========================================================
#         # 2. OVERRIDE DETECTION 
#         # =========================================================

#         # --- LFI ---
#         if "../" in decoded or "/etc/passwd" in decoded:
#             return {
#                 "status": "attack",
#                 "score": 7,
#                 "matches": ["LFI"],
#                 "top_attack": "LFI_RFI",
#                 "severity": "High"
#             }

#         # --- Command Injection ---
#         if re.search(r"(;|\|\||&&)\s*(ls|cat|whoami|id|bash|sh)", decoded):
#             return {
#                 "status": "attack",
#                 "score": 7,
#                 "matches": ["CMD"],
#                 "top_attack": "COMMAND_INJECTION",
#                 "severity": "High"
#             }
        
#         # --- RCE ---
#         if re.search(r"(bash\s+-i|nc\s+-e|python\s+-c|perl\s+-e|powershell)", decoded):
#             return {
#                 "status": "attack",
#                 "score": 8,
#                 "matches": ["RCE"],
#                 "top_attack": "REMOTE_CODE_EXECUTION",
#                 "severity": "Critical"
#             }

#         # --- Scanning ---
#         if "nmap" in decoded or "sqlmap" in decoded or "nikto" in decoded:
#             return {
#                 "status": "attack",
#                 "score": 6,
#                 "matches": ["SCAN"],
#                 "top_attack": "SCANNING",
#                 "severity": "High"
#             }

#         # 3. Brute Force
#         if r and ("login" in decoded or "password" in decoded):
#             key = f"bf:{ip}"
#             count = r.incr(key)
#             r.expire(key, BRUTE_FORCE_WINDOW)

#             if count > BRUTE_FORCE_THRESHOLD:
#                 return {
#                     "status": "attack",
#                     "score": ATTACK_WEIGHTS["BRUTE_FORCE"],
#                     "matches": ["BRUTE_FORCE"],
#                     "top_attack": "BRUTE_FORCE",
#                     "severity": "High"
#                 }


#         # 4. DoS
#         if r:
#             key = f"dos:{ip}"
#             count = r.incr(key)
#             r.expire(key, DOS_WINDOW)

#             if count > DOS_THRESHOLD:
#                 return {
#                     "status": "attack",
#                     "score": ATTACK_WEIGHTS["DOS"],
#                     "matches": ["DOS"],
#                     "top_attack": "DOS",
#                     "severity": "Critical"
#                 }
        
#         # 3. Context Filter 
#         if not any(p.search(decoded) for p in COMPILED_PATTERNS):
#             return {"status": "normal", "reason": "no suspicious patterns"}

#         candidates = self._get_candidate_rules(decoded)
#         # =============================
#         # Basic scoring
#         # =============================
#         score = 0
#         matches = []
#         attack_scores = defaultdict(int)

#         for rule in candidates:
#             if not rule.pattern:
#                 continue

#             try:
#                 if rule.pattern.search(decoded):
#                     attack_type = get_attack_type(rule.id)
#                     weight = ATTACK_WEIGHTS.get(attack_type, 1)

#                     score += weight
#                     matches.append(rule.id)
#                     attack_scores[attack_type] += weight
#             except:
#                 continue

#         # Threshold + minimum matches
#             # Threshold
#         if score < THRESHOLD and len(matches) < MIN_MATCHES:
#             return {
#                 "status": "normal",
#                 "score": score,
#                 "matches": matches
#             }

#         # تحديد severity
#         # لو rule واحدة قوية (زي XSS / SQLi)
#         if len(matches) == 1 and score >= 5:
#             severity = "High"
#         else:
#             if score >= 10:
#                 severity = "Critical"
#             elif score >= 6:
#                 severity = "High"
#             elif score >= 3:
#                 severity = "Medium"
#             else:
#                 severity = "Low"

#         top_attack = max(attack_scores, key=attack_scores.get) if attack_scores else "Unknown"

#         xss_type = None

#         if re.search(r"<script.*?>", decoded):
#             xss_type = "Reflected XSS"
#         elif "onerror=" in decoded or "onload=" in decoded:
#             xss_type = "Event-based XSS"
#         elif "javascript:" in decoded:
#             xss_type = "DOM XSS"

#         return {
#             "status": "attack",
#             "score": score,
#             "matches": matches,
#             "top_attack": top_attack,
#             "details": dict(attack_scores),
#             "severity": severity,
#             "sub_type": xss_type
#         }

# # =========================================================
# # SINGLETON
# # =========================================================

# _detector_instance = None

# def get_static_detector():
#     global _detector_instance

#     if _detector_instance is None:
#         current_dir = os.path.dirname(os.path.abspath(__file__))
#         rules_path = os.path.join(current_dir, 'coreruleset')

#         print(f" Loading rules from: {rules_path}")

#         parser = CRSParser(rules_path)
#         parser.parse_all()

#         _detector_instance = AttackDetector(parser)

#     return _detector_instance

# # =========================================================
# # MIDDLEWARE ENTRY
# # =========================================================

# def check_log_static(log_entry):
#     detector = get_static_detector()

#     result = detector.detect(log_entry)

#     if result["status"] == "attack":
#         return True, result, result["severity"]

#     return False, result, "Low"
# #----------------------------------------------------