import pika
import json
import requests

API_URL = "http://localhost:8000/predict"

def callback(ch, method, properties, body):
    try:
        log = json.loads(body.decode())
        with open('aisentinel_raw_data.jsonl', 'a', encoding='utf-8') as f:
            f.write(json.dumps(log) + '\n')

        # Send to API
        try:
            requests.post(API_URL, json=log, timeout=2)
            print(f"[+] Processed & Archived: {log.get('ip')}")
        except requests.exceptions.RequestException:
            print(f"[!] API Unreachable, log saved locally only.")
        # response = requests.post(API_URL, json=log)
        # print(f"[+] Sent to API: {log.get('ip')}")

        ch.basic_ack(delivery_tag=method.delivery_tag)

    except Exception as e:
        print(f"[!] Error: {e}")

def main():
    connection = pika.BlockingConnection(
        pika.ConnectionParameters(host='localhost')
    )
    channel = connection.channel()

    channel.queue_declare(queue='aisentinel.logs', durable=True)

    channel.basic_consume(
        queue='aisentinel.logs',
        on_message_callback=callback
    )

    print("[*] Consumer running (receiver only)...")
    channel.start_consuming()

if __name__ == "__main__":
    main()
# import pika
# import json
# import pandas as pd
# import joblib

# from preprocessing import PreSplitPreprocessor  

# # تحميل الموديل مرة واحدة بس
# model = joblib.load("model.pkl")

# processor = PreSplitPreprocessor()

# def callback(ch, method, properties, body):
#     try:
#         log_entry = json.loads(body.decode())

#         # حفظ raw data (زي ما هو)
#         with open('aisentinel_raw_data.jsonl', 'a', encoding='utf-8') as f:
#             f.write(json.dumps(log_entry) + '\n')

#         # -----------------------------
#         #  NEW: Preprocessing + Prediction
#         # -----------------------------
#         df = pd.DataFrame([log_entry])

#         df_processed = processor.run_all(df)

#         prediction = model.predict(df_processed)[0]

#         print(f" [+] IP: {log_entry.get('ip', 'N/A')} | Prediction: {prediction}")

#         # ACK
#         ch.basic_ack(delivery_tag=method.delivery_tag)

#     except Exception as e:
#         print(f" [!] Error processing log: {e}")

# def main():
#     connection = pika.BlockingConnection(
#         pika.ConnectionParameters(host='localhost')
#     )

#     channel = connection.channel()
#     channel.queue_declare(queue='aisentinel.logs', durable=True)

#     channel.basic_consume(
#         queue='aisentinel.logs',
#         on_message_callback=callback
#     )

#     print(' [*] AiSentinel Real-Time Detection Running...')
#     channel.start_consuming()

# if __name__ == '__main__':
#     main()
#--------------------------------------------------------------------
# import pika
# import json
# import sys  

# def callback(ch, method, properties, body):
#     try:
#         # تحويل الداتا المستلمة لـ Dictionary
#         log_entry = json.loads(body.decode())
        
#         # حفظ الداتا في ملف بتنسيق JSON Lines (كل سطر JSON مستقل)
#         # 'a' تعني Append عشان يضيف على الملف مش يمسحه
#         with open('aisentinel_raw_data.jsonl', 'a', encoding='utf-8') as f:
#             f.write(json.dumps(log_entry) + '\n')
            
#         print(f" [+] Data Received and Saved: {log_entry.get('ip', 'N/A')} from {log_entry.get('country', 'Unknown')}")
        
#         # تأكيد الاستلام لـ RabbitMQ
#         ch.basic_ack(delivery_tag=method.delivery_tag)
#     except Exception as e:
#         print(f" [!] Error processing log: {e}")

# def main():
#     connection = pika.BlockingConnection(pika.ConnectionParameters(host='localhost'))
#     channel = connection.channel()
#     channel.queue_declare(queue='aisentinel.logs', durable=True)
    
#     channel.basic_consume(queue='aisentinel.logs', on_message_callback=callback)
#     print(' [*] AiSentinel Pipeline is Running... Saving data to .jsonl')
#     channel.start_consuming()

# if __name__ == '__main__':
#     main()





# import pika
# import sys
# import os
# import json

# def callback(ch, method, properties, body):
#     # تحويل الـ JSON اللي جاي من RabbitMQ لـ Python Dictionary
#     try:
#         log_entry = json.loads(body.decode())
        
#         # سحب البيانات اللي إحنا محتاجينها بس
#         msg = log_entry.get('message', 'No Message')
#         time = log_entry.get('@timestamp', 'No Timestamp')
#         # بنستخدم .get() مع dictionary فاضي كديفولت عشان نتجنب الـ Key Error
#         log_info = log_entry.get('log', {})
#         file_info = log_info.get('file', {})
#         source = file_info.get('path', 'Unknown')

#         print(f"\n[AiSentinel Analysis]")
#         print(f"  Time  : {time}")
#         print(f"  Source: {source}")
#         print(f"  Log   : {msg}")
#         print(f"--------------------------------------")
        
#         # هنا هيكون مكان موديول الـ AI مستقبلاً
#         # result = ai_model.predict(msg)
        
#         # تأكيد استلام الرسالة عشان تتمسح من الـ Queue
#         ch.basic_ack(delivery_tag=method.delivery_tag)
#     except Exception as e:
#         print(f"Error parsing JSON: {e}")

# def main():
#     # إعدادات الاتصال بـ RabbitMQ
#     connection = pika.BlockingConnection(pika.ConnectionParameters(host='localhost'))
#     channel = connection.channel()

#     # التأكد من وجود الـ Queue
#     channel.queue_declare(queue='aisentinel.logs', durable=True)

#     # تحديد الوظيفة (callback) اللي هتتنفذ لما تيجي رسالة
#     channel.basic_consume(queue='aisentinel.logs', on_message_callback=callback)

#     print(' [*] AiSentinel is waiting for logs.. Press CTRL+C to exit')
#     channel.start_consuming()

# if __name__ == '__main__':
#     try:
#         main()
#     except KeyboardInterrupt:
#         print('\nShutting down AiSentinel Consumer...')
#         try:
#             sys.exit(0)
#         except SystemExit:
#             os._exit(0)