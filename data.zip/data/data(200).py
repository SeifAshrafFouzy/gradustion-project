import pandas as pd
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
csv_path = os.path.join(BASE_DIR, "data.csv")

df = pd.read_csv(csv_path)

val_end = int(len(df) * 0.85)
eval_df = df.iloc[val_end:].copy()

tested_logs = eval_df.head(200)

output_path = os.path.join(BASE_DIR, "debug_logs.xlsx")
tested_logs.to_excel(output_path, index=False)

print(f" Saved logs to {output_path}")
