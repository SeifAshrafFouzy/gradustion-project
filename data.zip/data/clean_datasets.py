import re

def clean_csv_file(file_path, output_path):
    print(f"Reading original: {file_path}")
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            content = f.read()

        pattern = r"(normal|attack|xss|directory_traversal|command_injection|lfi|rfi|scanning|benign_suspicious)(\d{1,3}\.\d{1,3})"
        fixed_content = re.sub(pattern, r"\1\n\2", content, flags=re.IGNORECASE)

        with open(output_path, "w", encoding="utf-8") as f:
            f.write(fixed_content)
            
        print(f"Created clean version at: {output_path}\n")
    except Exception as e:
        print(f"Error processing {file_path}: {e}\n")

if __name__ == "__main__":
    clean_csv_file(r"C:\AiSentinel\data\data_anomaly_V1.csv", r"C:\AiSentinel\data\data.csv")
    clean_csv_file(r"C:\AiSentinel\data\data_threat_V1.csv", r"C:\AiSentinel\data\data_threat.csv")
    
    print("Clean files are generated! Your original files remain untouched.")