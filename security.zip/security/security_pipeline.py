import logging
from datetime import datetime
from activeResponse.active_responder import take_action 
from core.static_engine import check_log_static

logger = logging.getLogger(__name__)

class SecurityPipeline:
    def __init__(self, anomaly_model, threat_model=None):
        self.anomaly_model = anomaly_model
        self.threat_model = threat_model
        self.brute_force_cache = {}  # ذاكرة التتبع زمنياً

    def _parse_log_timestamp(self, log_entry):
        raw_time = log_entry.get("timestamp") or log_entry.get("frame.time")
        if raw_time:
            try:
                if isinstance(raw_time, (int, float)):
                    return float(raw_time)
                return datetime.strptime(str(raw_time).split(".")[0], "%Y-%m-%d %H:%M:%S").timestamp()
            except:
                try:
                    return datetime.strptime(str(raw_time), "%d/%b/%Y:%H:%M:%S").timestamp()
                except:
                    pass
        return datetime.now().timestamp()

    def _check_brute_force_window(self, ip, request_str, status_code, log_time):
        if "login" in str(request_str).lower() and int(status_code) == 401:
            if ip not in self.brute_force_cache:
                self.brute_force_cache[ip] = []
            
            self.brute_force_cache[ip].append(log_time)
            self.brute_force_cache[ip] = [t for t in self.brute_force_cache[ip] if log_time - t <= 60]
            
            if len(self.brute_force_cache[ip]) >= 4:
                return True
        return False

    @staticmethod
    def _calculate_static_attack_weights(request_str):
        request_str = str(request_str).lower()
        
        sqli_signals = ["select", "union", "insert", "update", "delete", "'", "--", "/*", "or 1=1"]
        sqli_score = sum(5 for signal in sqli_signals if signal in request_str)

        xss_signals = ["<script", "script>", "javascript:", "onerror", "onload", "alert(", "<img", "href="]
        xss_score = sum(5 for signal in xss_signals if signal in request_str)

        traversal_signals = ["..", "../", "..\\", "/etc/", "passwd", "boot.ini", "win.ini", "var/log"]
        traversal_score = sum(4 for signal in traversal_signals if signal in request_str)
        
        cmd_signals = [";", "&&", "||", "`", "whoami", "id", "uname", "cmd.exe", "/bin/sh", "/bin/bash"]
        cmd_score = sum(5 for signal in cmd_signals if signal in request_str)
        
        scores = {
            "sql_injection": sqli_score,
            "xss": xss_score,
            "directory_traversal": traversal_score,
            "command_injection": cmd_score 
        }
        
        max_attack = max(scores, key=scores.get)
        if scores[max_attack] == 0:
            return "normal", 0.0
            
        return max_attack, scores[max_attack]

    def run(self, log_entry: dict):
        if "status" not in log_entry: log_entry["status"] = log_entry.get("status_code", 200)
        if "ip" not in log_entry: log_entry["ip"] = log_entry.get("source_ip", "127.0.0.1")

        result_data = {
            "status": "normal", "reason": "None", "severity": "Low",
            "sub_type": "None", "anomaly_score": 0.0, "stages": [] 
        }

        ip = log_entry["ip"]
        request_str = str(log_entry.get("request", ""))
        status_code = int(log_entry["status"])
        log_time = self._parse_log_timestamp(log_entry)

        # =========================================================
        # 🚨 محطة 0: Stateful Brute Force Detection
        # =========================================================
        if self._check_brute_force_window(ip, request_str, status_code, log_time):
            result_data["stages"] = ["STATIC:RATE_LIMIT", "THREAT:BYPASS", "ANOMALY:BYPASS"]
            result_data.update({"status": "blocked", "reason": "Threat: bruteforce", "severity": "High", "sub_type": "bruteforce"})
            take_action(log_entry, "Time-Window Engine", "bruteforce", "High")
            return result_data

        # =========================================================
        # 🚨 محطة 1: الـ Static Engine (الفحص المتتالي الأول)
        # =========================================================
        try:
            is_attack, static_result, static_severity = check_log_static(log_entry)
            static_score = static_result.get("score", 0)
            static_reason = static_result.get("top_attack", "Unknown")
        except:
            is_attack, static_score, static_severity, static_reason = False, 0, "Low", "None"

        current_static_sev = static_severity.upper() if static_score > 0 else "CLEAN"

        # 🔴 [تعديل جوهري: إعطاء الـ Static شخصية مستقلة وصريحة]:
        if current_static_sev in ["CRITICAL", "HIGH"] and static_score >= 8:
            static_type, _ = self._calculate_static_attack_weights(request_str)
            confirmed_attack_type = static_type if static_type != "normal" else static_reason.lower()
            
            # 🌟 صيغة إدانة صريحة تؤكد للجنة أن الـ Static هو من قرر الحظر
            explicit_reason = f"Static Firewall Direct Block: {confirmed_attack_type.upper()}"

            result_data["stages"] = [f"STATIC:{current_static_sev}", "THREAT:BYPASS", "ANOMALY:BYPASS"]
            result_data.update({
                "status": "blocked", 
                "reason": explicit_reason,
                "severity": static_severity, 
                "sub_type": confirmed_attack_type, 
                "anomaly_score": 0.0
            })
            # 🌟 إرسال التنبيه باسم الطبقة الصريحة ليظهر في التليجرام والداشبورد كخط دفاع أول
            take_action(log_entry, "Static Rules Engine (Line 1 Defense)", explicit_reason, static_severity)
            return result_data

        # =========================================================
        # 🚨 محطة 2: الـ Supervised ML Model (خط الدفاع المتتالي الثاني)
        # =========================================================
        # الطلب دخل هنا لأن الـ Static قال سكور قليل أو طبيعي (Low / Medium)
        threat_type = "normal"
        confidence = 0.0
        if self.threat_model:
            try:
                threat_res = self.threat_model(log_entry, model_name="ensemble")
                threat_type = threat_res.get("attack_name", "Normal").strip().lower()
                confidence = threat_res.get("confidence", 0.0)
            except: pass

        is_threat_attack = threat_type not in ["normal", "benign", "none", "clean", "benign_suspicious"]

        if is_threat_attack:
            result_data["stages"] = [f"STATIC:{current_static_sev}", "THREAT:ATTACK", "ANOMALY:BYPASS"]
            result_data.update({
                "status": "blocked", 
                "reason": f"Threat Layer: {threat_type}",
                "severity": "Medium", 
                "sub_type": threat_type, 
                "anomaly_score": float(confidence)
            })
            # الموديل الخاضع للإشراف لقط الهجوم -> حظر فوري مبكر (Early Break)
            take_action(log_entry, "Threat Layer (Ensemble)", threat_type, "Medium")
            return result_data

        # =========================================================
        # 🚨 محطة 3: الـ Behavioral Anomaly Engine (خط الدفاع المتتالي الأخير)
        # =========================================================
        # الطلب دخل هنا لأن الـ Static والـ Threat قالوا طبيعي
        try:
            ai_anomaly_prediction = self.anomaly_model.predict(log_entry, model_type="if")
            prediction_val = ai_anomaly_prediction.get("prediction", "Normal")
            score = ai_anomaly_prediction.get("reconstruction_error", 0.0)
        except:
            prediction_val, score = "Normal", 0.0

        is_anomaly = prediction_val in ["Attack", "Anomaly", 1, True]

        if is_anomaly:
            result_data["stages"] = [f"STATIC:{current_static_sev}", "THREAT:NORMAL", f"ANOMALY:ATTACK:{score:.2f}"]
            result_data.update({
                "status": "blocked", 
                "reason": "Anomaly Detected",
                "severity": "Medium", 
                "sub_type": "Anomaly", 
                "anomaly_score": score
            })
            # موديل كشف الشذوذ (Isolation Forest) رصد سلوك مريب -> حظر وإرسال تنبيه
            take_action(log_entry, "AI Anomaly Engine (IF)", "Anomaly", "Medium")
            return result_data

        # =========================================================
        # 🟢 تمرير المرور بأمان تام (الطلب سليم ولم تطلقه أي محطة)
        # =========================================================
        result_data["stages"] = [f"STATIC:{current_static_sev}", "THREAT:NORMAL", f"ANOMALY:NORMAL:{score:.2f}"]
        return result_data




#  لوجيك السيستم اللى فيه توازى و تتابع
# import logging
# from datetime import datetime
# from activeResponse.active_responder import take_action 
# from core.static_engine import check_log_static

# logger = logging.getLogger(__name__)

# class SecurityPipeline:
#     def __init__(self, anomaly_model, threat_model=None):
#         self.anomaly_model = anomaly_model
#         self.threat_model = threat_model
#         self.brute_force_cache = {}  # ذاكرة التتبع زمنياً

#     def _parse_log_timestamp(self, log_entry):
#         raw_time = log_entry.get("timestamp") or log_entry.get("frame.time")
#         if raw_time:
#             try:
#                 if isinstance(raw_time, (int, float)):
#                     return float(raw_time)
#                 return datetime.strptime(str(raw_time).split(".")[0], "%Y-%m-%d %H:%M:%S").timestamp()
#             except:
#                 try:
#                     return datetime.strptime(str(raw_time), "%d/%b/%Y:%H:%M:%S").timestamp()
#                 except:
#                     pass
#         return datetime.now().timestamp()

#     def _check_brute_force_window(self, ip, request_str, status_code, log_time):
#         if "login" in str(request_str).lower() and int(status_code) == 401:
#             if ip not in self.brute_force_cache:
#                 self.brute_force_cache[ip] = []
            
#             self.brute_force_cache[ip].append(log_time)
#             self.brute_force_cache[ip] = [t for t in self.brute_force_cache[ip] if log_time - t <= 60]
            
#             if len(self.brute_force_cache[ip]) >= 4:
#                 return True
#         return False

#     @staticmethod
#     def _calculate_static_attack_weights(request_str):
#         request_str = str(request_str).lower()
        
#         sqli_signals = ["select", "union", "insert", "update", "delete", "'", "--", "/*", "or 1=1"]
#         sqli_score = sum(5 for signal in sqli_signals if signal in request_str)

#         xss_signals = ["<script", "script>", "javascript:", "onerror", "onload", "alert(", "<img", "href="]
#         xss_score = sum(5 for signal in xss_signals if signal in request_str)

#         traversal_signals = ["..", "../", "..\\", "/etc/", "passwd", "boot.ini", "win.ini", "var/log"]
#         traversal_score = sum(4 for signal in traversal_signals if signal in request_str)
        
#         cmd_signals = [";", "&&", "||", "`", "whoami", "id", "uname", "cmd.exe", "/bin/sh", "/bin/bash"]
#         cmd_score = sum(5 for signal in cmd_signals if signal in request_str)
        
#         scores = {
#             "sql_injection": sqli_score,
#             "xss": xss_score,
#             "directory_traversal": traversal_score,
#             "command_injection": cmd_score 
#         }
        
#         max_attack = max(scores, key=scores.get)
#         if scores[max_attack] == 0:
#             return "normal", 0.0
            
#         return max_attack, scores[max_attack]

#     def run(self, log_entry: dict):
#         if "status" not in log_entry: log_entry["status"] = log_entry.get("status_code", 200)
#         if "ip" not in log_entry: log_entry["ip"] = log_entry.get("source_ip", "127.0.0.1")

#         result_data = {
#             "status": "normal", "reason": "None", "severity": "Low",
#             "sub_type": "None", "anomaly_score": 0.0, "stages": [] 
#         }

#         ip = log_entry["ip"]
#         request_str = str(log_entry.get("request", ""))
#         status_code = int(log_entry["status"])
#         log_time = self._parse_log_timestamp(log_entry)

#         # 🚨 محطة 0: Stateful Brute Force Detection
#         if self._check_brute_force_window(ip, request_str, status_code, log_time):
#             result_data["stages"] = ["STATIC:RATE_LIMIT", "THREAT:BYPASS", "ANOMALY:BYPASS"]
#             result_data.update({"status": "blocked", "reason": "Threat: bruteforce", "severity": "High", "sub_type": "bruteforce"})
#             take_action(log_entry, "Time-Window Engine", "bruteforce", "High")
#             return result_data

#         # 🚨 محطة 1: الـ Static Engine
#         try:
#             is_attack, static_result, static_severity = check_log_static(log_entry)
#             static_score = static_result.get("score", 0)
#             static_reason = static_result.get("top_attack", "Unknown")
#         except:
#             is_attack, static_score, static_severity, static_reason = False, 0, "Low", "None"

#         # تحديد مسمى الخطورة الاستاتيكية الصريح
#         current_static_sev = static_severity.upper() if static_score > 0 else "CLEAN"

#         # =========================================================
#         # 🚨 محطة 2: Severity-Based Routing Flow
#         # =========================================================
        
#         # 🔴 أولاً: مسار الخطورة العالية (بناءً على الـ THRESHOLD = 8)
#         if current_static_sev in ["CRITICAL", "HIGH"] and static_score >= 8:
            
#             threat_type = "normal"
#             if self.threat_model:
#                 try:
#                     threat_res = self.threat_model(log_entry, model_name="ensemble")
#                     threat_type = threat_res.get("attack_name", "Normal").strip().lower()
#                 except: pass

#             try:
#                 # 🌟 تعديل النداء ليطلب موديل الـ Isolation Forest فقط
#                 ai_anomaly_prediction = self.anomaly_model.predict(log_entry, model_type="if")
#                 prediction_val = ai_anomaly_prediction.get("prediction", "Normal")
#                 score = ai_anomaly_prediction.get("reconstruction_error", 0.0)
#             except:
#                 prediction_val, score = "Normal", 0.0

#             is_threat_attack = threat_type not in ["normal", "benign", "none", "clean"]
#             is_anomaly = prediction_val in ["Attack", "Anomaly", 1, True]

#             threat_status = "ATTACK" if is_threat_attack else "NORMAL"
#             anomaly_status = f"ATTACK:{score:.2f}" if is_anomaly else f"NORMAL:{score:.2f}"

#             if is_anomaly or is_threat_attack:
#                 static_type, _ = self._calculate_static_attack_weights(request_str)
#                 confirmed_attack_type = static_type if static_type != "normal" else static_reason.lower()

#                 # 🌟 صيغة الـ Stages النظيفة الموحدة
#                 result_data["stages"] = [f"STATIC:{current_static_sev}", f"THREAT:{threat_status}", f"ANOMALY:{anomaly_status}"]
#                 result_data.update({
#                     "status": "blocked", "reason": f"Static Engine: {confirmed_attack_type}",
#                     "severity": static_severity, "sub_type": confirmed_attack_type, "anomaly_score": score
#                 })
#                 take_action(log_entry, "Hybrid Engine (Static+AI)", confirmed_attack_type, static_severity)
#                 return result_data
#             else:
#                 result_data["stages"] = [f"STATIC:{current_static_sev}", f"THREAT:{threat_status}", f"ANOMALY:{anomaly_status}"]
#                 return result_data

#         # 🟡 ثانياً: مسار الخطورة المنخفضة أو الريكوست النظيف
#         else:
#             threat_type = "normal"
#             confidence = 0.0
#             if self.threat_model:
#                 try:
#                     threat_res = self.threat_model(log_entry, model_name="ensemble")
#                     threat_type = threat_res.get("attack_name", "Normal").strip().lower()
#                     confidence = threat_res.get("confidence", 0.0)
#                 except: pass

#             is_threat_attack = threat_type not in ["normal", "benign", "none", "clean", "benign_suspicious"]

#             if is_threat_attack:
#                 result_data["stages"] = [f"STATIC:{current_static_sev}", "THREAT:ATTACK", "ANOMALY:BYPASS"]
#                 result_data.update({
#                     "status": "blocked", "reason": f"Threat Layer: {threat_type}",
#                     "severity": "Medium", "sub_type": threat_type, "anomaly_score": float(confidence)
#                 })
#                 take_action(log_entry, "Threat Layer", threat_type, "Medium")
#                 return result_data

#             try:
#                 # 🌟 تعديل النداء ليطلب موديل الـ Isolation Forest فقط
#                 ai_anomaly_prediction = self.anomaly_model.predict(log_entry, model_type="if")
#                 prediction_val = ai_anomaly_prediction.get("prediction", "Normal")
#                 score = ai_anomaly_prediction.get("reconstruction_error", 0.0)
#             except:
#                 prediction_val, score = "Normal", 0.0

#             if prediction_val in ["Attack", "Anomaly", 1, True]:
#                 result_data["stages"] = [f"STATIC:{current_static_sev}", "THREAT:NORMAL", f"ANOMALY:ATTACK:{score:.2f}"]
#                 result_data.update({
#                     "status": "blocked", "reason": "Anomaly Detected",
#                     "severity": "Medium", "sub_type": "Anomaly", "anomaly_score": score
#                 })
#                 take_action(log_entry, "AI Anomaly Engine", "Anomaly", "Medium")
#                 return result_data

#             # المرور بأمان تام
#             result_data["stages"] = [f"STATIC:{current_static_sev}", "THREAT:NORMAL", f"ANOMALY:NORMAL:{score:.2f}"]
#             return result_data



















































# import logging
# from datetime import datetime
# from activeResponse.active_responder import take_action 
# from core.static_engine import check_log_static

# logger = logging.getLogger(__name__)

# class SecurityPipeline:
#     def __init__(self, anomaly_model, threat_model=None):
#         self.anomaly_model = anomaly_model
#         self.threat_model = threat_model
#         self.brute_force_cache = {}  # ذاكرة التتبع زمنياً

#     def _parse_log_timestamp(self, log_entry):
#         """🌟 حل مشكلة الوقت: قراءة الوقت من اللوج نفسه لتوافق البيئة الحقيقية والتيست"""
#         raw_time = log_entry.get("timestamp") or log_entry.get("frame.time")
#         if raw_time:
#             try:
#                 if isinstance(raw_time, (int, float)):
#                     return float(raw_time)
#                 return datetime.strptime(str(raw_time).split(".")[0], "%Y-%m-%d %H:%M:%S").timestamp()
#             except:
#                 try:
#                     return datetime.strptime(str(raw_time), "%d/%b/%Y:%H:%M:%S").timestamp()
#                 except:
#                     pass
#         return datetime.now().timestamp()  # Fallback للوقت الفعلي الحالي

#     def _check_brute_force_window(self, ip, request_str, status_code, log_time):
#         """تتبع نافذة الـ Brute Force بناءً على وقت اللوج الديناميكي"""
#         if "login" in str(request_str).lower() and int(status_code) == 401:
#             if ip not in self.brute_force_cache:
#                 self.brute_force_cache[ip] = []
            
#             self.brute_force_cache[ip].append(log_time)
#             # تصفية النافذة (60 ثانية بناءً على وقت اللوج الحقيقي)
#             self.brute_force_cache[ip] = [t for t in self.brute_force_cache[ip] if log_time - t <= 60]
            
#             if len(self.brute_force_cache[ip]) >= 4:
#                 return True
#         return False
#     @staticmethod
#     def _calculate_static_attack_weights(request_str):
#         request_str = str(request_str).lower()
        
#         sqli_signals = ["select", "union", "insert", "update", "delete", "'", "--", "/*", "or 1=1"]
#         sqli_score = sum(5 for signal in sqli_signals if signal in request_str)

#         xss_signals = ["<script", "script>", "javascript:", "onerror", "onload", "alert(", "<img", "href="]
#         xss_score = sum(5 for signal in xss_signals if signal in request_str)

#         traversal_signals = ["..", "../", "..\\", "/etc/", "passwd", "boot.ini", "win.ini", "var/log"]
#         traversal_score = sum(4 for signal in traversal_signals if signal in request_str)
        
#         # 🌟 إضافة إشارات صريحة للـ Command Injection
#         cmd_signals = [";", "&&", "||", "`", "whoami", "id", "uname", "cmd.exe", "/bin/sh", "/bin/bash"]
#         cmd_score = sum(5 for signal in cmd_signals if signal in request_str)
        
#         scores = {
#             "sql_injection": sqli_score,
#             "xss": xss_score,
#             "directory_traversal": traversal_score,
#             "command_injection": cmd_score  # 🌟 تم الضم بنجاح
#         }
        
#         max_attack = max(scores, key=scores.get)
#         if scores[max_attack] == 0:
#             return "normal", 0.0
            
#         return max_attack, scores[max_attack]
#     # @staticmethod
#     # def _calculate_static_attack_weights(request_str):
#     #     """حساب الأوزان المعتمدة لتحديد المسمى الدقيق عند الحاجة"""
#     #     request_str = str(request_str).lower()
        
#     #     sqli_signals = ["select", "union", "insert", "update", "delete", "'", "--", "/*", "or 1=1"]
#     #     sqli_score = sum(5 for signal in sqli_signals if signal in request_str)

#     #     xss_signals = ["<script", "script>", "javascript:", "onerror", "onload", "alert(", "<img", "href="]
#     #     xss_score = sum(5 for signal in xss_signals if signal in request_str)

#     #     traversal_signals = ["..", "../", "..\\", "/etc/", "passwd", "boot.ini", "win.ini", "var/log"]
#     #     traversal_score = sum(4 for signal in traversal_signals if signal in request_str)
        
#     #     scores = {
#     #         "sql_injection": sqli_score,
#     #         "xss": xss_score,
#     #         "directory_traversal": traversal_score
#     #     }
        
#     #     max_attack = max(scores, key=scores.get)
#     #     if scores[max_attack] == 0:
#     #         return "normal", 0.0
            
#     #     return max_attack, scores[max_attack]

#     def run(self, log_entry: dict):
#         if "status" not in log_entry: log_entry["status"] = log_entry.get("status_code", 200)
#         if "ip" not in log_entry: log_entry["ip"] = log_entry.get("source_ip", "127.0.0.1")

#         result_data = {
#             "status": "normal", "reason": "None", "severity": "Low",
#             "sub_type": "None", "anomaly_score": 0.0, "stages": [] 
#         }

#         ip = log_entry["ip"]
#         request_str = str(log_entry.get("request", ""))
#         status_code = int(log_entry["status"])
        
#         # جلب الوقت الديناميكي للوج
#         log_time = self._parse_log_timestamp(log_entry)

#         # 🚨 محطة 0: Stateful Brute Force Detection
#         if self._check_brute_force_window(ip, request_str, status_code, log_time):
#             result_data["stages"].append("TimeWindow:bruteforce")
#             result_data.update({"status": "blocked", "reason": "Threat: bruteforce", "severity": "High", "sub_type": "bruteforce"})
#             take_action(log_entry, "Time-Window Engine", "bruteforce", "High")
#             return result_data

#         # 🚨 محطة 1: الـ Static Engine
#         try:
#             is_attack, static_result, static_severity = check_log_static(log_entry)
#             static_score = static_result.get("score", 0)
#             static_reason = static_result.get("top_attack", "Unknown")
#         except:
#             is_attack, static_score, static_severity, static_reason = False, 0, "Low", "None"

#         # =========================================================
#         # 🚨 محطة 2: Severity-Based Routing Flow (اللوجيك المعدل والمحمي)
#         # =========================================================
        
#         # 🔴 أولاً: مسار الخطورة العالية (بناءً على الـ THRESHOLD = 8 المرفوع)
#         if static_severity in ["Critical", "High"] and static_score >= 8:
#             result_data["stages"].append(f"Static_Suspect:{static_severity}")
            
#             # استدعاء الـ 2 Models معاً كمجلس تأكيد (Majority Voting)
#             threat_type = "normal"
#             if self.threat_model:
#                 try:
#                     threat_res = self.threat_model(log_entry, model_name="ensemble")
#                     threat_type = threat_res.get("attack_name", "Normal").strip().lower()
#                 except: pass

#             try:
#                 ai_anomaly_prediction = self.anomaly_model.predict(log_entry, model_type="ensemble")
#                 prediction_val = ai_anomaly_prediction.get("prediction", "Normal")
#                 score = ai_anomaly_prediction.get("reconstruction_error", 0.0)
#             except:
#                 prediction_val, score = "Normal", 0.0

#             is_threat_attack = threat_type not in ["normal", "benign", "none", "clean"]
#             is_anomaly = prediction_val in ["Attack", "Anomaly", 1, True]

#             # التصويت المشروط: لو حد فيهم قال هجوم -> النوع النهائي هو اللي الـ static حددته
#             if is_anomaly or is_threat_attack:
#                 static_type, _ = self._calculate_static_attack_weights(request_str)
#                 confirmed_attack_type = static_type if static_type != "normal" else static_reason.lower()

#                 result_data["stages"].append(f"AI_Confirmed:{confirmed_attack_type}")
#                 result_data.update({
#                     "status": "blocked", "reason": f"Static Engine: {confirmed_attack_type}",
#                     "severity": static_severity, "sub_type": confirmed_attack_type, "anomaly_score": score
#                 })
#                 take_action(log_entry, "Hybrid Engine (Static+AI)", confirmed_attack_type, static_severity)
#                 return result_data
#             else:
#                 # الـ AI Override الصريح لحماية النورمال
#                 result_data["stages"].append("AI_Override:Passed")
#                 return result_data

#         # 🟡 ثانياً: مسار الخطورة المنخفضة أو المتوسطة أو الريكوست نظيف استاتيكياً
#         else:
#             if static_score > 0: result_data["stages"].append(f"Static_Mild:{static_severity}")
#             else: result_data["stages"].append("Static:Clean")

#             # أ) يدخل على الـ Threat Model أولاً
#             threat_type = "normal"
#             confidence = 0.0
#             if self.threat_model:
#                 try:
#                     threat_res = self.threat_model(log_entry, model_name="ensemble")
#                     threat_type = threat_res.get("attack_name", "Normal").strip().lower()
#                     confidence = threat_res.get("confidence", 0.0)
#                 except: pass

#             # استثناء النورمال والمنطقة الرمادية benign_suspicious
#             is_threat_attack = threat_type not in ["normal", "benign", "none", "clean", "benign_suspicious"]

#             if is_threat_attack:
#                 # 🌟 التعديل المطلوب: الاعتماد على الموديل فقط لتحديد نوع الهجوم بدون دكج
#                 confirmed_attack_type = threat_type

#                 result_data["stages"].append(f"Threat_Layer_Catch:{confirmed_attack_type}")
#                 result_data.update({
#                     "status": "blocked", "reason": f"Threat Layer: {confirmed_attack_type}",
#                     "severity": "Medium", "sub_type": confirmed_attack_type, "anomaly_score": float(confidence)
#                 })
#                 take_action(log_entry, "Threat Layer", confirmed_attack_type, "Medium")
#                 return result_data

#             # ب) محطة الـ Anomaly Engine للفصل النهائي بـ Static Baseline ومصيدة الـ FN
#             try:
#                 ai_anomaly_prediction = self.anomaly_model.predict(log_entry, model_type="ensemble")
#                 prediction_val = ai_anomaly_prediction.get("prediction", "Normal")
#                 score = ai_anomaly_prediction.get("reconstruction_error", 0.0)
#             except:
#                 prediction_val, score = "Normal", 0.0

#             if prediction_val in ["Attack", "Anomaly", 1, True]:
#                 result_data["stages"].append(f"Anomaly_Layer_Catch:{score:.2f}")
#                 result_data.update({
#                     "status": "blocked", "reason": "Anomaly Detected",
#                     "severity": "Medium", "sub_type": "Anomaly", "anomaly_score": score
#                 })
#                 take_action(log_entry, "AI Anomaly Engine", "Anomaly", "Medium")
#                 return result_data

#             # المرور بأمان تـام
#             result_data["stages"].append(f"Passed_All_Checks:{score:.2f}")
#             return result_data





































# # from activeResponse.active_responder import take_action 
# # from core.static_engine import check_log_static
# # from datetime import datetime
# # import logging     
# # import traceback  

# # logger = logging.getLogger(__name__)
# # analysis_mode = False  # production

# # class SecurityPipeline:

# #     def __init__(self, anomaly_model, threat_model=None):
# #         self.anomaly_model = anomaly_model
# #         self.threat_model = threat_model
# #         self.analysis_mode = analysis_mode
# #         self.brute_force_cache = {} 

# #     def _check_brute_force_window(self, ip, request_str, status_code):
# #         if "login" in str(request_str).lower() and status_code == 401:
# #             current_time = datetime.now().timestamp()
# #             if ip not in self.brute_force_cache:
# #                 self.brute_force_cache[ip] = []
# #             self.brute_force_cache[ip].append(current_time)
# #             self.brute_force_cache[ip] = [t for t in self.brute_force_cache[ip] if current_time - t <= 60]
# #             if len(self.brute_force_cache[ip]) >= 4:
# #                 return True
# #         return False

# #     @staticmethod
# #     def _calculate_static_attack_weights(request_str):
# #         request_str = str(request_str).lower()
# #         sqli_signals = ["select", "union", "insert", "update", "delete", "'", "--", "/*", "or 1=1"]
# #         sqli_score = sum(1 for signal in sqli_signals if signal in request_str)
# #         if "'" in request_str and ("or" in request_str or "union" in request_str):
# #             sqli_score += 2

# #         xss_signals = ["<script", "script>", "javascript:", "onerror", "onload", "alert(", "<img", "href="]
# #         xss_score = sum(1 for signal in xss_signals if signal in request_str)
# #         if "<" in request_str and ">" in request_str:
# #             xss_score += 1

# #         traversal_signals = ["..", "../", "..\\", "/etc/", "passwd", "boot.ini", "win.ini", "var/log"]
# #         traversal_score = sum(1 for signal in traversal_signals if signal in request_str)
        
# #         scores = {
# #             "sql_injection": sqli_score,
# #             "xss": xss_score,
# #             "directory_traversal": traversal_score
# #         }
# #         max_attack = max(scores, key=scores.get)
# #         if scores[max_attack] == 0:
# #             return "normal", 0.0
# #         return max_attack, scores[max_attack]

# #     def run(self, log_entry: dict):
# #         if "status" not in log_entry: log_entry["status"] = 200
# #         if "ip" not in log_entry: log_entry["ip"] = log_entry.get("source_ip", "127.0.0.1")

# #         result_data = {
# #             "status": "normal", "reason": "None", "severity": "Low",
# #             "sub_type": "None", "anomaly_score": 0.0, "stages": [] 
# #         }

# #         ip = log_entry["ip"]
# #         request_str = str(log_entry.get("request", ""))
# #         status_code = int(log_entry["status"])

# #         # 🚨 محطة 0: تتبع الـ Brute Force
# #         if self._check_brute_force_window(ip, request_str, status_code):
# #             result_data["stages"].append("TimeWindow:bruteforce")
# #             result_data.update({"status": "blocked", "reason": "Threat: bruteforce", "severity": "High", "sub_type": "bruteforce"})
# #             take_action(log_entry, "Time-Window Engine", "bruteforce", "High")
# #             return result_data

# #         # 🚨 محطة 1: التقييم الاستاتيكي (بيدينا سكور والـ SeverityLabel)
# #         try:
# #             is_attack, static_result, static_severity = check_log_static(log_entry)
# #             static_score = static_result.get("score", 0)
# #             static_reason = static_result.get("top_attack", "Unknown")
# #         except Exception as e:
# #             is_attack, static_score, static_severity, static_reason = False, 0, "Low", "None"

# #         # =========================================================
# #         # 🚨 محطة 2: الـ Routing Mode الاحترافي المبني على الخطورة
# #         # =========================================================
        
# #         # 🔴 أولاً: حالة الشبهة العالية (High/Critical) -> الـ AI كـ مجلس تأكيد
# #         if static_severity in ["Critical", "High"] and static_score > 0:
# #             result_data["stages"].append(f"Static_Suspect:{static_severity}")
            
# #             attack_type = "normal"
# #             confidence = 0.0
# #             if self.threat_model:
# #                 try:
# #                     threat_result = self.threat_model(log_entry, model_name="ensemble")
# #                     attack_type = threat_result.get("attack_name", "Normal").strip().lower()
# #                     confidence = threat_result.get("confidence", 0.0)
# #                 except:
# #                     pass

# #             ai_input = self._convert_log(log_entry)
# #             try:
# #                 ai_anomaly_prediction = self.anomaly_model.predict(ai_input, model_type="ensemble")
# #                 prediction_val = ai_anomaly_prediction.get("prediction", "Normal")
# #                 score = ai_anomaly_prediction.get("reconstruction_error", 0.0)
# #             except:
# #                 prediction_val, score = "Normal", 0.0

# #             is_threat_attack = attack_type not in ["normal", "benign", "none", "clean"]
# #             is_anomaly = prediction_val in ["Attack", "Anomaly", 1, True]

# #             if is_anomaly or is_threat_attack:
# #                 static_type, _ = self._calculate_static_attack_weights(request_str)
# #                 if static_type != "normal":
# #                     confirmed_attack_type = static_type
# #                 else:
# #                     # لو جاية من الـ Threat باسم شبهة، بنحولها لـ Suspicious Behavior
# #                     confirmed_attack_type = "Suspicious Behavior" if attack_type == "benign_suspicious" else attack_type

# #                 result_data["stages"].append(f"AI_Confirmed:{confirmed_attack_type}")

# #                 result_data.update({
# #                     "status": "blocked", "reason": f"Static Engine: {confirmed_attack_type}",
# #                     "severity": static_severity, "sub_type": confirmed_attack_type,
# #                     "anomaly_score": score if score > 0 else float(confidence)
# #                 })
# #                 take_action(log_entry, "Hybrid Engine (Static+AI)", confirmed_attack_type, static_severity)
# #                 return result_data
# #             else:
# #                 result_data["status"] = "normal" 
# #                 result_data["stages"].append("AI_Override:Passed")
# #                 return result_data

# #         # 🟡 ثانياً: حالة الـ Low / Medium أو النظيف تماماً (تطبيق منطقك بالملي)
# #         else:
# #             if static_score > 0:
# #                 result_data["stages"].append(f"Static_Mild:{static_severity}")
# #             else:
# #                 result_data["stages"].append("Static:Clean")

# #             # المحطة A: ركّزي هنا.. يمر أولاً على الـ Threat Model
# #             attack_type = "normal"
# #             confidence = 0.0
# #             if self.threat_model:
# #                 try:
# #                     threat_result = self.threat_model(log_entry, model_name="ensemble")
# #                     attack_type = threat_result.get("attack_name", "Normal").strip().lower()
# #                     confidence = threat_result.get("confidence", 0.0)
# #                 except:
# #                     pass

# #             is_threat_attack = attack_type not in ["normal", "benign", "none", "clean", "benign_suspicious"]

# #             # لو الـ Threat قال إنه Attack -> احظر فوراً واعمل Return (توفير موارد)
# #             if is_threat_attack:
# #                 static_type, _ = self._calculate_static_attack_weights(request_str)
# #                 confirmed_attack_type = static_type if static_type != "normal" else attack_type

# #                 result_data["stages"].append(f"Threat_Layer_Catch:{confirmed_attack_type}")
# #                 result_data.update({
# #                     "status": "blocked", "reason": f"Threat Layer: {confirmed_attack_type}",
# #                     "severity": "Medium", "sub_type": confirmed_attack_type, "anomaly_score": float(confidence)
# #                 })
# #                 take_action(log_entry, "Threat Layer", confirmed_attack_type, "Medium")
# #                 return result_data

# #             # المحطة B: لو الـ Threat ملقطش حاجة (Else) -> يدخل على الـ Anomaly Engine كـ مصيدة أخيرة
# #             ai_input = self._convert_log(log_entry)
# #             try:
# #                 ai_anomaly_prediction = self.anomaly_model.predict(ai_input, model_type="ensemble")
# #                 prediction_val = ai_anomaly_prediction.get("prediction", "Normal")
# #                 score = ai_anomaly_prediction.get("reconstruction_error", 0.0)
# #             except:
# #                 prediction_val, score = "Normal", 0.0

# #             is_anomaly = prediction_val in ["Attack", "Anomaly", 1, True]

# #             if is_anomaly:
# #                 result_data["stages"].append(f"Anomaly_Layer_Catch:{score:.2f}")
# #                 result_data.update({
# #                     "status": "blocked", "reason": "Anomaly Detected",
# #                     "severity": "Medium", "sub_type": "Anomaly", "anomaly_score": score
# #                 })
# #                 take_action(log_entry, "AI Anomaly Engine", "Anomaly", "Medium")
# #                 return result_data

# #             # لو عدى من كل ده يبقى سليم 100%
# #             result_data["stages"].append(f"Passed_All_Checks:{score:.2f}")
# #             return result_data

# #     def _convert_log(self, log_entry):
# #         # دالة التحويل الداخلية لتجهيز الداتا للـ ML
# #         raw_ip = str(log_entry.get("source_ip") or log_entry.get("ip") or "127.0.0.1").strip()
# #         clean_ip = raw_ip.split(":")[0] if ":" in raw_ip else raw_ip
# #         raw_request = str(log_entry.get("request") or log_entry.get("request_url") or "GET / HTTP/1.1").strip()
# #         if "HTTP" not in raw_request.upper(): raw_request = f"{raw_request} HTTP/1.1"
# #         headers = log_entry.get("headers", {})
# #         if not isinstance(headers, dict): headers = {}
# #         user_agent = headers.get("user-agent") or log_entry.get("user_agent") or "Unknown"
# #         referer = headers.get("referer") or "Unknown"

# #         return {
# #             "ip": clean_ip, "request": raw_request, "status": log_entry.get("status", 200),
# #             "size": log_entry.get("size", 500), "datetime": datetime.now().strftime('%d/%b/%Y:%H:%M:%S'), 
# #             "browser": user_agent, "referer": referer
# #         }
    



# # Accuracy 66
# # from activeResponse.active_responder import take_action 
# # from core.static_engine import check_log_static
# # from datetime import datetime
# # import logging     
# # import traceback  

# # # -----------------------------
# # # Logging Setup
# # # -----------------------------
# # logger = logging.getLogger(__name__)

# # analysis_mode = False  # production

# # class SecurityPipeline:

# #     def __init__(self, anomaly_model, threat_model=None):
# #         self.anomaly_model = anomaly_model
# #         self.threat_model = threat_model
# #         self.analysis_mode = analysis_mode
# #         # 🌟 تعديل 1: الذاكرة المؤقتة لتتبع محاولات الـ Brute Force
# #         self.brute_force_cache = {} 

# #     # 🌟 تعديل 2: دالة تتبع الوقت التكرارية المحدثة والخفيفة للـ Brute Force
# #     def _check_brute_force_window(self, ip, request_str, status_code):
# #         if "login" in str(request_str).lower() and status_code == 401:
# #             current_time = datetime.now().timestamp()
# #             if ip not in self.brute_force_cache:
# #                 self.brute_force_cache[ip] = []
            
# #             self.brute_force_cache[ip].append(current_time)
# #             # تنظيف النوافذ الزمنية التي مر عليها أكثر من دقيقة
# #             self.brute_force_cache[ip] = [t for t in self.brute_force_cache[ip] if current_time - t <= 60]
            
# #             # العتبة الذكية (4 محاولات فاشلة في الدقيقة = Brute Force قطعي)
# #             if len(self.brute_force_cache[ip]) >= 4:
# #                 return True
# #         return False

# #     # 🌟 دالة حساب الأوزان (باقية كـ staticmethod لتصحيح مسميات الأنواع)
# #     @staticmethod
# #     def _calculate_static_attack_weights(request_str):
# #         request_str = str(request_str).lower()
        
# #         # 1. SQL Injection Indicators
# #         sqli_signals = ["select", "union", "insert", "update", "delete", "'", "--", "/*", "or 1=1"]
# #         sqli_score = sum(1 for signal in sqli_signals if signal in request_str)
# #         if "'" in request_str and ("or" in request_str or "union" in request_str):
# #             sqli_score += 2

# #         # 2. XSS Indicators
# #         xss_signals = ["<script", "script>", "javascript:", "onerror", "onload", "alert(", "<img", "href="]
# #         xss_score = sum(1 for signal in xss_signals if signal in request_str)
# #         if "<" in request_str and ">" in request_str:
# #             xss_score += 1

# #         # 3. Directory Traversal / LFI Indicators
# #         traversal_signals = ["..", "../", "..\\", "/etc/", "passwd", "boot.ini", "win.ini", "var/log"]
# #         traversal_score = sum(1 for signal in traversal_signals if signal in request_str)
        
# #         scores = {
# #             "sql_injection": sqli_score,
# #             "xss": xss_score,
# #             "directory_traversal": traversal_score
# #         }
        
# #         max_attack = max(scores, key=scores.get)
# #         if scores[max_attack] == 0:
# #             return "normal", 0.0
            
# #         return max_attack, scores[max_attack]

# #     def run(self, log_entry: dict):
# #         if "status" not in log_entry:
# #             log_entry["status"] = 200
# #         if "ip" not in log_entry:
# #             log_entry["ip"] = log_entry.get("source_ip", "127.0.0.1")

# #         result_data = {
# #             "status": "normal",
# #             "reason": "None",
# #             "severity": "Low",
# #             "sub_type": "None",
# #             "anomaly_score": 0.0,
# #             "stages": [] 
# #         }

# #         # جلب البيانات الأساسية للفحص
# #         ip = log_entry["ip"]
# #         request_str = str(log_entry.get("request", ""))
# #         status_code = int(log_entry["status"])

# #         # =========================================================
# #         # 🚨 محطة الصفر: Stateful Brute Force Detection (Time-Window)
# #         # =========================================================
# #         if self._check_brute_force_window(ip, request_str, status_code):
# #             logger.warning(f"[BRUTE FORCE] IP {ip} detected via sliding window!")
# #             result_data["stages"].append("TimeWindow:bruteforce")
# #             result_data.update({
# #                 "status": "blocked",
# #                 "reason": "Threat: bruteforce",
# #                 "severity": "High",
# #                 "sub_type": "bruteforce"
# #             })
# #             take_action(log_entry, "Time-Window Engine", "bruteforce", "High")
# #             if not self.analysis_mode:
# #                 return result_data

# #         # =========================================================
# #         # 1) الـ Static Engine: فحص الشبهة وتحديد الـ Severity فقط
# #         # =========================================================
# #         try:
# #             is_attack, static_result, static_severity = check_log_static(log_entry)
# #             static_score = static_result.get("score", 0)
# #             static_reason = static_result.get("top_attack", "Unknown")
# #         except Exception as e:
# #             logger.error(f"[ERROR] Static Engine Failed: {e}")
# #             is_attack, static_score, static_severity, static_reason = False, 0, "Low", "None"

# #         # =========================================================
# #         # 🌟 تعديل 3: منطق التوجيه الذكي الاحترافي (Severity-Based Routing)
# #         # =========================================================
        
# #         # 🔴 الحالة الأولى: الـ Static لقط شبهة خطيرة (Critical / High) -> الـ AI كـ مجلس تأكيد لمنع الـ FP
# #         if static_severity in ["Critical", "High"] and static_score > 0:
# #             result_data["stages"].append(f"Static_Suspect:{static_severity}")
            
# #             # استدعاء الـ Anomaly للفصل والـ Validation
# #             ai_input = self._convert_log(log_entry)
# #             try:
# #                 ai_anomaly_prediction = self.anomaly_model.predict(ai_input, model_type="ensemble")
# #                 prediction_val = ai_anomaly_prediction.get("prediction", "Normal")
# #                 score = ai_anomaly_prediction.get("reconstruction_error", 0.0)
# #             except Exception as e:
# #                 logger.warning(f"Anomaly Model Failed during validation: {e}")
# #                 prediction_val, score = "Normal", 0.0

# #             is_anomaly = prediction_val in ["Attack", "Anomaly", 1, True]

# #             if is_anomaly:
# #                 # الـ AI وافق الـ Static -> حظر فوري وتصحيح الاسم بالدالة الذكية
# #                 static_type, _ = self._calculate_static_attack_weights(request_str)
# #                 confirmed_attack_type = static_type if static_type != "normal" else static_reason.lower()

# #                 result_data["stages"].append(f"AI_Confirmed:{confirmed_attack_type}")
# #                 result_data.update({
# #                     "status": "blocked",
# #                     "reason": f"Static Engine: {confirmed_attack_type}",
# #                     "severity": static_severity,
# #                     "sub_type": confirmed_attack_type,
# #                     "anomaly_score": score
# #                 })
# #                 take_action(log_entry, "Hybrid Engine (Static+AI)", confirmed_attack_type, static_severity)
# #                 if not self.analysis_mode:
# #                     return result_data
# #             else:
# #                 # الـ AI أنقذ الموقف ورفض قرار الـ CRS الجامد -> تمرير بأمان
# #                 result_data["stages"].append("AI_Override:Passed")
# #                 if not self.analysis_mode:
# #                     return result_data

# #         # 🟡 الحالة الثانية: الـ Static مطلع نتيجة Low/Medium أو الريكوست نظيف تماماً
# #         # المنطق: تمرير للـ Anomaly Engine كـ مفتش عشان يصيد الـ False Negatives (الهجمات المشفرة)
# #         else:
# #             if static_score > 0:
# #                 result_data["stages"].append(f"Static_Mild:{static_severity}")
# #             else:
# #                 result_data["stages"].append("Static:Clean")

# #             ai_input = self._convert_log(log_entry)
# #             try:
# #                 ai_anomaly_prediction = self.anomaly_model.predict(ai_input, model_type="ensemble")
# #                 prediction_val = ai_anomaly_prediction.get("prediction", "Normal")
# #                 score = ai_anomaly_prediction.get("reconstruction_error", 0.0)
# #             except Exception as e:
# #                 prediction_val, score = "Normal", 0.0

# #             is_anomaly = prediction_val in ["Attack", "Anomaly", 1, True]

# #             if is_anomaly:
# #                 result_data["stages"].append(f"Anomaly_Layer:{score:.2f}")
# #                 result_data.update({
# #                     "status": "blocked",
# #                     "reason": "Anomaly Detected",
# #                     "severity": "Medium",
# #                     "sub_type": "Anomaly",
# #                     "anomaly_score": score
# #                 })
# #                 take_action(log_entry, "AI Anomaly Engine", "Anomaly", "Medium")
# #                 if not self.analysis_mode:
# #                     return result_data

# #             # لو كل الطبقات شافت إنه سليم بيعدي عادي
# #             result_data["stages"].append(f"Passed_All_Checks:{score:.2f}")
# #             return result_data

# #     def _convert_log(self, log_entry):
# #         # دالة التحويل الداخلية المعتمدة لديكِ
# #         return log_entry











#     #  نسخة ما قبل 8 ص يوم 26/6
# # from activeResponse.active_responder import take_action 
# # from core.static_engine import check_log_static
# # from datetime import datetime
# # import logging     
# # import traceback  

# # from threat.preprocessing.security_patterns import (
# #     SQL_PATTERNS, XSS_PATTERNS, CMD_PATTERNS, 
# #     TRAVERSAL_PATTERNS, LFI_PATTERNS, RFI_PATTERNS
# # )
# # # -----------------------------
# # # Logging Setup
# # # -----------------------------
# # logger = logging.getLogger(__name__)

# # analysis_mode = False  # production

# # class SecurityPipeline:

# #     def __init__(self, anomaly_model, threat_model=None):
# #         self.anomaly_model = anomaly_model
# #         self.threat_model = threat_model
# #         self.analysis_mode = analysis_mode
# #         self.brute_force_cache = {}

# #     def _check_brute_force_window(self, ip, request_str, status_code):
# #         if "login" in str(request_str).lower() and status_code == 401:
# #             current_time = datetime.now().timestamp()
# #             if ip not in self.brute_force_cache:
# #                 self.brute_force_cache[ip] = []
# #             self.brute_force_cache[ip].append(current_time)
# #             self.brute_force_cache[ip] = [t for t in self.brute_force_cache[ip] if current_time - t <= 60]
# #             if len(self.brute_force_cache[ip]) >= 4: 
# #                 return True
# #         return False
        
# #     @staticmethod
# #     def _calculate_static_attack_weights(request_str):
# #         request_str = str(request_str).lower()
        
# #         # 1. SQL Injection Indicators
# #         sqli_signals = ["select", "union", "insert", "update", "delete", "'", "--", "/*", "or 1=1"]
# #         sqli_score = sum(1 for signal in sqli_signals if signal in request_str)
# #         if "'" in request_str and ("or" in request_str or "union" in request_str):
# #             sqli_score += 2

# #         # 2. XSS Indicators
# #         xss_signals = ["<script", "script>", "javascript:", "onerror", "onload", "alert(", "<img", "href="]
# #         xss_score = sum(1 for signal in xss_signals if signal in request_str)
# #         if "<" in request_str and ">" in request_str:
# #             xss_score += 1

# #         # 3. Directory Traversal / LFI Indicators
# #         traversal_signals = ["..", "../", "..\\", "/etc/", "passwd", "boot.ini", "win.ini", "var/log"]
# #         traversal_score = sum(1 for signal in traversal_signals if signal in request_str)
        
# #         scores = {
# #             "sql_injection": sqli_score,
# #             "xss": xss_score,
# #             "directory_traversal": traversal_score
# #         }
        
# #         max_attack = max(scores, key=scores.get)
        
# #         if scores[max_attack] == 0:
# #             return "normal", 0.0
            
# #         return max_attack, scores[max_attack]
    
# #     def run(self, log_entry: dict):

# #         if "status" not in log_entry:
# #             log_entry["status"] = 200
# #         if "ip" not in log_entry:
# #             log_entry["ip"] = log_entry.get("source_ip", "127.0.0.1")

# #         ip = log_entry["ip"]
# #         request_str = str(log_entry.get("request", ""))
# #         status_code = int(log_entry["status"])

# #         result_data = {
# #             "status": "normal",
# #             "reason": "None",
# #             "severity": "Low",
# #             "sub_type": "None",
# #             "anomaly_score": 0.0,
# #             "stages": [] 
# #         }

# #         try:
# #             # =========================================================
# #             # 0) Stateful Brute Force Detection (Time-Window)
# #             # =========================================================
# #             if self._check_brute_force_window(ip, request_str, status_code):
# #                 logger.warning(f"[BRUTE FORCE] IP {ip} exceeded max login failures within 1 min!")
# #                 result_data["stages"].append("TimeWindow:bruteforce")
# #                 result_data.update({
# #                     "status": "blocked",
# #                     "reason": "Threat: bruteforce",
# #                     "severity": "High",
# #                     "sub_type": "bruteforce"
# #                 })
# #                 take_action(log_entry, "Time-Window Engine", "bruteforce", "High")
# #                 if not self.analysis_mode:
# #                     return result_data
# #             # =========================================================
# #             # 1) Static Rules 
# #             # =========================================================
# #             try:
# #                 is_attack, static_result, static_severity = check_log_static(log_entry)
# #                 static_score = static_result.get("score", 0)
# #                 static_reason = static_result.get("top_attack", "Unknown")
# #             except Exception as e:
# #                 is_attack, static_score, static_severity, static_reason = False, 0, "Low", "None"

# #         # =========================================================
# #         # 2) لوجيك التوجيه الذكي المعتمد (Severity-Based Routing)
# #         # =========================================================
        
# #             if static_severity in ["Critical", "High"] and static_score > 0:
# #                 result_data["stages"].append(f"Static_Suspect:{static_severity}")
                
# #                 ai_input = self._convert_log(log_entry)
# #                 try:
# #                     ai_anomaly_prediction = self.anomaly_model.predict(ai_input, model_type="ensemble")
# #                     prediction_val = ai_anomaly_prediction.get("prediction", "Normal")
# #                     score = ai_anomaly_prediction.get("reconstruction_error", 0.0)
# #                 except:
# #                     prediction_val, score = "Normal", 0.0

# #                 if prediction_val in ["Attack", "Anomaly", 1, True]:
# #                     # الـ AI أكد الشبهة -> حظر فوري وتصحيح المسمى
# #                     static_type, _ = self._calculate_static_attack_weights(request_str)
# #                     confirmed_type = static_type if static_type != "normal" else static_reason
                    
# #                     result_data["stages"].append(f"AI_Confirmed:{confirmed_attack_type}")
# #                     result_data.update({
# #                         "status": "blocked", "reason": f"Static Engine: {confirmed_attack_type}",
# #                         "severity": static_severity, "sub_type": confirmed_attack_type, "anomaly_score": score
# #                     })
# #                     take_action(log_entry, "Static + AI Combined", confirmed_attack_type, static_severity)
# #                     return result_data
# #                 else:
# #                     # الـ AI فحصها ولقاها طبيعية -> تمرير وحماية النورمال من ظلم الـ CRS
# #                     result_data["stages"].append("AI_Override:Passed")
# #                     return result_data

# #             # المنطقة العادية (Low / Medium / Clean) -> فحص سلوكي طبيعي بالـ AI لصيد الـ FN
# #             else:
# #                 if static_score > 0:
# #                     result_data["stages"].append(f"Static_Mild:{static_score}")
                    
# #                 ai_input = self._convert_log(log_entry)
# #                 try:
# #                     ai_anomaly_prediction = self.anomaly_model.predict(ai_input, model_type="ensemble")
# #                     prediction_val = ai_anomaly_prediction.get("prediction", "Normal")
# #                     score = ai_anomaly_prediction.get("reconstruction_error", 0.0)
# #                 except:
# #                     prediction_val, score = "Normal", 0.0

# #                 if prediction_val in ["Attack", "Anomaly", 1, True]:
# #                     result_data["stages"].append(f"Anomaly_Layer:{score:.2f}")
# #                     result_data.update({
# #                         "status": "blocked", "reason": "Anomaly Detected",
# #                         "severity": "Medium", "sub_type": "Anomaly", "anomaly_score": score
# #                     })
# #                     take_action(log_entry, "AI Anomaly Engine", "Anomaly", "Medium")
# #                     return result_data

# #                 result_data["stages"].append(f"Passed_All_Checks:{score:.2f}")
# #                 return result_data
# #                 # 26/6/2026  before 8PM
# #             #     is_attack, result, severity = check_log_static(log_entry)
# #             # except Exception as e:
# #             #     logger.error(f"[ERROR] Static Engine Failed: {e}")
# #             #     is_attack, result, severity = False, {}, "Low"
                
# #             # if is_attack:
# #             #     score = result.get("score", 0)
# #             #     reason = result.get("top_attack", "Unknown Attack")

# #             #     logger.info(f"[Static] Detected {reason} | Score={score}")
# #             #     result_data["stages"].append(f"Static:{reason}")
                
# #             #     take_action(log_entry, "Static Engine", reason, severity)

# #             #     if score >= 10 or severity in ["High", "Critical"]:
# #             #         result_data.update({
# #             #             "status": "blocked",
# #             #             "reason": reason,
# #             #             "severity": severity,
# #             #             "sub_type": result.get("sub_type", reason)
# #             #         })
# #             #         if not self.analysis_mode:
# #             #             return result_data
        
# #            # =========================================================
# #             # 2) Threat Detection (Secure Context-Aware Filtering)
# #             # =========================================================
# #             if self.threat_model:
# #                 try:
# #                     threat_result = self.threat_model(log_entry, model_name="ensemble")
# #                     attack_type = threat_result.get("attack_name", "Normal").strip().lower()
# #                     confidence = threat_result.get("confidence", 0.0)
# #                 except Exception as e:
# #                     logger.warning(f"[Threat Model] Failed: {e}.")
# #                     attack_type = "normal"
# #                     confidence = 0.0

# #                 is_threat_attack = attack_type not in ["normal", "benign", "none", "clean", "benign_suspicious"]

# #                 if is_threat_attack:
# #                     logger.info(f"[Threat Model] AI Detected Threat: {attack_type}")
# #                     request_str = str(log_entry.get("request", ""))
                    
# #                     # 🌟 تصحيح استدعاء الدالة باستخدام self لحل الـ NameError
# #                     static_type, static_score = self._calculate_static_attack_weights(request_str)
                    
# #                     if static_type != "normal" and static_score >= 1:
# #                         confirmed_attack_type = static_type
# #                     else:
# #                         confirmed_attack_type = attack_type

# #                     result_data["stages"].append(f"Threat:{confirmed_attack_type}")
# #                     result_data.update({
# #                         "status": "blocked",
# #                         "reason": f"Threat: {confirmed_attack_type}",
# #                         "severity": "High",
# #                         "sub_type": confirmed_attack_type,
# #                         "anomaly_score": float(confidence) 
# #                     })

# #                     take_action(log_entry, "Threat Model", confirmed_attack_type, "High")
# #                     if not self.analysis_mode:
# #                         return result_data
# #             # if self.threat_model:
# #             #     try:
# #             #         threat_result = self.threat_model(log_entry, model_name="ensemble")
# #             #         attack_type = threat_result.get("attack_name", "Normal").strip().lower()
# #             #         confidence = threat_result.get("confidence", 0.0)
# #             #     except Exception as e:
# #             #         logger.warning(f"[Threat Model] Execution Failed: {e}.")
# #             #         attack_type = "normal"
# #             #         confidence = 0.0

# #             #     is_threat_attack = attack_type not in ["normal", "benign", "none", "clean", "benign_suspicious"]

# #             #     if is_threat_attack:
# #             #         # 🌟 الحل الهندسي: للتأكد أن الـ Block ليس False Positive بسبب تشنج الموديل
# #             #         # بنتحقق من وجود ملمح هجوم حقيقي في الريكوست بالكامل (Request, Body, or Headers)
# #             #         full_payload_to_check = str(log_entry.get("request", "")) + str(log_entry.get("body", "")) + str(log_entry.get("headers", ""))
# #             #         full_payload_to_check = full_payload_to_check.lower()

# #             #         # مؤشرات حقيقية للهجمات (SQLi, Directory Traversal, XSS)
# #             #         has_real_malicious_indicator = (
# #             #             ".." in full_payload_to_check or 
# #             #             "'" in full_payload_to_check or 
# #             #             "--" in full_payload_to_check or 
# #             #             "<script" in full_payload_to_check or
# #             #             "select" in full_payload_to_check or
# #             #             "union" in full_payload_to_check
# #             #         )

# #             #         # السيستم مش هيعمل Block من طبقة الـ Threat إلا لو الموديل لقط هجوم وفيه علامة حقيقية في الداتا
# #             #         # وإلا.. هيعتبرها شبهة غير مؤكدة ويباصيها للـ Anomaly Engine يفحصها بهدوء
# #             #         if has_real_malicious_indicator:
# #             #             logger.info(f"[Threat Model] Confirmed Malicious Threat: {attack_type}")
                        
# #             #             # نحدد النوع بدقة عبر الـ Patterns
# #             #             request_str = str(log_entry.get("request", ""))
# #             #             if SQL_PATTERNS.search(request_str): confirmed_attack_type = "sql_injection"
# #             #             elif XSS_PATTERNS.search(request_str): confirmed_attack_type = "xss"
# #             #             elif CMD_PATTERNS.search(request_str): confirmed_attack_type = "command_injection"
# #             #             elif TRAVERSAL_PATTERNS.search(request_str) or LFI_PATTERNS.search(request_str): confirmed_attack_type = "directory_traversal"
# #             #             else: confirmed_attack_type = attack_type

# #             #             result_data["stages"].append(f"Threat:{confirmed_attack_type}")
# #             #             result_data.update({
# #             #                 "status": "blocked",
# #             #                 "reason": f"Threat: {confirmed_attack_type}",
# #             #                 "severity": "High",
# #             #                 "sub_type": confirmed_attack_type,
# #             #                 "anomaly_score": float(confidence) 
# #             #             })
# #             #             take_action(log_entry, "Threat Model", confirmed_attack_type, "High")
# #             #             if not self.analysis_mode:
# #             #                 return result_data
# #             #         else:
# #             #             logger.info(f"[Threat Model] Suspicious label but no hard indicators -> Passing to Anomaly Engine.")
          
# #            # الكود اللى ادانى دقة 69
# #             # if self.threat_model:
# #             #     try:
# #             #         threat_result = self.threat_model(log_entry, model_name="ensemble")
# #             #         attack_type = threat_result.get("attack_name", "Normal").strip().lower()
# #             #         confidence = threat_result.get("confidence", 0.0)
# #             #     except Exception as e:
# #             #         logger.warning(f"[Threat Model] Execution Failed: {e}. Falling back to 'Normal'.")
# #             #         attack_type = "normal"
# #             #         confidence = 0.0

# #             #     # القواعد الجديدة: بنستثني benign_suspicious والـ Normal الصريح
# #             #     is_threat_attack = (
# #             #         attack_type not in ["normal", "benign", "none", "clean", "benign_suspicious"]
# #             #     )

# #             #     if is_threat_attack:
# #             #         logger.info(f"[Threat Model] AI Detected Threat -> Matching with Security Patterns...")

# #             #         # 🌟 الحل العبقري: فحص الـ Request بالـ Patterns عشان نحدد النوع بدقة 100%
# #             #         request_str = str(log_entry.get("request", ""))
                    
# #             #         if SQL_PATTERNS.search(request_str):
# #             #             confirmed_attack_type = "sql_injection"
# #             #         elif XSS_PATTERNS.search(request_str):
# #             #             confirmed_attack_type = "xss"
# #             #         elif CMD_PATTERNS.search(request_str):
# #             #             confirmed_attack_type = "command_injection"
# #             #         elif TRAVERSAL_PATTERNS.search(request_str) or LFI_PATTERNS.search(request_str):
# #             #             confirmed_attack_type = "directory_traversal"
# #             #         elif RFI_PATTERNS.search(request_str):
# #             #             confirmed_attack_type = "remote_file_inclusion"
# #             #         else:
# #             #             # Fallback: لو الـ Patterns ملقطتش نوع صريح، نثق في تصنيف الـ AI نفسه
# #             #             confirmed_attack_type = attack_type

# #             #         logger.info(f"[Threat Model] Confirmed Type via Patterns: {confirmed_attack_type}")

# #             #         result_data["stages"].append(f"Threat:{confirmed_attack_type}")
# #             #         result_data.update({
# #             #             "status": "blocked",
# #             #             "reason": f"Threat: {confirmed_attack_type}",
# #             #             "severity": "High",
# #             #             "sub_type": confirmed_attack_type,
# #             #             "anomaly_score": float(confidence) 
# #             #         })

# #             #         take_action(log_entry, "Threat Model", confirmed_attack_type, "High")
                    
# #             #         if not self.analysis_mode:
# #             #             return result_data
                
# #             #     # لو benign_suspicious بتعدي بسلاسة للـ Anomaly Engine
# #             #     elif attack_type == "benign_suspicious":
# #             #         logger.info(f"[Threat Model] Classified as benign_suspicious -> Passing to Anomaly Engine.")
         
# #         #  =============================================================
# #             # قبل تعديل ال threat انه يحدد نوع الهجوم من خلال القواعد و اننا نخلى المشبوه يعدى نورمال
# #             # if self.threat_model:
# #             #     try:
# #             #         threat_result = self.threat_model(log_entry, model_name="ensemble")
# #             #         attack_type = threat_result.get("attack_name", "Normal").strip()
# #             #         confidence = threat_result.get("confidence", 0.0)
# #             #     except Exception as e:
# #             #         logger.warning(f"[Threat Model] Execution Failed: {e}. Falling back to 'Normal'.")
# #             #         attack_type = "Normal"
# #             #         confidence = 0.0

# #             #     # فحص صارم: لو الموديل مطلعش "Normal" أو "Benign" يبقى ده هجوم حقيقي!
# #             #     if attack_type.lower() not in ["normal", "benign", "none", "clean"]:
# #             #         logger.info(f"[Threat Model] Detected {attack_type} | Confidence: {confidence:.2f}")
# #             #         result_data["stages"].append(f"Threat:{attack_type}")

# #             #         result_data.update({
# #             #             "status": "blocked",
# #             #             "reason": f"Threat: {attack_type}",
# #             #             "severity": "High",
# #             #             "sub_type": attack_type,
# #             #             "anomaly_score": float(confidence) 
# #             #         })

# #             #         take_action(log_entry, "Threat Model", attack_type, "High")
                    
# #             #         if not self.analysis_mode:
# #             #             return result_data

# #             # =========================================================
# #             # 3) Anomaly Detection 
# #             # =========================================================
# #             ai_input = self._convert_log(log_entry)
            
# #             try:
# #                 ai_anomaly_prediction = self.anomaly_model.predict(
# #                     ai_input,
# #                     model_type="ensemble"
# #                 )
# #                 score = ai_anomaly_prediction.get("reconstruction_error", 0.0)
# #                 prediction_val = ai_anomaly_prediction.get("prediction", "Normal")
# #             except Exception as e:
# #                 logger.warning(f"Anomaly Model Failed: {e}")
# #                 prediction_val = "Normal"
# #                 score = 0.0
                
# #             logger.info(f"[Anomaly] Score: {score}")
            
# #             # التحقق المرن للتأكد من التقاط الهجوم
# #             is_anomaly = prediction_val in ["Attack", 1, True, "Anomaly"]

# #             if is_anomaly and result_data["status"] == "normal":
# #                 result_data["stages"].append(f"Anomaly:{score:.2f}")
# #                 result_data.update({
# #                     "status": "blocked",
# #                     "reason": "Anomaly Detected",
# #                     "severity": "High",
# #                     "sub_type": "Anomaly",
# #                     "anomaly_score": score
# #                 })

# #                 take_action(log_entry, "AI Engine", "Anomaly", "High")

# #                 if not self.analysis_mode:
# #                     return result_data
# #             else:
# #                 result_data["stages"].append(f"Anomaly:{score:.2f}")

# #         except Exception:   
# #             logger.error(f"[ERROR] Pipeline Error: {traceback.format_exc()}")
        
# #         # =============================
# #         # FINAL DECISION LOGGING
# #         # =============================
# #         logger.info(
# #             f"[FINAL] IP={log_entry.get('source_ip')} | "
# #             f"Stages={result_data['stages']} | "
# #             f"Status={result_data['status']} | "
# #             f"Type={result_data['sub_type']} | "
# #             f"Score={result_data['anomaly_score']}"
# #         )
# #         return result_data
    
# #     def _convert_log(self, log_entry):
# #         raw_ip = str(log_entry.get("source_ip") or log_entry.get("ip") or "127.0.0.1").strip()
# #         clean_ip = raw_ip.split(":")[0] if ":" in raw_ip else raw_ip

# #         # التعديل الجوهري هنا: البحث عن "request" أولاً عشان نحمي داتا سكريبت التقييم
# #         raw_request = str(log_entry.get("request") or log_entry.get("request_url") or log_entry.get("url") or "GET / HTTP/1.1").strip()
# #         if "HTTP" not in raw_request.upper():
# #             raw_request = f"{raw_request} HTTP/1.1"

# #         headers = log_entry.get("headers", {})
# #         if not isinstance(headers, dict): headers = {}
        
# #         user_agent = headers.get("user-agent") or log_entry.get("user_agent") or log_entry.get("browser") or "Unknown"
# #         referer = headers.get("referer") or log_entry.get("referer") or "Unknown"

# #         return {
# #             "ip": clean_ip,
# #             "request": raw_request,
# #             "status": log_entry.get("status", 200),
# #             "size": log_entry.get("size", 500),
# #             "datetime": datetime.now().strftime('%d/%b/%Y:%H:%M:%S'), 
# #             "browser": user_agent,
# #             "referer": referer
# #         }



# # # 25/6/2026 6PM
# # # from activeResponse.active_responder import take_action 
# # # from core.static_engine import check_log_static
# # # from datetime import datetime
# # # import logging     
# # # import traceback  

# # # logger = logging.getLogger(__name__)
# # # analysis_mode = False 

# # # class SecurityPipeline:
# # #     def __init__(self, anomaly_model, threat_model=None):
# # #         self.anomaly_model = anomaly_model
# # #         self.threat_model = threat_model
# # #         self.analysis_mode = analysis_mode

# # #     def run(self, log_entry: dict):
# # #         result_data = {"status": "normal", "reason": "None", "severity": "Low", "sub_type": "None", "anomaly_score": 0.0, "stages": []}

# # #         # 1) Static Rules (Highest Priority)
# # #         try:
# # #             is_attack, result, severity = check_log_static(log_entry)
# # #             if is_attack:
# # #                 reason = result.get("top_attack", "Static Violation")
# # #                 result_data["stages"].append(f"Static:{reason}")
                
# # #                 # Exit if severity is high/critical
# # #                 if severity in ["High", "Critical"]:
# # #                     result_data.update({"status": "blocked", "reason": reason, "severity": severity, "sub_type": result.get("sub_type", reason)})
# # #                     take_action(log_entry, "Static", reason, severity)
# # #                     return result_data # Fail-Fast!
                
# # #                 # If Low/Medium, continue to Threat Detection
# # #                 result_data.update({"severity": severity, "reason": reason})
# # #         except: pass

# # #         # 2) Threat Detection (Only if Static didn't block)
# # #         if self.threat_model:
# # #             try:
# # #                 threat_res = self.threat_model(log_entry, model_name="ensemble")
# # #                 attack_type = threat_res.get("attack_name", "Normal").strip()
# # #                 if attack_type.lower() not in ["normal", "benign"]:
# # #                     result_data["stages"].append(f"Threat:{attack_type}")
# # #                     result_data.update({"status": "blocked", "reason": f"Threat:{attack_type}", "severity": "High", "sub_type": attack_type})
# # #                     take_action(log_entry, "Threat Model", attack_type, "High")
# # #                     return result_data # Fail-Fast!
# # #             except: pass

# # #         # 3) Anomaly Detection (Final Fallback)
# # #         try:
# # #             ai_input = self._convert_log(log_entry)
# # #             pred = self.anomaly_model.predict(ai_input, model_type="ensemble")
# # #             score = pred.get("reconstruction_error", 0.0)
# # #             result_data["stages"].append(f"Anomaly:{score:.2f}")
            
# # #             if pred.get("prediction") == "Attack":
# # #                 result_data.update({"status": "blocked", "reason": "Anomaly Detected", "severity": "High", "sub_type": "Anomaly", "anomaly_score": score})
# # #                 take_action(log_entry, "AI Engine", "Anomaly", "High")
# # #         except: pass

# # #         return result_data

# # #     def _convert_log(self, log_entry):
# # #         raw_ip = str(log_entry.get("source_ip") or log_entry.get("ip") or "127.0.0.1").strip()
# # #         raw_request = str(log_entry.get("request_url") or log_entry.get("url") or "GET / HTTP/1.1").strip()
# # #         return {
# # #             "ip": raw_ip.split(":")[0],
# # #             "request": raw_request if "HTTP" in raw_request.upper() else f"{raw_request} HTTP/1.1",
# # #             "status": log_entry.get("status", 200),
# # #             "size": log_entry.get("size", 500),
# # #             "datetime": datetime.now().strftime('%d/%b/%Y:%H:%M:%S'), 
# # #             "browser": log_entry.get("user_agent") or "Unknown",
# # #             "referer": log_entry.get("referer") or "Unknown"
# # #         }














# # 25/6/2026 3:23AM   "The Best"
# # اللى ادانى دقة 100% فى تحديد الهجمات
# # from activeResponse.active_responder import take_action 
# # from core.static_engine import check_log_static
# # from datetime import datetime
# # import logging     
# # import traceback  

# # # -----------------------------
# # # Logging Setup
# # # -----------------------------
# # logger = logging.getLogger(__name__)

# # analysis_mode = False  # production
# # # analysis_mode = True  # Testing/Analysis

# # class SecurityPipeline:

# #     def __init__(self, anomaly_model, threat_model=None):
# #         self.anomaly_model = anomaly_model
# #         self.threat_model = threat_model
# #         self.analysis_mode = analysis_mode

# #     def run(self, log_entry: dict):

# #         if "status" not in log_entry:
# #             log_entry["status"] = 200
# #         if "ip" not in log_entry:
# #             log_entry["ip"] = log_entry.get("source_ip", "127.0.0.1")

# #         result_data = {
# #             "status": "normal",
# #             "reason": "None",
# #             "severity": "Low",
# #             "sub_type": "None",
# #             "anomaly_score": 0.0,
# #             "stages": [] 
# #         }

# #         try:
# #             # =========================================================
# #             # 1) Static Rules 
# #             # =========================================================
# #             try:
# #                 is_attack, result, severity = check_log_static(log_entry)
# #             except Exception as e:
# #                 logger.error(f"[ERROR] Static Engine Failed: {e}")
# #                 is_attack, result, severity = False, {}, "Low"
                
# #             if is_attack:
# #                 score = result.get("score", 0)
# #                 reason = result.get("top_attack", "Unknown Attack")

# #                 logger.info(f"[Static] Detected {reason} | Score={score}")
# #                 result_data["stages"].append(f"Static:{reason}")
                
# #                 take_action(log_entry, "Static Engine", reason, severity)

# #                 if score >= 10 or severity in ["High", "Critical"]:
# #                     result_data.update({
# #                         "status": "blocked",
# #                         "reason": reason,
# #                         "severity": severity,
# #                         "sub_type": result.get("sub_type", reason)
# #                     })
# #                     if not self.analysis_mode:
# #                         return result_data

# #             # =========================================================
# #             # 2) Threat Detection 
# #             # =========================================================
# #             if self.threat_model:
# #                 try:
# #                     threat_result = self.threat_model(log_entry, model_name="ensemble")
# #                     attack_type = threat_result.get("attack_name", "Normal").strip()
# #                     confidence = threat_result.get("confidence", 0.0)
# #                 except Exception as e:
# #                     logger.warning(f"[Threat Model] Execution Failed: {e}. Falling back to 'Normal'.")
# #                     attack_type = "Normal"
# #                     confidence = 0.0

# #                 # فحص صارم: لو الموديل مطلعش "Normal" أو "Benign" يبقى ده هجوم حقيقي!
# #                 if attack_type.lower() not in ["normal", "benign", "none", "clean"]:
# #                     logger.info(f"[Threat Model] Detected {attack_type} | Confidence: {confidence:.2f}")
# #                     result_data["stages"].append(f"Threat:{attack_type}")

# #                     result_data.update({
# #                         "status": "blocked",
# #                         "reason": f"Threat: {attack_type}",
# #                         "severity": "High",
# #                         "sub_type": attack_type,
# #                         "anomaly_score": float(confidence) 
# #                     })

# #                     # بننادي take_action هنا فقط في حالة الهجوم المؤكد!
# #                     take_action(log_entry, "Threat Model", attack_type, "High")
                    
# #                     if not self.analysis_mode:
# #                         return result_data
# #             # if self.threat_model:
# #             #     try:
# #             #         threat_result = self.threat_model(log_entry, model_name="ensemble")
# #             #         attack_type = threat_result.get("attack_name", "Normal")
# #             #         confidence = threat_result.get("confidence", 0.0)
# #             #     except Exception as e:
# #             #         logger.warning(f"[Threat Model] Execution Failed: {e}. Falling back to 'Normal'.")
# #             #         attack_type = "Normal"
# #             #         confidence = 0.0

# #             #     if attack_type.lower() not in ["normal", "benign"]:
# #             #         logger.info(f"[Threat Model] Detected {attack_type} | Confidence: {confidence:.2f}")
# #             #         result_data["stages"].append(f"Threat:{attack_type}")

# #             #         result_data.update({
# #             #             "status": "blocked",
# #             #             "reason": f"Threat: {attack_type}",
# #             #             "severity": "High",
# #             #             "sub_type": attack_type,
# #             #             "anomaly_score": float(confidence) 
# #             #         })

# #             #         take_action(log_entry, "Threat Model", attack_type, "High")
# #             #         if not self.analysis_mode:
# #             #             return result_data

# #             # =========================================================
# #             # 3) Anomaly Detection 
# #             # =========================================================
# #             ai_input = self._convert_log(log_entry)
           
# #             try:
# #                 ai_anomaly_prediction = self.anomaly_model.predict(
# #                     ai_input,
# #                     model_type="ensemble"
# #                 )

# #                 score = ai_anomaly_prediction.get("reconstruction_error", 0.0)
# #             except Exception as e:
# #                 logger.warning(f"Anomaly Model Failed: {e}")
# #                 ai_anomaly_prediction = {"prediction": "Normal"}
# #                 score = 0.0
                
# #             logger.info(f"[Anomaly] Score: {score}")
            
# #             if ai_anomaly_prediction["prediction"] == "Attack" and result_data["status"] == "normal":
# #                 result_data["stages"].append(f"Anomaly:{score}")
# #                 result_data.update({
# #                     "status": "blocked",
# #                     "reason": "Anomaly Detected",
# #                     "severity": "High",
# #                     "sub_type": "Anomaly",
# #                     "anomaly_score": score
# #                 })

# #                 take_action(log_entry, "AI Engine", "Anomaly", "High")

# #                 if not self.analysis_mode:
# #                     return result_data
# #             else:
# #                 result_data["stages"].append(f"Anomaly:{score}")

# #         except Exception:   
# #             logger.error(f"[ERROR] Pipeline Error: {traceback.format_exc()}")
       
# #         # =============================
# #         # NORMAL LOGGING
# #         # =============================
# #         if result_data["status"] == "normal":
# #             logger.info(
# #                 f"[NORMAL] IP={log_entry.get('source_ip')} | "
# #                 f"Stages={result_data['stages']}"
# #             )
# #         # =============================
# #         # FINAL DECISION
# #         # =============================
# #         logger.info(
# #             f"[FINAL] IP={log_entry.get('source_ip')} | "
# #             f"Stages={result_data['stages']} | "
# #             f"Status={result_data['status']} | "
# #             f"Type={result_data['sub_type']} | "
# #             f"Score={result_data['anomaly_score']}"
# #         )
# #         return result_data
    
# #     def _convert_log(self, log_entry):
# #         raw_ip = str(log_entry.get("source_ip") or log_entry.get("ip") or "127.0.0.1").strip()
# #         clean_ip = raw_ip.split(":")[0] if ":" in raw_ip else raw_ip

# #         raw_request = str(log_entry.get("request_url") or log_entry.get("url") or "GET / HTTP/1.1").strip()
# #         if "HTTP" not in raw_request.upper():
# #             raw_request = f"{raw_request} HTTP/1.1"

# #         headers = log_entry.get("headers", {})
# #         if not isinstance(headers, dict): headers = {}
        
# #         user_agent = headers.get("user-agent") or log_entry.get("user_agent") or log_entry.get("browser") or "Unknown"
# #         referer = headers.get("referer") or log_entry.get("referer") or "Unknown"

# #         return {
# #             "ip": clean_ip,
# #             "request": raw_request,
# #             "status": log_entry.get("status", 200),
# #             "size": log_entry.get("size", 500),
# #             "datetime": datetime.now().strftime('%d/%b/%Y:%H:%M:%S'), 
# #             "browser": user_agent,
# #             "referer": referer
# #         }


























# # # from activeResponse.active_responder import take_action 
# # # from core.static_engine import check_log_static
# # # from datetime import datetime
# # # import logging     
# # # import traceback  

# # # # -----------------------------
# # # # Logging Setup
# # # # -----------------------------
# # # logger = logging.getLogger(__name__)

# # # analysis_mode = False  # production
# # # # analysis_mode = True  # Testing/Analysis

# # # class SecurityPipeline:

# # #     def __init__(self, anomaly_model, threat_model=None):
# # #         self.anomaly_model = anomaly_model
# # #         self.threat_model = threat_model
# # #         self.analysis_mode = analysis_mode

# # #     def run(self, log_entry: dict):

# # #         if "status" not in log_entry:
# # #             log_entry["status"] = 200
# # #         if "ip" not in log_entry:
# # #             log_entry["ip"] = log_entry.get("source_ip", "127.0.0.1")

# # #         result_data = {
# # #             "status": "normal",
# # #             "reason": "None",
# # #             "severity": "Low",
# # #             "sub_type": "None",
# # #             "anomaly_score": 0.0,
# # #             "stages": [] 
# # #         }

# # #         try:
# # #             # =============================
# # #             # 1) Static Rules
# # #             # =============================
# # #             try:
# # #                 is_attack, result, severity = check_log_static(log_entry)
# # #             except Exception as e:
# # #                 logger.error(f"[ERROR] Static Engine Failed: {e}")
# # #                 is_attack, result, severity = False, {}, "Low"
                
# # #             if is_attack:
# # #                 score = result.get("score", 0)
# # #                 reason = result.get("top_attack", "Unknown Attack")

# # #                 logger.info(f"[Static] Detected {reason} | Score={score}")
# # #                 result_data["stages"].append(f"Static:{reason}")
                
# # #                 take_action(log_entry, "Static Engine", reason, severity)

# # #                 if score >= 10 or severity in ["High", "Critical"]:
# # #                     result_data.update({
# # #                         "status": "blocked",
# # #                         "reason": reason,
# # #                         "severity": severity,
# # #                         "sub_type": result.get("sub_type")
# # #                     })
# # #                     if not self.analysis_mode:
# # #                       return result_data

# # #         # =============================
# # #         # 2) Threat Detection
# # #         # =============================
# # #             if self.threat_model:
# # #                 try:
# # #                     td_input = self._convert_log(log_entry)
# # #                     threat_result = self.threat_model.predict(td_input)
# # #                 except Exception as e:
# # #                     logger.warning(f"[Threat Model] Execution Failed: {e}. Falling back to 'Normal'.")
# # #                     threat_result = {"attack_type": "Normal"}

# # #                 attack_type = threat_result.get("attack_type", "Normal")

# # #                 if attack_type != "Normal":
# # #                     logger.info(f"[Threat Model] Detected {attack_type}")
# # #                     result_data["stages"].append(f"Threat:{attack_type}")

# # #                     result_data.update({
# # #                         "status": "blocked",
# # #                         "reason": f"Threat: {attack_type}",
# # #                         "severity": "High",
# # #                         "sub_type": attack_type
# # #                     })

# # #                     take_action(log_entry, "Threat Model", attack_type, "High")
# # #                     if not self.analysis_mode:
# # #                         return result_data

# # #             # =============================
# # #             # 3) Anomaly Detection
# # #             # =============================
# # #             ai_input = self._convert_log(log_entry)
           
# # #             try:
# # #                 ai_anomaly_prediction = self.anomaly_model.predict(
# # #                     ai_input,
# # #                     model_type="ensemble"
# # #                 )

# # #                 score = ai_anomaly_prediction.get("reconstruction_error", 0.0)
# # #             except Exception as e:
# # #                 logger.warning(f"Anomaly Model Failed: {e}")
# # #                 ai_anomaly_prediction = {"prediction": "Normal"}
# # #                 score = 0.0
# # #             logger.info(f"[Anomaly] Score: {score}")
# # #             result_data["stages"].append(f"Anomaly:{score}")

# # #             if ai_anomaly_prediction["prediction"] == "Attack":

# # #                 result_data.update({
# # #                     "status": "blocked",
# # #                     "reason": "Anomaly Detected",
# # #                     "severity": "High",
# # #                     "sub_type": "Anomaly",
# # #                     "anomaly_score": score
# # #                 })

# # #                 take_action(log_entry, "AI Engine", "Anomaly", "High")

# # #                 if not self.analysis_mode:
# # #                     return result_data

# # #         except Exception:   
# # #             logger.error(f"[ERROR] Pipeline Error: {traceback.format_exc()}")
       
# # #         # =============================
# # #         # NORMAL LOGGING
# # #         # =============================
# # #         if result_data["status"] == "normal":
# # #             logger.info(
# # #                 f"[NORMAL] IP={log_entry.get('source_ip')} | "
# # #                 f"Stages={result_data['stages']}"
# # #             )
# # #         # =============================
# # #         # FINAL DECISION (مرة واحدة بس)
# # #         # =============================
# # #         logger.info(
# # #             f"[FINAL] IP={log_entry.get('source_ip')} | "
# # #             f"Stages={result_data['stages']} | "
# # #             f"Status={result_data['status']} | "
# # #             f"Type={result_data['sub_type']} | "
# # #             f"Score={result_data['anomaly_score']}"
# # #         )
# # #         return result_data
    
# # #     def _convert_log(self, log_entry):
# # #         raw_ip = str(log_entry.get("source_ip") or log_entry.get("ip") or "127.0.0.1").strip()
# # #         clean_ip = raw_ip.split(":")[0] if ":" in raw_ip else raw_ip

# # #         raw_request = str(log_entry.get("request_url") or log_entry.get("url") or "GET / HTTP/1.1").strip()
# # #         if "HTTP" not in raw_request.upper():
# # #             raw_request = f"{raw_request} HTTP/1.1"

# # #         headers = log_entry.get("headers", {})
# # #         if not isinstance(headers, dict): headers = {}
        
# # #         user_agent = headers.get("user-agent") or log_entry.get("user_agent") or log_entry.get("browser") or "Unknown"
# # #         referer = headers.get("referer") or log_entry.get("referer") or "Unknown"

# # #         return {
# # #             "ip": clean_ip,
# # #             "request": raw_request,
# # #             "status": log_entry.get("status", 200),
# # #             "size": log_entry.get("size", 500),
# # #             "datetime": datetime.now().strftime('%d/%b/%Y:%H:%M:%S'), 
# # #             "browser": user_agent,
# # #             "referer": referer
# # #         }
    










# #     # def _convert_log(self, log_entry):

# #     #     # raw_request = log_entry.get("request_url", "")
# #     #     raw_request = str(log_entry.get("request_url") or "").strip()
# #     #     if not raw_request:
# #     #          raw_request = "GET / HTTP/1.1"
# #     #     # لو request ناقص HTTP version → نضيفه
# #     #     # if "HTTP" not in raw_request:
# #     #     #     raw_request = raw_request.upper() + " HTTP/1.1"
# #     #     if "HTTP" not in raw_request.upper():
# #     #         raw_request = f"{raw_request} HTTP/1.1"
# #     #     return {
# #     #         "ip": log_entry.get("source_ip"),
# #     #         # "request": log_entry.get("request_url"),
# #     #         "request": raw_request,
# #     #         "status": log_entry.get("status", 200),
# #     #         "size": log_entry.get("size", 500),
# #     #         "datetime": datetime.now().strftime('%d/%b/%Y:%H:%M:%S'),
# #     #         "browser": log_entry.get("headers", {}).get("user-agent", "Unknown"),
# #     #         "referer": log_entry.get("headers", {}).get("referer", "Unknown")
# #     #     }


  

# #  أخر تعديل 27/6/2026 12 م
# # from activeResponse.active_responder import take_action 
# # from core.static_engine import check_log_static
# # from datetime import datetime
# # import logging     

# # logger = logging.getLogger(__name__)

# # class SecurityPipeline:
# #     def __init__(self, anomaly_model, threat_model=None):
# #         self.anomaly_model = anomaly_model
# #         self.threat_model = threat_model
# #         self.brute_force_cache = {} # ذاكرة التتبع زمنياً

# #     def _parse_log_timestamp(self, log_entry):
# #         """🌟 حل مشكلة الوقت: قراءة الوقت من اللوج نفسه لتوافق البيئة الحقيقية والتيست"""
# #         raw_time = log_entry.get("timestamp") or log_entry.get("frame.time")
# #         if raw_time:
# #             try:
# #                 # محاولة قراءة صيغ التوقيت المشهورة في الداتاسيتس
# #                 if isinstance(raw_time, (int, float)):
# #                     return float(raw_time)
# #                 return datetime.strptime(str(raw_time).split(".")[0], "%Y-%m-%d %H:%M:%S").timestamp()
# #             except:
# #                 try:
# #                     return datetime.strptime(str(raw_time), "%d/%b/%Y:%H:%M:%S").timestamp()
# #                 except:
# #                     pass
# #         return datetime.now().timestamp() # Fallback للوقت الفعلي الحالي

# #     def _check_brute_force_window(self, ip, request_str, status_code, log_time):
# #         """تتبع نافذة الـ Brute Force بناءً على وقت اللوج الديناميكي"""
# #         if "login" in str(request_str).lower() and int(status_code) == 401:
# #             if ip not in self.brute_force_cache:
# #                 self.brute_force_cache[ip] = []
            
# #             self.brute_force_cache[ip].append(log_time)
# #             # تصفية النافذة (60 ثانية بناءً على وقت اللوج الحقيقي)
# #             self.brute_force_cache[ip] = [t for t in self.brute_force_cache[ip] if log_time - t <= 60]
            
# #             if len(self.brute_force_cache[ip]) >= 4:
# #                 return True
# #         return False

# #     @staticmethod
# #     def _calculate_static_attack_weights(request_str):
# #         """حساب الأوزان المعتمدة لديكِ لتحديد المسمى الدقيق المتوافق مع الـ Ground Truth"""
# #         request_str = str(request_str).lower()
        
# #         sqli_signals = ["select", "union", "insert", "update", "delete", "'", "--", "/*", "or 1=1"]
# #         sqli_score = sum(5 for signal in sqli_signals if signal in request_str) # الوزن 5

# #         xss_signals = ["<script", "script>", "javascript:", "onerror", "onload", "alert(", "<img", "href="]
# #         xss_score = sum(5 for signal in xss_signals if signal in request_str) # الوزن 5

# #         traversal_signals = ["..", "../", "..\\", "/etc/", "passwd", "boot.ini", "win.ini", "var/log"]
# #         traversal_score = sum(4 for signal in traversal_signals if signal in request_str) # LFI/RFI الوزن 4
        
# #         scores = {
# #             "sql_injection": sqli_score,
# #             "xss": xss_score,
# #             "directory_traversal": traversal_score
# #         }
        
# #         max_attack = max(scores, key=scores.get)
# #         if scores[max_attack] == 0:
# #             return "normal", 0.0
            
# #         return max_attack, scores[max_attack]

# #     def run(self, log_entry: dict):
# #         if "status" not in log_entry: log_entry["status"] = log_entry.get("status_code", 200)
# #         if "ip" not in log_entry: log_entry["ip"] = log_entry.get("source_ip", "127.0.0.1")

# #         result_data = {
# #             "status": "normal", "reason": "None", "severity": "Low",
# #             "sub_type": "None", "anomaly_score": 0.0, "stages": [] 
# #         }

# #         ip = log_entry["ip"]
# #         request_str = str(log_entry.get("request", ""))
# #         status_code = int(log_entry["status"])
        
# #         # جلب الوقت الديناميكي للوج
# #         log_time = self._parse_log_timestamp(log_entry)

# #         # 🚨 محطة 0: Stateful Brute Force Detection
# #         if self._check_brute_force_window(ip, request_str, status_code, log_time):
# #             result_data["stages"].append("TimeWindow:bruteforce")
# #             result_data.update({"status": "blocked", "reason": "Threat: bruteforce", "severity": "High", "sub_type": "bruteforce"})
# #             take_action(log_entry, "Time-Window Engine", "bruteforce", "High")
# #             return result_data

# #         # 🚨 محطة 1: الـ Static Engine
# #         try:
# #             is_attack, static_result, static_severity = check_log_static(log_entry)
# #             static_score = static_result.get("score", 0)
# #             static_reason = static_result.get("top_attack", "Unknown")
# #         except:
# #             is_attack, static_score, static_severity, static_reason = False, 0, "Low", "None"

# #         # =========================================================
# #         # 🚨 محطة 2: Severity-Based Routing Flow (اللوجيك الجديد بالملي)
# #         # =========================================================
        
# #         # 🔴 أولاً: مسار الخطورة العالية (High/Critical قادم من الـ Static بناءً على الـ THRESHOLD = 8)
# #         if static_severity in ["Critical", "High"] and static_score >= 8:
# #             result_data["stages"].append(f"Static_Suspect:{static_severity}")
            
# #             # استدعاء الـ 2 Models معاً كمجلس تأكيد (Majority Voting)
# #             threat_type = "normal"
# #             if self.threat_model:
# #                 try:
# #                     threat_res = self.threat_model(log_entry, model_name="ensemble")
# #                     threat_type = threat_res.get("attack_name", "Normal").strip().lower()
# #                 except: pass

# #             try:
# #                 ai_anomaly_prediction = self.anomaly_model.predict(log_entry, model_type="ensemble")
# #                 prediction_val = ai_anomaly_prediction.get("prediction", "Normal")
# #                 score = ai_anomaly_prediction.get("reconstruction_error", 0.0)
# #             except:
# #                 prediction_val, score = "Normal", 0.0

# #             is_threat_attack = threat_type not in ["normal", "benign", "none", "clean"]
# #             is_anomaly = prediction_val in ["Attack", "Anomaly", 1, True]

# #             # 🎯 التصويت المشروط: لو حد فيهم وافق وقفل على هجوم -> حظر فوري والمسمى يتبع الـ Static
# #             if is_anomaly or is_threat_attack:
# #                 static_type, _ = self._calculate_static_attack_weights(request_str)
# #                 confirmed_attack_type = static_type if static_type != "normal" else static_reason.lower()

# #                 result_data["stages"].append(f"AI_Confirmed:{confirmed_attack_type}")
# #                 result_data.update({
# #                     "status": "blocked", "reason": f"Static Engine: {confirmed_attack_type}",
# #                     "severity": static_severity, "sub_type": confirmed_attack_type, "anomaly_score": score
# #                 })
# #                 take_action(log_entry, "Hybrid Engine (Static+AI)", confirmed_attack_type, static_severity)
# #                 return result_data
# #             else:
# #                 # الـ AI Override: الموديلات أنقذت الريكوست النورمال المظلوم
# #                 result_data["stages"].append("AI_Override:Passed")
# #                 return result_data

# #         # 🟡 ثانياً: مسار الخطورة المنخفضة أو المتوسطة أو الريكوست نظيف استاتيكياً
# #         else:
# #             if static_score > 0: result_data["stages"].append(f"Static_Mild:{static_severity}")
# #             else: result_data["stages"].append("Static:Clean")

# #             # أ) يدخل على الـ Threat Model أولاً
# #             threat_type = "normal"
# #             confidence = 0.0
# #             if self.threat_model:
# #                 try:
# #                     threat_res = self.threat_model(log_entry, model_name="ensemble")
# #                     threat_type = threat_res.get("attack_name", "Normal").strip().lower()
# #                     confidence = threat_res.get("confidence", 0.0)
# #                 except: pass

# #             # استثناء benign_suspicious والـ Normal الصريح من البلوك هنا
# #             is_threat_attack = threat_type not in ["normal", "benign", "none", "clean", "benign_suspicious"]

# #             if is_threat_attack:
# #                 # هجوم صريح من الـ Threat -> دمج الاسم بالقواعد
# #                 static_type, _ = self._calculate_static_attack_weights(request_str)
# #                 confirmed_attack_type = static_type if static_type != "normal" else threat_type

# #                 result_data["stages"].append(f"Threat_Layer_Catch:{confirmed_attack_type}")
# #                 result_data.update({
# #                     "status": "blocked", "reason": f"Threat Layer: {confirmed_attack_type}",
# #                     "severity": "Medium", "sub_type": confirmed_attack_type, "anomaly_score": float(confidence)
# #                 })
# #                 take_action(log_entry, "Threat Layer", confirmed_attack_type, "Medium")
# #                 return result_data

# #             # ب) لو طلع نورمال أو شبهة رمادية -> محطة الـ Anomaly Engine للفصل النهائي بـ Static Baseline
# #             try:
# #                 ai_anomaly_prediction = self.anomaly_model.predict(log_entry, model_type="ensemble")
# #                 prediction_val = ai_anomaly_prediction.get("prediction", "Normal")
# #                 score = ai_anomaly_prediction.get("reconstruction_error", 0.0)
# #             except:
# #                 prediction_val, score = "Normal", 0.0

# #             if prediction_val in ["Attack", "Anomaly", 1, True]:
# #                 result_data["stages"].append(f"Anomaly_Layer_Catch:{score:.2f}")
# #                 result_data.update({
# #                     "status": "blocked", "reason": "Anomaly Detected",
# #                     "severity": "Medium", "sub_type": "Anomaly", "anomaly_score": score
# #                 })
# #                 take_action(log_entry, "AI Anomaly Engine", "Anomaly", "Medium")
# #                 return result_data

# #             # المرور بسلام وآمن
# #             result_data["stages"].append(f"Passed_All_Checks:{score:.2f}")
# #             return result_data  